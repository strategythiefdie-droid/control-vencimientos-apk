-- Version 1.5: sync location edits (including clearing a location) by timestamp.
-- Safe after the earlier location migration; does not delete or rewrite inventory rows.
alter table public.products
  add column if not exists location text not null default '';

alter table public.products
  add column if not exists location_updated_at bigint not null default 0;

notify pgrst, 'reload schema';
