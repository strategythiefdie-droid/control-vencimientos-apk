# Revisión 7 — endurecimiento del aislamiento multiinventario

## Cambios

- Se añadieron triggers SQL de defensa en profundidad para impedir que un `UPDATE/UPSERT` mueva productos o lotes entre inventarios.
- La base de datos ahora valida que cada lote apunte a un producto del mismo `workspace_id`, incluso si dos peticiones compiten.
- `SyncTombstoneStore` resuelve el espacio de preferencias por perfil en cada operación, evitando conservar una referencia a las preferencias de un perfil anterior si la instancia sobrevive a un cambio de perfil.

## Antes de usar

1. Realiza una copia de seguridad de Supabase.
2. Ejecuta la migración en un proyecto de pruebas, no en producción inicialmente.
3. Confirma que las tablas `products`, `inventory_batches` e `inventory_workspaces` existen y que las columnas `id`, `product_id` y `workspace_id` tienen los tipos esperados.
4. Prueba inserción y actualización dentro de un perfil, un lote vinculado a un producto de otro perfil (debe rechazarse), y un intento de cambiar el `workspace_id` de una fila existente (debe rechazarse).
5. Compila en Android Studio y prueba los perfiles secundarios con dispositivos autorizados y revocados.

## Limitaciones de verificación

Este entorno no tiene el wrapper de Gradle (`gradlew` / `gradle-wrapper.jar`) ni el ejecutable `gradle`, y no dispone de acceso a tu proyecto Supabase. Por tanto, no se afirma que el APK compile ni que la migración haya sido ejecutada. La migración debe revisarse en una base de pruebas antes de producción.
