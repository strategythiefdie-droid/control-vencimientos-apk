# Acceso local al modo administrador sin internet

Esta revisión permite abrir el modo administrador sin conexión **solo en un dispositivo donde la contraseña haya sido aceptada previamente por Supabase**. Tras un inicio de sesión online correcto, Android almacena un HMAC de la contraseña calculado con una clave de Android Keystore; no guarda la contraseña ni una sesión remota reutilizable.

## Límites de seguridad

- El acceso offline desbloquea únicamente la interfaz local.
- No crea `CloudAdminSession`; consultar usuarios/productos, generar códigos, vincular dispositivos, revocar accesos y cualquier otra operación remota siguen requiriendo internet y una sesión de servidor válida.
- Si se cambia la contraseña del administrador, el verificador local de dispositivos que ya iniciaron sesión no se invalida automáticamente hasta que el usuario vuelva a conectarse. Si la política requiere revocación inmediata, no debe usarse el modo offline como autorización para operaciones remotas (y el código no lo hace).
- Borrar datos de la app o reinstalar puede eliminar el verificador y requerir una autenticación online.
- El modo offline no puede saber si el administrador fue revocado remotamente mientras el dispositivo estuvo desconectado; por eso solo permite operaciones locales.

## Prueba recomendada

1. Instalar la app en un dispositivo de pruebas con internet.
2. Iniciar sesión online con la contraseña correcta.
3. Cerrar la app, activar modo avión y volver a abrir el acceso de administrador.
4. Confirmar que la misma contraseña permite abrir el área local y que una contraseña incorrecta no lo hace.
5. Confirmar que las funciones remotas muestran que necesitan conexión/sesión y no presentan datos remotos cacheados como si fueran actuales.
6. En un dispositivo que nunca haya autenticado online, confirmar que no permite el acceso offline.

La compilación y las pruebas en dispositivo deben ejecutarse en Android Studio antes de distribuir el APK.
