# Actualización de Macro

Cambios realizados en esta versión del proyecto:

- La lista de Macro ahora muestra cada registro importado por separado, de modo que un mismo producto puede tener varias fechas de vencimiento/lotes.
- El PLU se muestra exclusivamente desde el campo `plu`; ya no se usa el código de barras como sustituto del PLU.
- Cada tarjeta de Macro muestra el porcentaje de descuento cuando está disponible, la cantidad, la fecha física de vencimiento y la vigencia del descuento.
- El importador CSV sigue leyendo por encabezados `PLU`, `Descripcion`, `Fecha_Vencimiento`, `Cantidad_Vencer`, `DesdeCuando`, `HastaCuando`, `PorcentajeDescue`, e ignora `Estado Solic...` y `Detalle Estado`.
- Se añadió una opción OCR para elegir una imagen y extraer el texto mediante ML Kit. El texto OCR queda editable y requiere revisión: la lectura de una foto de una hoja de cálculo no garantiza por sí sola que las columnas se puedan separar correctamente. Para una importación precisa de todas las columnas se recomienda CSV.

No se cambió la configuración de acceso TUSK/admin de este proyecto base. El proyecto no se compiló en este entorno porque no hay Gradle instalado ni wrapper `gradlew` incluido; abrirlo en Android Studio y sincronizar Gradle antes de generar APK.
