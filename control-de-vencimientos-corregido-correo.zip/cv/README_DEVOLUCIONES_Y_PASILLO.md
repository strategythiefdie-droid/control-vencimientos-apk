# Devoluciones y mejora de Mi pasillo — versión 1.4

## Devolución
- En Inventario, pulsa **Seleccionar productos**.
- Marca uno o varios productos y elige **Tiene devolución** o **No tiene devolución**.
- Los productos marcados con devolución permanecen en el inventario y en Mi pasillo.
- Al marcarlos con devolución, se retiran sus registros de Macro. La importación CSV de Macro también omite productos marcados con devolución.
- Al quitar la marca no se agregan automáticamente a Macro; se pueden incorporar manualmente cuando corresponda.

## Supabase
Antes de desplegar la versión 1.4, ejecuta `supabase_migration_product_returns.sql` en Supabase SQL Editor.
Luego vuelve a desplegar `supabase/functions/admin-gateway/index.ts` para que la sincronización de los perfiles ACT lea y escriba el nuevo campo.

La migración es aditiva: crea columnas con valores predeterminados y no elimina los productos ni sus lotes existentes.

## Base local
Room migra de la versión 7 a la 8 y conserva los productos actuales. Los registros anteriores reciben `hasReturn = false`.

## Mi pasillo
La pantalla muestra ahora el lugar físico asociado al producto junto con la información del lote, vencimiento y cantidad. La cantidad del pasillo sigue siendo independiente de las existencias generales.
