package com.example.data

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface ProductDao {
    @Transaction
    @Query("SELECT * FROM products WHERE areaId = :areaId ORDER BY name ASC")
    fun getProductsWithBatchesByArea(areaId: String): Flow<List<ProductWithBatches>>

    @Transaction
    @Query("SELECT * FROM products ORDER BY name ASC")
    fun getAllProductsWithBatches(): Flow<List<ProductWithBatches>>

    @Transaction
    @Query("SELECT * FROM products ORDER BY name ASC")
    suspend fun getAllProductsWithBatchesDirect(): List<ProductWithBatches>

    @Transaction
    @Query("SELECT * FROM products WHERE id = :id LIMIT 1")
    suspend fun getProductWithBatchesById(id: String): ProductWithBatches?

    @Query("SELECT * FROM products WHERE id = :id LIMIT 1")
    suspend fun getProductById(id: String): ProductEntity?

    @Query("SELECT * FROM products WHERE areaId = :areaId")
    suspend fun getRawProductsByArea(areaId: String): List<ProductEntity>

    @Query("SELECT * FROM products")
    suspend fun getAllRawProducts(): List<ProductEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertProduct(product: ProductEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertProducts(products: List<ProductEntity>)

    @Update
    suspend fun updateProduct(product: ProductEntity)

    @Delete
    suspend fun deleteProduct(product: ProductEntity)

    @Query("DELETE FROM products WHERE id = :id")
    suspend fun deleteProductById(id: String)

    @Query("DELETE FROM products WHERE id IN (:ids)")
    suspend fun deleteProductsByIds(ids: List<String>)

    @Query("DELETE FROM products WHERE areaId = :areaId")
    suspend fun deleteByArea(areaId: String)

    @Query("DELETE FROM products")
    suspend fun clearAllProducts()

    @Query("SELECT COUNT(*) FROM products")
    suspend fun getProductCount(): Int
}
