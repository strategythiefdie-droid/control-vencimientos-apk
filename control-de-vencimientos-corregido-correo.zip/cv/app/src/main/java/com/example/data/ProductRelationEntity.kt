package com.example.data

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey
import java.util.UUID

@Entity(
    tableName = "product_relations",
    foreignKeys = [
        ForeignKey(entity = ProductEntity::class, parentColumns = ["id"], childColumns = ["parentProductId"], onDelete = ForeignKey.CASCADE),
        ForeignKey(entity = ProductEntity::class, parentColumns = ["id"], childColumns = ["childProductId"], onDelete = ForeignKey.CASCADE)
    ],
    indices = [Index(value = ["parentProductId", "childProductId"], unique = true), Index(value = ["parentProductId"]), Index(value = ["childProductId"])]
)
data class ProductRelationEntity(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val parentProductId: String,
    val childProductId: String,
    val unitsPerParent: Int,
    val createdAt: Long = System.currentTimeMillis()
)
