package com.example.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import com.example.profile.InventoryProfile

@Database(
    entities = [ProductEntity::class, BatchEntity::class, MacroRecordEntity::class, ProductRelationEntity::class, AisleEntryEntity::class],
    version = 9,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun productDao(): ProductDao
    abstract fun batchDao(): BatchDao
    abstract fun macroDao(): MacroDao
    abstract fun productRelationDao(): ProductRelationDao
    abstract fun aisleEntryDao(): AisleEntryDao

    companion object {
        private val MIGRATION_3_4 = object : Migration(3, 4) {
            override fun migrate(database: SupportSQLiteDatabase) {
                database.execSQL("ALTER TABLE products ADD COLUMN unitCost REAL")
            }
        }

        private val MIGRATION_4_5 = object : Migration(4, 5) {
            override fun migrate(database: SupportSQLiteDatabase) {
                database.execSQL("ALTER TABLE macro_records ADD COLUMN expiryDate TEXT")
                database.execSQL("ALTER TABLE macro_records ADD COLUMN quantity REAL")
                database.execSQL("ALTER TABLE macro_records ADD COLUMN discountPercent REAL")
            }
        }

        private val MIGRATION_5_6 = object : Migration(5, 6) {
            override fun migrate(database: SupportSQLiteDatabase) {
                database.execSQL("CREATE TABLE IF NOT EXISTS product_relations (id TEXT NOT NULL PRIMARY KEY, parentProductId TEXT NOT NULL, childProductId TEXT NOT NULL, unitsPerParent INTEGER NOT NULL, createdAt INTEGER NOT NULL, FOREIGN KEY(parentProductId) REFERENCES products(id) ON UPDATE NO ACTION ON DELETE CASCADE, FOREIGN KEY(childProductId) REFERENCES products(id) ON UPDATE NO ACTION ON DELETE CASCADE)")
                database.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS index_product_relations_parentProductId_childProductId ON product_relations(parentProductId, childProductId)")
                database.execSQL("CREATE INDEX IF NOT EXISTS index_product_relations_parentProductId ON product_relations(parentProductId)")
                database.execSQL("CREATE INDEX IF NOT EXISTS index_product_relations_childProductId ON product_relations(childProductId)")
                database.execSQL("CREATE TABLE IF NOT EXISTS aisle_entries (id TEXT NOT NULL PRIMARY KEY, productId TEXT NOT NULL, batchId TEXT, quantity REAL NOT NULL, status TEXT NOT NULL, updatedAt INTEGER NOT NULL, FOREIGN KEY(productId) REFERENCES products(id) ON UPDATE NO ACTION ON DELETE CASCADE, FOREIGN KEY(batchId) REFERENCES batches(id) ON UPDATE NO ACTION ON DELETE SET NULL)")
                database.execSQL("CREATE INDEX IF NOT EXISTS index_aisle_entries_productId ON aisle_entries(productId)")
                database.execSQL("CREATE INDEX IF NOT EXISTS index_aisle_entries_batchId ON aisle_entries(batchId)")
            }
        }

        private val MIGRATION_6_7 = object : Migration(6, 7) {
            override fun migrate(database: SupportSQLiteDatabase) {
                // Keep every existing product; old rows start with an empty location.
                database.execSQL("ALTER TABLE products ADD COLUMN location TEXT NOT NULL DEFAULT ''")
            }
        }

        private val MIGRATION_7_8 = object : Migration(7, 8) {
            override fun migrate(database: SupportSQLiteDatabase) {
                // Additive migration: keeps the existing product rows and their stock.
                database.execSQL("ALTER TABLE products ADD COLUMN hasReturn INTEGER NOT NULL DEFAULT 0")
                database.execSQL("ALTER TABLE products ADD COLUMN returnUpdatedAt INTEGER NOT NULL DEFAULT 0")
            }
        }

        private val MIGRATION_8_9 = object : Migration(8, 9) {
            override fun migrate(database: SupportSQLiteDatabase) {
                // Timestamp-based merge lets location edits (including clearing a location)
                // propagate across devices without an older offline device restoring stale data.
                database.execSQL("ALTER TABLE products ADD COLUMN locationUpdatedAt INTEGER NOT NULL DEFAULT 0")
            }
        }

        @Volatile
        private var INSTANCE: AppDatabase? = null
        @Volatile
        private var INSTANCE_PROFILE_ID: String? = null

        fun getInstance(context: Context): AppDatabase {
            val appContext = context.applicationContext
            val profile = InventoryProfile.selected(appContext)
                ?: throw IllegalStateException("Selecciona un perfil de inventario antes de abrir la base de datos.")
            return INSTANCE?.takeIf { INSTANCE_PROFILE_ID == profile.id && it.isOpen } ?: synchronized(this) {
                // Re-check inside the lock in case two components request the database together.
                val activeProfile = InventoryProfile.selected(appContext)
                    ?: throw IllegalStateException("Selecciona un perfil de inventario antes de abrir la base de datos.")
                val current = INSTANCE
                if (current != null && INSTANCE_PROFILE_ID == activeProfile.id && current.isOpen) {
                    return@synchronized current
                }
                // A profile switch must never keep serving the previous profile's Room instance.
                // Each profile has a different filename, and closing this handle does not delete its data.
                try { current?.close() } catch (_: Exception) { }
                val instance = Room.databaseBuilder(
                    appContext,
                    AppDatabase::class.java,
                    activeProfile.databaseName
                )
                // Never erase the inventory automatically when an unknown schema version is found.
                // If a migration is missing, fail visibly so the data can be backed up and migrated
                // deliberately instead of silently recreating an empty database.
                .addMigrations(MIGRATION_3_4, MIGRATION_4_5, MIGRATION_5_6, MIGRATION_6_7, MIGRATION_7_8, MIGRATION_8_9)
                .build()
                INSTANCE = instance
                INSTANCE_PROFILE_ID = activeProfile.id
                instance
            }
        }
    }
}
