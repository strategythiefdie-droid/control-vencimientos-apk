package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.ProductWithBatches
import com.example.ui.theme.StatusExpiredDark
import com.example.ui.theme.StatusSoonDark
import com.example.util.DateUtils

@Composable
fun StatsCardsSection(
    products: List<ProductWithBatches>,
    selectedFilter: String,
    onFilterSelect: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val totalProducts = products.size
    val totalBatches = products.sumOf { it.batches.size }
    val soonBatchesCount = products.sumOf { p ->
        p.batches.count { DateUtils.daysLeft(it.expiryDate) in 0..30 }
    }
    val expiredBatchesCount = products.sumOf { p ->
        p.batches.count { DateUtils.daysLeft(it.expiryDate) < 0 }
    }

    Row(
        modifier = modifier
            .fillMaxWidth()
            .testTag("stats_cards_row"),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        StatCard(
            title = "TOTAL",
            subtitle = "$totalBatches lote(s)",
            count = totalProducts,
            accentColor = MaterialTheme.colorScheme.primary,
            isSelected = selectedFilter == "ALL",
            onClick = { onFilterSelect("ALL") },
            modifier = Modifier.weight(1f)
        )
        StatCard(
            title = "PRÓXIMOS",
            subtitle = "≤ 30 días",
            count = soonBatchesCount,
            accentColor = StatusSoonDark,
            isSelected = selectedFilter == "SOON",
            onClick = { onFilterSelect("SOON") },
            modifier = Modifier.weight(1f)
        )
        StatCard(
            title = "VENCIDOS",
            subtitle = "atención",
            count = expiredBatchesCount,
            accentColor = StatusExpiredDark,
            isSelected = selectedFilter == "EXPIRED",
            onClick = { onFilterSelect("EXPIRED") },
            modifier = Modifier.weight(1f)
        )
    }
}

@Composable
fun StatCard(
    title: String,
    subtitle: String,
    count: Int,
    accentColor: Color,
    isSelected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val shape = RoundedCornerShape(16.dp)
    val bgColor = if (isSelected) {
        MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.55f)
    } else {
        MaterialTheme.colorScheme.surface.copy(alpha = 0.7f)
    }

    Box(
        modifier = modifier
            .clip(shape)
            .background(bgColor)
            .clickable(onClick = onClick)
            .padding(vertical = 12.dp, horizontal = 10.dp)
            .testTag("stat_card_${title.lowercase()}")
    ) {
        Column(
            modifier = Modifier.fillMaxWidth(),
            horizontalAlignment = Alignment.Start
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(6.dp)
                        .clip(CircleShape)
                        .background(accentColor)
                )
                Text(
                    text = title,
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 0.8.sp,
                    color = if (isSelected) accentColor else MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            Spacer(modifier = Modifier.height(4.dp))

            Text(
                text = count.toString(),
                fontSize = 22.sp,
                fontWeight = FontWeight.Black,
                color = MaterialTheme.colorScheme.onSurface,
                modifier = Modifier.testTag("stat_count_${title.lowercase()}")
            )

            Text(
                text = subtitle,
                fontSize = 9.sp,
                fontWeight = FontWeight.Normal,
                color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.8f)
            )
        }
    }
}
