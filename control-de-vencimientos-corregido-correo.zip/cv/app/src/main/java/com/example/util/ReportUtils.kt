package com.example.util

import com.example.data.ProductWithBatches
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

data class ReportRow(
    val day: String,
    val codeOrPlu: String,
    val productName: String,
    val quantity: Double,
    val expiryDay: String,
    val expiryMonth: String,
    val withdrawalDay: String,
    val withdrawalMonth: String,
    val batchLabel: String = "Lote 1",
    val actionPlan: String = "Venta sugerida / Macro",
    val responsible: String = "Líder de Sección",
    val areaId: String? = null,
    val location: String = ""
) {
    constructor(
        day: String,
        codeOrPlu: String,
        productName: String,
        quantity: Int,
        expiryDay: String,
        expiryMonth: String,
        withdrawalDay: String,
        withdrawalMonth: String,
        batchLabel: String = "Lote 1",
        actionPlan: String = "Venta sugerida / Macro",
        responsible: String = "Líder de Sección",
        areaId: String? = null
    ) : this(
        day = day,
        codeOrPlu = codeOrPlu,
        productName = productName,
        quantity = quantity.toDouble(),
        expiryDay = expiryDay,
        expiryMonth = expiryMonth,
        withdrawalDay = withdrawalDay,
        withdrawalMonth = withdrawalMonth,
        batchLabel = batchLabel,
        actionPlan = actionPlan,
        responsible = responsible,
        areaId = areaId
    )
}

object ReportUtils {
    private val monthsEs = arrayOf(
        "ENERO", "FEBRERO", "MARZO", "ABRIL", "MAYO", "JUNIO",
        "JULIO", "AGOSTO", "SEPTIEMBRE", "OCTUBRE", "NOVIEMBRE", "DICIEMBRE"
    )

    fun getCurrentMonthName(): String {
        val cal = Calendar.getInstance()
        return monthsEs[cal.get(Calendar.MONTH)]
    }

    fun getCurrentYear(): Int {
        return Calendar.getInstance().get(Calendar.YEAR)
    }

    fun generateReportRows(products: List<ProductWithBatches>): List<ReportRow> {
        val todayCal = Calendar.getInstance()
        val currentDayStr = String.format(Locale.US, "%02d", todayCal.get(Calendar.DAY_OF_MONTH))
        val rows = mutableListOf<ReportRow>()

        for (p in products) {
            val code = when {
                !p.plu.isNullOrBlank() -> p.plu ?: ""
                !p.barcode.isNullOrBlank() -> p.barcode ?: ""
                else -> "—"
            }

            val batchesToReport = if (p.batches.isNotEmpty()) p.batches else emptyList()

            for ((idx, batch) in batchesToReport.withIndex()) {
                var expDay = "—"
                var expMonth = "—"
                val parts = batch.expiryDate.split("-")
                if (parts.size == 3) {
                    expDay = parts[2]
                    expMonth = parts[1]
                }

                var wDay = expDay
                var wMonth = expMonth
                try {
                    val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.US)
                    val expDate = sdf.parse(batch.expiryDate)
                    if (expDate != null) {
                        val wCal = Calendar.getInstance().apply {
                            time = expDate
                            add(Calendar.DAY_OF_YEAR, -1)
                        }
                        wDay = String.format(Locale.US, "%02d", wCal.get(Calendar.DAY_OF_MONTH))
                        wMonth = String.format(Locale.US, "%02d", wCal.get(Calendar.MONTH) + 1)
                    }
                } catch (_: Exception) {}

                val label = batch.batchNumber ?: "Lote ${idx + 1}"

                rows.add(
                    ReportRow(
                        day = currentDayStr,
                        codeOrPlu = code,
                        productName = p.name,
                        quantity = batch.quantity,
                        expiryDay = expDay,
                        expiryMonth = expMonth,
                        withdrawalDay = wDay,
                        withdrawalMonth = wMonth,
                        batchLabel = label,
                        areaId = p.areaId,
                        location = p.location
                    )
                )
            }
        }

        return rows
    }

    fun generateShareableSummary(products: List<ProductWithBatches>, areaName: String): String {
        val rows = generateReportRows(products)
        val sb = StringBuilder()
        sb.appendLine("📋 FORMATO F-0646 - CONTROL DE VENCIMIENTOS")
        sb.appendLine("RELACIÓN DE PRODUCTOS Y LOTES PRÓXIMOS A RETIRAR")
        sb.appendLine("Área: $areaName | Mes: ${getCurrentMonthName()} ${getCurrentYear()}")
        sb.appendLine("=".repeat(48))

        if (rows.isEmpty()) {
            sb.appendLine("No hay lotes registrados en esta sección.")
        } else {
            rows.forEachIndexed { i, r ->
                val isFruit = QuantityFormatter.isFruitArea(r.areaId)
                val qtyLabel = if (isFruit) "Peso: ${QuantityFormatter.format(r.quantity)} kg" else "Cant: ${QuantityFormatter.format(r.quantity)}"
                sb.appendLine("${i + 1}. ${r.productName} [${r.batchLabel}] ($qtyLabel)")
                sb.appendLine("   Código/PLU: ${r.codeOrPlu}")
                if (r.location.isNotBlank()) sb.appendLine("   Lugar: ${r.location}")
                sb.appendLine("   Vencimiento: ${r.expiryDay}/${r.expiryMonth} | Retiro sugerido: ${r.withdrawalDay}/${r.withdrawalMonth}")
                sb.appendLine("   Plan: ${r.actionPlan} | Resp: ${r.responsible}")
            }
        }

        return sb.toString()
    }
}
