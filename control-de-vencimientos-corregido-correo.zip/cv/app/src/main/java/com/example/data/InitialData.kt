package com.example.data

/** No demo stock is inserted automatically: new installations start with empty inventories. */
object InitialData {
    fun getInitialSeed(): List<SeedProduct> = emptyList()
    fun getInitialMacroRecords(): List<MacroRecordEntity> = emptyList()
}

data class SeedProduct(
    val product: ProductEntity,
    val batches: List<BatchEntity>
)
