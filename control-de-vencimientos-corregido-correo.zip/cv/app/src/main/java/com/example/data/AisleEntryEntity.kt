package com.example.data

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey
import java.util.UUID

/** Independent physical-aisle count; does not silently alter total inventory. */
@Entity(
    tableName = "aisle_entries",
    foreignKeys = [
        ForeignKey(entity = ProductEntity::class, parentColumns = ["id"], childColumns = ["productId"], onDelete = ForeignKey.CASCADE),
        ForeignKey(entity = BatchEntity::class, parentColumns = ["id"], childColumns = ["batchId"], onDelete = ForeignKey.SET_NULL)
    ],
    indices = [Index(value = ["productId"]), Index(value = ["batchId"])]
)
data class AisleEntryEntity(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val productId: String,
    val batchId: String? = null,
    val quantity: Double,
    val status: String = "EN_PASILLO",
    val updatedAt: Long = System.currentTimeMillis()
)
