package com.example

import android.app.Application
import androidx.work.Configuration
import com.example.receiver.AlarmScheduler
import com.example.util.NotificationHelper
import com.example.worker.ExpiryNotificationWorker
import com.example.worker.AutoExpiryEmailWorker

class MyApplication : Application(), Configuration.Provider {

    override val workManagerConfiguration: Configuration
        get() = Configuration.Builder()
            .setMinimumLoggingLevel(android.util.Log.INFO)
            .build()

    override fun onCreate() {
        super.onCreate()
        try {
            NotificationHelper.createNotificationChannel(this)
        } catch (e: Throwable) {
            e.printStackTrace()
        }

        try {
            ExpiryNotificationWorker.schedulePeriodicCheck(this)
            AutoExpiryEmailWorker.schedule(this)
        } catch (e: Throwable) {
            e.printStackTrace()
        }

        try {
            AlarmScheduler.scheduleDailyAlarms(this)
        } catch (e: Throwable) {
            e.printStackTrace()
        }
    }
}
