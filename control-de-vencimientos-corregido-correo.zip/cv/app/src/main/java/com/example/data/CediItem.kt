package com.example.data

/**
 * Representa una fila parseada de la planilla CEDI.
 */
data class CediParsedItem(
    val pluOrBarcode: String,
    val name: String,
    val quantity: Double,
    val isMatchedWithCatalog: Boolean = false,
    val matchedCatalogName: String? = null,
    val matchedBarcode: String? = null,
    val matchedPlu: String? = null
) {
    constructor(
        pluOrBarcode: String,
        name: String,
        quantity: Int,
        isMatchedWithCatalog: Boolean = false,
        matchedCatalogName: String? = null,
        matchedBarcode: String? = null,
        matchedPlu: String? = null
    ) : this(
        pluOrBarcode,
        name,
        quantity.toDouble(),
        isMatchedWithCatalog,
        matchedCatalogName,
        matchedBarcode,
        matchedPlu
    )
}

/**
 * Resultado del procesamiento o previsualización de una carga CEDI.
 */
data class CediParseResult(
    val items: List<CediParsedItem>,
    val totalUnits: Double,
    val unrecognizedCount: Int,
    val errorRows: List<String> = emptyList()
) {
    constructor(
        items: List<CediParsedItem>,
        totalUnits: Int,
        unrecognizedCount: Int,
        errorRows: List<String> = emptyList()
    ) : this(
        items,
        totalUnits.toDouble(),
        unrecognizedCount,
        errorRows
    )
}
