package com.example.data

import androidx.room.withTransaction
import kotlinx.coroutines.flow.Flow
import java.util.UUID

class RelationsAndAisleRepository(private val db: AppDatabase) {
    private val products = db.productDao()
    private val batches = db.batchDao()
    private val relations = db.productRelationDao()
    private val aisle = db.aisleEntryDao()

    fun observeRelations(): Flow<List<ProductRelationEntity>> = relations.observeAll()
    fun observeAisle(): Flow<List<AisleEntryEntity>> = aisle.observeAll()

    suspend fun saveRelation(id: String?, parentId: String, childId: String, units: Int) {
        require(parentId != childId) { "Un producto no puede relacionarse consigo mismo." }
        require(units > 0) { "La equivalencia debe ser mayor que cero." }
        require(products.getProductById(parentId) != null && products.getProductById(childId) != null) { "Selecciona dos productos existentes." }
        db.withTransaction {
            val duplicate = relations.getAll().firstOrNull {
                it.id != id && ((it.parentProductId == parentId && it.childProductId == childId) || (it.parentProductId == childId && it.childProductId == parentId))
            }
            require(duplicate == null) { "Esta pareja de productos ya tiene una relación." }
            val existing = id?.let { relations.getById(it) }
            val entity = ProductRelationEntity(id = existing?.id ?: UUID.randomUUID().toString(), parentProductId = parentId, childProductId = childId, unitsPerParent = units, createdAt = existing?.createdAt ?: System.currentTimeMillis())
            if (existing == null) relations.insert(entity) else relations.update(entity)
        }
    }

    suspend fun deleteRelation(id: String) = relations.deleteById(id)

    /** Converts only within the selected source lot and copies its expiry date to the destination lot. */
    suspend fun convert(relationId: String, sourceBatchId: String, sourceQuantity: Int, parentToChild: Boolean): String = db.withTransaction {
        require(sourceQuantity > 0) { "La cantidad debe ser mayor que cero." }
        val relation = relations.getById(relationId) ?: error("La relación ya no existe.")
        val source = batches.getBatchById(sourceBatchId) ?: error("El lote de origen ya no existe.")
        val sourceProductId = if (parentToChild) relation.parentProductId else relation.childProductId
        val targetProductId = if (parentToChild) relation.childProductId else relation.parentProductId
        require(source.productId == sourceProductId) { "El lote seleccionado no pertenece al producto de origen." }
        val targetQuantity = if (parentToChild) sourceQuantity.toDouble() * relation.unitsPerParent else {
            require(sourceQuantity % relation.unitsPerParent == 0) { "La cantidad de unidades debe ser múltiplo de ${relation.unitsPerParent} para convertirla en cajas." }
            (sourceQuantity / relation.unitsPerParent).toDouble()
        }
        require(source.quantity >= sourceQuantity.toDouble()) { "Existencias insuficientes en el lote seleccionado." }
        val targetProduct = products.getProductById(targetProductId) ?: error("El producto de destino ya no existe.")
        val matchingTarget = batches.getBatchesForProductDirect(targetProductId).firstOrNull {
            it.expiryDate == source.expiryDate && it.batchNumber == source.batchNumber
        }
        batches.updateBatch(source.copy(quantity = source.quantity - sourceQuantity.toDouble()))
        if (matchingTarget != null) {
            batches.updateBatch(matchingTarget.copy(quantity = matchingTarget.quantity + targetQuantity))
        } else {
            batches.insertBatch(BatchEntity(productId = targetProduct.id, batchNumber = source.batchNumber, quantity = targetQuantity, expiryDate = source.expiryDate))
        }
        "Conversión guardada: ${sourceQuantity} ${if (parentToChild) "cajas" else "unidades"} → ${targetQuantity.toInt()} ${if (parentToChild) "unidades" else "cajas"}. Vencimiento ${source.expiryDate}."
    }

    suspend fun addToAisle(productId: String, batchId: String?, quantity: Double) {
        require(quantity >= 0.0) { "La cantidad no puede ser negativa." }
        require(products.getProductById(productId) != null) { "El producto ya no existe." }
        if (batchId != null) require(batches.getBatchById(batchId)?.productId == productId) { "El lote no pertenece al producto." }
        db.withTransaction {
            val current = aisle.find(productId, batchId)
            if (current == null) aisle.insert(AisleEntryEntity(productId = productId, batchId = batchId, quantity = quantity))
            else aisle.update(current.copy(quantity = quantity, status = if (quantity == 0.0) "AGOTADO" else "EN_PASILLO", updatedAt = System.currentTimeMillis()))
        }
    }

    suspend fun updateAisle(id: String, quantity: Double? = null, status: String? = null) {
        require(quantity == null || quantity >= 0.0) { "La cantidad no puede ser negativa." }
        val current = aisle.getById(id) ?: error("El registro del pasillo ya no existe.")
        aisle.update(current.copy(quantity = quantity ?: current.quantity, status = status ?: if ((quantity ?: current.quantity) == 0.0) "AGOTADO" else current.status, updatedAt = System.currentTimeMillis()))
    }

    suspend fun removeFromAisle(id: String) = aisle.deleteById(id)
}
