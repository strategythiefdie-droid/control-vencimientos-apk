package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.Area
import com.example.data.ProductWithBatches
import com.example.util.DateUtils
import com.example.util.QuantityFormatter

@Composable
fun InventorySummarySection(products: List<ProductWithBatches>, onOpenExpiring: () -> Unit = {}) {
    val totalProducts = products.size
    val soonBatches = products.sumOf { p -> p.batches.count { DateUtils.daysLeft(it.expiryDate) in 0..30 } }

    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Column {
            Text("Resumen del inventario", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onBackground)
            Text("Vista general de todas las categorías", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        SummaryMetric("POR VENCER", soonBatches.toString(), "Lotes en 0–30 días", Modifier.fillMaxWidth(), onClick = onOpenExpiring)
        SummaryMetric("PRODUCTOS EN CATÁLOGO", totalProducts.toString(), "Productos con al menos un registro", Modifier.fillMaxWidth())

        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(18.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Column(Modifier.padding(16.dp)) {
                Text("Cantidad actual por categoría", fontSize = 16.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(4.dp))
                Text("Barras comparativas por categoría. Fruver se expresa en kg; las demás categorías, en unidades.", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(Modifier.height(14.dp))
                val values = Area.workAreas.map { area ->
                    val areaProducts = products.filter { it.areaId == area.id }
                    Triple(area, areaProducts.sumOf { it.totalQuantity }, areaProducts.size)
                }
                val maxValue = values.maxOfOrNull { it.second }?.coerceAtLeast(1.0) ?: 1.0
                values.forEach { (area, quantity, count) ->
                    Column(Modifier.fillMaxWidth().padding(bottom = 12.dp)) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("${area.icon} ${area.displayName}", fontSize = 12.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                            Text("${QuantityFormatter.format(quantity)} · $count prod.", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        Spacer(Modifier.height(5.dp))
                        LinearProgressIndicator(
                            progress = (quantity / maxValue).toFloat().coerceIn(0f, 1f),
                            modifier = Modifier.fillMaxWidth().height(8.dp),
                            color = MaterialTheme.colorScheme.primary,
                            trackColor = MaterialTheme.colorScheme.surfaceVariant
                        )
                    }
                }
                if (products.isEmpty()) {
                    Text("Aún no hay productos. Registra el primer lote para empezar a ver estadísticas.", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
    }
}

@Composable
private fun SummaryMetric(title: String, value: String, detail: String, modifier: Modifier = Modifier, onClick: (() -> Unit)? = null) {
    Card(
        modifier = modifier.then(if (onClick != null) Modifier.clickable { onClick() } else Modifier),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(Modifier.padding(13.dp)) {
            Text(title, fontSize = 9.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
            Spacer(Modifier.height(5.dp))
            Text(value, fontSize = 20.sp, fontWeight = FontWeight.ExtraBold, color = MaterialTheme.colorScheme.onSurface)
            Spacer(Modifier.height(3.dp))
            Text(detail, fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}
