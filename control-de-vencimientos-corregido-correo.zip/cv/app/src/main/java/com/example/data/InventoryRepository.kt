package com.example.data

import android.content.Context
import com.example.util.DateUtils
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.first
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID
import java.util.Locale

data class MacroImportResult(
    val totalRows: Int,
    val matched: Int,
    val unmatched: Int,
    val errorMessage: String? = null,
    val message: String? = null
)

class InventoryRepository(context: Context) {
    private val db = AppDatabase.getInstance(context)
    private val productDao = db.productDao()
    private val batchDao = db.batchDao()
    private val macroDao = db.macroDao()
    private val tombstones = SyncTombstoneStore(context.applicationContext)

    suspend fun initializeIfNeeded() {
        // Los inventarios y el control de macro empiezan vacíos en instalaciones nuevas.
        // No se insertan productos de demostración automáticamente.
    }

    suspend fun getAllProductsWithBatchesDirect(): List<ProductWithBatches> =
        productDao.getAllProductsWithBatchesDirect()

    // Snapshot/merge helpers used by the offline-first Supabase sync layer.
    suspend fun snapshotProducts(): List<ProductEntity> = productDao.getAllRawProducts()
    suspend fun snapshotBatches(): List<BatchEntity> = batchDao.getAllBatches().first()
    suspend fun snapshotMacroRecords(): List<MacroRecordEntity> = macroDao.getAllMacroRecords().first()

    suspend fun mergeCloudInventory(products: List<ProductEntity>, batches: List<BatchEntity>) {
        if (products.isNotEmpty()) productDao.insertProducts(products)
        if (batches.isNotEmpty()) batchDao.insertBatches(batches)
    }

    /** Update the physical location without touching stock, batches or product identity. */
    suspend fun updateProductLocation(productId: String, location: String) {
        val product = productDao.getProductById(productId) ?: error("El producto ya no existe.")
        val cleanLocation = location.trim()
        val updatedAt = maxOf(System.currentTimeMillis(), product.locationUpdatedAt + 1L)
        productDao.updateProduct(product.copy(location = cleanLocation, locationUpdatedAt = updatedAt))
    }

    /** Merge location edits by timestamp, including an intentional empty location. */
    suspend fun mergeCloudProductLocations(locations: Map<String, Pair<String, Long>>) {
        locations.forEach { (productId, remote) ->
            val local = productDao.getProductById(productId) ?: return@forEach
            val (cloudLocation, cloudUpdatedAt) = remote
            val remoteIsNewer = cloudUpdatedAt > local.locationUpdatedAt
            val legacyCloudLocation = local.location.isBlank() && cloudLocation.isNotBlank() && cloudUpdatedAt >= local.locationUpdatedAt
            // Version 1.4 and earlier did not send a location timestamp. When both sides are
            // still legacy (timestamp 0), prefer a non-empty cloud value so other devices can
            // receive a location written by an older installation.
            val changedByLegacyClient = cloudUpdatedAt == 0L && local.locationUpdatedAt == 0L &&
                cloudLocation.isNotBlank() && cloudLocation != local.location
            if (remoteIsNewer || legacyCloudLocation || changedByLegacyClient) {
                productDao.updateProduct(local.copy(location = cloudLocation, locationUpdatedAt = cloudUpdatedAt))
            }
        }
    }

    /** Apply the newest return flag from the cloud without overwriting a newer offline edit. */
    suspend fun mergeCloudProductReturnFlags(flags: Map<String, Pair<Boolean, Long>>) {
        flags.forEach { (productId, remote) ->
            val local = productDao.getProductById(productId) ?: return@forEach
            val (hasReturn, updatedAt) = remote
            if (updatedAt > local.returnUpdatedAt) {
                val updated = local.copy(hasReturn = hasReturn, returnUpdatedAt = updatedAt)
                productDao.updateProduct(updated)
                if (hasReturn) removeMacroReferencesForProduct(updated)
            }
        }
    }

    /** Bulk flag editor used by the inventory selection mode. */
    suspend fun setProductsReturnStatus(productIds: List<String>, hasReturn: Boolean): Int {
        val now = System.currentTimeMillis()
        val products = productIds.distinct().mapNotNull { productDao.getProductById(it) }
        products.forEach { product ->
            val updated = product.copy(
                hasReturn = hasReturn,
                returnUpdatedAt = maxOf(now, product.returnUpdatedAt + 1L)
            )
            productDao.updateProduct(updated)
            if (hasReturn) removeMacroReferencesForProduct(updated)
        }
        return products.size
    }

    fun getAllProducts(): Flow<List<ProductWithBatches>> = productDao.getAllProductsWithBatches()

    fun getProducts(area: Area): Flow<List<ProductWithBatches>> {
        return if (area == Area.ADMIN) {
            productDao.getAllProductsWithBatches()
        } else {
            productDao.getProductsWithBatchesByArea(area.id)
        }
    }

    fun getMacroRecords(area: Area): Flow<List<MacroRecordEntity>> {
        val records = if (area == Area.ADMIN) macroDao.getAllMacroRecords() else macroDao.getMacroRecordsByArea(area.id)
        // Defensive filter: even legacy Macro rows cannot reappear while their product is
        // marked for return, including after a cloud pull or restoration from a backup.
        return combine(records, productDao.getAllProductsWithBatches()) { macroRows, products ->
            val returnProducts = products.filter { it.hasReturn }
            macroRows.filterNot { record ->
                returnProducts.any { product -> macroRecordMatchesProduct(record, product.product) }
            }
        }
    }

    suspend fun findExistingProduct(areaId: String?, barcode: String?, plu: String?): ProductEntity? {
        val all = productDao.getAllRawProducts()
        val normBarcode = barcode?.trim()?.lowercase()?.takeIf { it.isNotEmpty() }
        val normPlu = plu?.trim()?.lowercase()?.takeIf { it.isNotEmpty() }

        if (normBarcode == null && normPlu == null) return null

        return all.firstOrNull { p ->
            val pBarcode = p.barcode?.trim()?.lowercase()
            val pPlu = p.plu?.trim()?.lowercase()

            val matchesArea = areaId == null || p.areaId == areaId
            val matchesBarcode = normBarcode != null && pBarcode == normBarcode
            val matchesPlu = normPlu != null && pPlu == normPlu

            matchesArea && (matchesBarcode || matchesPlu)
        }
    }

    suspend fun findProductWithBatches(barcode: String?, plu: String?): ProductWithBatches? {
        val all = productDao.getAllProductsWithBatches().first()
        val normBarcode = barcode?.trim()?.lowercase()?.takeIf { it.isNotEmpty() }
        val normPlu = plu?.trim()?.lowercase()?.takeIf { it.isNotEmpty() }

        if (normBarcode == null && normPlu == null) return null

        return all.firstOrNull { item ->
            val pBarcode = item.barcode?.trim()?.lowercase()
            val pPlu = item.plu?.trim()?.lowercase()

            (normBarcode != null && pBarcode == normBarcode) ||
            (normPlu != null && pPlu == normPlu)
        }
    }

    suspend fun findAutoFillMatch(barcode: String?, plu: String?, name: String?): ProductWithBatches? {
        val all = productDao.getAllProductsWithBatches().first()
        val b = barcode?.trim()?.lowercase()?.takeIf { it.isNotEmpty() }
        val p = plu?.trim()?.lowercase()?.takeIf { it.isNotEmpty() }
        val n = name?.trim()?.lowercase()?.takeIf { it.isNotEmpty() }

        return all.firstOrNull { item ->
            (b != null && item.barcode?.trim()?.lowercase() == b) ||
            (p != null && item.plu?.trim()?.lowercase() == p) ||
            (n != null && item.name.trim().lowercase() == n)
        }
    }

    /**
     * Guarda un producto y/o lote.
     * Si el producto con este PLU o código de barras ya existe:
     * - Se asocia el nuevo lote a ese producto existente sin duplicar el producto en el catálogo.
     * Si se está editando un lote específico:
     * - Se actualiza ese lote.
     */
    suspend fun saveProductWithBatch(
        areaId: String,
        name: String,
        barcode: String?,
        plu: String?,
        quantity: Double,
        expiryDate: String,
        editingProductId: String? = null,
        editingBatchId: String? = null,
        unitCost: Double? = null,
        location: String = ""
    ) {
        val cleanBarcode = barcode?.trim()?.takeIf { it.isNotEmpty() }
        val cleanPlu = plu?.trim()?.takeIf { it.isNotEmpty() }
        val cleanName = name.trim()
        val cleanLocation = location.trim()

        if (editingBatchId != null) {
            // Editando un lote existente
            val existingBatch = batchDao.getBatchById(editingBatchId)
            if (existingBatch != null) {
                batchDao.updateBatch(
                    existingBatch.copy(
                        quantity = quantity,
                        expiryDate = expiryDate
                    )
                )
                // Actualizar nombre/códigos del producto padre si cambiaron
                val parentProduct = productDao.getProductById(existingBatch.productId)
                if (parentProduct != null) {
                    productDao.updateProduct(
                        parentProduct.copy(
                            name = cleanName,
                            barcode = cleanBarcode,
                            plu = cleanPlu,
                            unitCost = unitCost ?: parentProduct.unitCost,
                            location = cleanLocation,
                            locationUpdatedAt = if (cleanLocation != parentProduct.location) maxOf(System.currentTimeMillis(), parentProduct.locationUpdatedAt + 1L) else parentProduct.locationUpdatedAt
                        )
                    )
                }
            }
            return
        }

        // Si tenemos un editingProductId explícito o encontramos un producto coincidente
        val targetProduct: ProductEntity = if (editingProductId != null) {
            val p = productDao.getProductById(editingProductId)
            if (p != null) {
                val updated = p.copy(
                    name = cleanName, barcode = cleanBarcode, plu = cleanPlu,
                    unitCost = unitCost ?: p.unitCost,
                    location = cleanLocation,
                    locationUpdatedAt = if (cleanLocation != p.location) maxOf(System.currentTimeMillis(), p.locationUpdatedAt + 1L) else p.locationUpdatedAt
                )
                productDao.updateProduct(updated)
                updated
            } else {
                val newP = ProductEntity(
                    areaId = areaId,
                    name = cleanName,
                    barcode = cleanBarcode,
                    plu = cleanPlu,
                    unitCost = unitCost,
                    location = cleanLocation,
                    locationUpdatedAt = if (cleanLocation.isNotBlank()) System.currentTimeMillis() else 0L
                )
                productDao.insertProduct(newP)
                newP
            }
        } else {
            // Buscar si ya existe un producto con el mismo código de barras o PLU en esta área
            val existing = findExistingProduct(areaId, cleanBarcode, cleanPlu)
            if (existing != null) {
                // Producto ya existe: actualizamos su nombre si cambió
                val resultingLocation = cleanLocation.ifBlank { existing.location }
                val updated = existing.copy(
                    name = cleanName,
                    unitCost = unitCost ?: existing.unitCost,
                    // A blank field while adding another batch must not erase a saved location.
                    location = resultingLocation,
                    locationUpdatedAt = if (resultingLocation != existing.location) maxOf(System.currentTimeMillis(), existing.locationUpdatedAt + 1L) else existing.locationUpdatedAt
                )
                if (updated != existing) productDao.updateProduct(updated)
                updated
            } else {
                // Producto nuevo
                val newP = ProductEntity(
                    areaId = areaId,
                    name = cleanName,
                    barcode = cleanBarcode,
                    plu = cleanPlu,
                    unitCost = unitCost,
                    location = cleanLocation,
                    locationUpdatedAt = if (cleanLocation.isNotBlank()) System.currentTimeMillis() else 0L
                )
                productDao.insertProduct(newP)
                newP
            }
        }

        // Ahora agregar el lote al targetProduct:
        // Si ya existe un lote con exactamente la misma fecha de vencimiento, sumamos la cantidad
        val existingBatches = batchDao.getBatchesForProduct(targetProduct.id).first()
        val sameDateBatch = existingBatches.firstOrNull { it.expiryDate == expiryDate }

        if (sameDateBatch != null) {
            batchDao.updateBatch(
                sameDateBatch.copy(
                    quantity = sameDateBatch.quantity + quantity
                )
            )
        } else {
            val newBatch = BatchEntity(
                productId = targetProduct.id,
                batchNumber = "Lote ${existingBatches.size + 1}",
                quantity = quantity,
                expiryDate = expiryDate
            )
            batchDao.insertBatch(newBatch)
        }
    }

    suspend fun saveProductWithBatch(
        areaId: String,
        name: String,
        barcode: String?,
        plu: String?,
        quantity: Int,
        expiryDate: String,
        editingProductId: String? = null,
        editingBatchId: String? = null
    ) = saveProductWithBatch(
        areaId, name, barcode, plu, quantity.toDouble(), expiryDate, editingProductId, editingBatchId
    )

    suspend fun addBatchToProduct(
        productId: String,
        quantity: Double,
        expiryDate: String,
        batchNumber: String? = null
    ) {
        val existingBatches = batchDao.getBatchesForProduct(productId).first()
        val sameDateBatch = existingBatches.firstOrNull { it.expiryDate == expiryDate }

        if (sameDateBatch != null) {
            batchDao.updateBatch(
                sameDateBatch.copy(quantity = sameDateBatch.quantity + quantity)
            )
        } else {
            val newBatch = BatchEntity(
                productId = productId,
                batchNumber = batchNumber ?: "Lote ${existingBatches.size + 1}",
                quantity = quantity,
                expiryDate = expiryDate
            )
            batchDao.insertBatch(newBatch)
        }
    }

    suspend fun addBatchToProduct(
        productId: String,
        quantity: Int,
        expiryDate: String,
        batchNumber: String? = null
    ) = addBatchToProduct(productId, quantity.toDouble(), expiryDate, batchNumber)

    suspend fun deleteBatch(batchId: String) {
        val batch = batchDao.getBatchById(batchId)
        if (batch != null) {
            tombstones.add("batch", batch.id)
            val product = productDao.getProductById(batch.productId)
            if (product != null) {
                val records = macroDao.getAllMacroRecords().first().filter { record ->
                    record.areaId == product.areaId && record.expiryDate == batch.expiryDate && (
                        (!record.plu.isNullOrBlank() && (normalizeProductKey(record.plu) == normalizeProductKey(product.plu) || normalizeProductKey(record.plu) == normalizeProductKey(product.barcode))) ||
                        record.name.trim().equals(product.name.trim(), ignoreCase = true)
                    )
                }
                records.forEach { tombstones.add("macro", it.id); macroDao.deleteById(it.id) }
            }
        }
        batchDao.deleteBatchById(batchId)

        // Si era el último lote, conservar el producto. La interfaz lo mostrará como "Sin stock";
        // el usuario puede eliminar el producto explícitamente desde su tarjeta.
    }

    suspend fun deleteBatchesBatch(batchIds: List<String>) {
        if (batchIds.isEmpty()) return
        val records = macroDao.getAllMacroRecords().first().toMutableList()
        batchIds.forEach { id ->
            val batch = batchDao.getBatchById(id) ?: return@forEach
            tombstones.add("batch", id)
            val product = productDao.getProductById(batch.productId) ?: return@forEach
            val linked = records.filter { record ->
                record.areaId == product.areaId && record.expiryDate == batch.expiryDate && (
                    (!record.plu.isNullOrBlank() && (normalizeProductKey(record.plu) == normalizeProductKey(product.plu) || normalizeProductKey(record.plu) == normalizeProductKey(product.barcode))) ||
                    record.name.trim().equals(product.name.trim(), ignoreCase = true)
                )
            }
            linked.forEach { tombstones.add("macro", it.id); macroDao.deleteById(it.id); records.remove(it) }
        }
        batchDao.deleteBatchesByIds(batchIds)

        // No eliminar los productos aunque se queden sin lotes: se conservan como "Sin stock".
        // La eliminación completa sigue disponible mediante deleteProduct().
    }

    suspend fun deleteProduct(productId: String) {
        val product = productDao.getProductById(productId)
        batchDao.getBatchesForProduct(productId).first().forEach { tombstones.add("batch", it.id) }
        if (product != null) removeMacroReferencesForProduct(product)
        tombstones.add("product", productId)
        productDao.deleteProductById(productId)
    }

    suspend fun moveProductToArea(productId: String, targetAreaId: String) {
        val product = productDao.getProductById(productId) ?: return
        productDao.updateProduct(product.copy(areaId = targetAreaId))
    }

    suspend fun deleteProductsBatch(productIds: List<String>) {
        if (productIds.isNotEmpty()) {
            productIds.forEach { id ->
                batchDao.getBatchesForProduct(id).first().forEach { tombstones.add("batch", it.id) }
                tombstones.add("product", id)
            }
            productDao.deleteProductsByIds(productIds)
        }
    }

    suspend fun deleteExpiredBatches(areaId: String? = null): Int {
        val products = if (areaId == null || areaId == Area.ADMIN.id) {
            productDao.getAllProductsWithBatches().first()
        } else {
            productDao.getProductsWithBatchesByArea(areaId).first()
        }

        val expiredBatchIds = mutableListOf<String>()
        for (p in products) {
            for (b in p.batches) {
                if (DateUtils.daysLeft(b.expiryDate) < 0) {
                    expiredBatchIds.add(b.id)
                }
            }
        }

        if (expiredBatchIds.isNotEmpty()) {
            deleteBatchesBatch(expiredBatchIds)
        }
        return expiredBatchIds.size
    }

    suspend fun saveMultiScannedBatch(areaId: String, items: List<MultiScanItem>, expiryDate: String) {
        var allInArea = productDao.getProductsWithBatchesByArea(areaId).first()

        for (item in items) {
            val existing = allInArea.firstOrNull { p ->
                val isSameProduct = (!p.barcode.isNullOrBlank() && p.barcode.equals(item.barcode, ignoreCase = true)) ||
                        (!p.plu.isNullOrBlank() && p.plu.equals(item.barcode, ignoreCase = true)) ||
                        (!item.plu.isNullOrBlank() && !p.plu.isNullOrBlank() && p.plu.equals(item.plu, ignoreCase = true))
                isSameProduct
            }

            val targetProductId = if (existing != null) {
                existing.id
            } else {
                val newProduct = ProductEntity(
                    areaId = areaId,
                    name = item.name,
                    barcode = item.barcode,
                    plu = item.plu
                )
                productDao.insertProduct(newProduct)
                allInArea = productDao.getProductsWithBatchesByArea(areaId).first()
                newProduct.id
            }

            addBatchToProduct(
                productId = targetProductId,
                quantity = item.quantity,
                expiryDate = item.expiryDate ?: expiryDate
            )
        }
    }

    private fun normalizeProductKey(value: String?): String = value.orEmpty()
        .trim().lowercase(Locale.ROOT).replace(Regex("\\s+"), "")

    private fun macroRecordMatchesProduct(record: MacroRecordEntity, product: ProductEntity): Boolean {
        if (record.areaId != product.areaId) return false
        val recordKey = normalizeProductKey(record.plu)
        val productKeys = listOf(normalizeProductKey(product.plu), normalizeProductKey(product.barcode)).filter { it.isNotBlank() }.toSet()
        if (recordKey.isNotBlank() && productKeys.isNotEmpty()) return recordKey in productKeys
        return record.name.trim().equals(product.name.trim(), ignoreCase = true)
    }

    private suspend fun removeMacroReferencesForProduct(product: ProductEntity) {
        val records = macroDao.getAllMacroRecords().first().filter { record ->
            macroRecordMatchesProduct(record, product)
        }
        records.forEach { tombstones.add("macro", it.id) }
        records.forEach { macroDao.deleteById(it.id) }
    }

    private suspend fun deduplicateMacroRecords() {
        val records = macroDao.getAllMacroRecords().first()
        val groups = records.groupBy { record ->
            val identity = normalizeProductKey(record.plu).ifBlank { normalizeProductKey(record.name) }
            "${record.areaId}|$identity|${record.expiryDate.orEmpty()}"
        }
        groups.values.filter { it.size > 1 }.forEach { duplicates ->
            val keep = duplicates.maxByOrNull { it.updatedAt } ?: return@forEach
            duplicates.filter { it.id != keep.id }.forEach { duplicate ->
                tombstones.add("macro", duplicate.id)
                macroDao.deleteById(duplicate.id)
            }
        }
    }

    suspend fun importMacroPastedText(area: Area, text: String): MacroImportResult {
        // CSV se procesa por encabezados: el orden de columnas puede cambiar y algunas
        // exportaciones agregan columnas adicionales (que ignoramos expresamente).
        val normalizedText = text.removePrefix("\uFEFF").replace("\r\n", "\n").replace('\r', '\n')
        val lines = normalizedText.lines().filter { it.isNotBlank() }
        if (lines.isEmpty()) return MacroImportResult(0, 0, 0, "El archivo está vacío.")

        fun splitDelimitedLine(line: String, delimiter: Char): List<String> {
            val values = mutableListOf<String>()
            val cell = StringBuilder()
            var quoted = false
            var i = 0
            while (i < line.length) {
                val c = line[i]
                when {
                    c == '"' && quoted && i + 1 < line.length && line[i + 1] == '"' -> {
                        cell.append('"'); i++
                    }
                    c == '"' -> quoted = !quoted
                    c == delimiter && !quoted -> {
                        values.add(cell.toString().trim())
                        cell.setLength(0)
                    }
                    else -> cell.append(c)
                }
                i++
            }
            values.add(cell.toString().trim())
            return values
        }
        fun norm(value: String): String = java.text.Normalizer
            .normalize(value.trim().removePrefix("\uFEFF").lowercase(Locale.ROOT), java.text.Normalizer.Form.NFD)
            .replace(Regex("\\p{Mn}+"), "")
            .replace(Regex("[^a-z0-9]"), "")

        val firstLine = lines.first()
        val delimiter = listOf(',', ';', '\t').maxByOrNull { splitDelimitedLine(firstLine, it).size } ?: ','
        val headers = splitDelimitedLine(firstLine, delimiter)
        val headerNames = headers.map(::norm)
        val hasHeader = headerNames.any { it == "plu" || it.startsWith("plu") } &&
            headerNames.any { it == "descripcion" || it == "nombre" || it.startsWith("descripcion") }
        if (!hasHeader) {
            return MacroImportResult(0, 0, 0, "No encontré la fila de encabezados. El CSV debe incluir PLU y Descripcion.")
        }
        fun findColumn(vararg aliases: String): Int {
            val targets = aliases.map(::norm)
            return headerNames.indexOfFirst { header -> targets.any { target -> header == target || header.startsWith(target) } }
        }
        val pluIdx = findColumn("PLU")
        val nameIdx = findColumn("Descripcion", "Nombre")
        val expiryIdx = findColumn("Fecha_Vencimiento", "Fecha Vencimiento", "Vencimiento")
        val qtyIdx = findColumn("Cantidad_Vencer", "Cantidad Vencer", "Cantidad")
        val startIdx = findColumn("DesdeCuando", "Desde Cuando", "FechaInicioMacro", "InicioMacro")
        val endIdx = findColumn("HastaCuando", "Hasta Cuando", "FechaFinMacro", "FinMacro")
        val percentIdx = findColumn("PorcentajeDescue", "PorcentajeDescuento", "Porcentaje Descuento", "Descuento")
        if (listOf(pluIdx, nameIdx, expiryIdx, qtyIdx, startIdx, endIdx, percentIdx).any { it < 0 }) {
            return MacroImportResult(0, 0, 0, "Faltan columnas. Se requieren PLU, Descripcion, Fecha_Vencimiento, Cantidad_Vencer, DesdeCuando, HastaCuando y PorcentajeDescue.")
        }
        fun cell(row: List<String>, index: Int): String = row.getOrNull(index).orEmpty().trim().trim('"', '\'')
        fun parseNumber(raw: String): Double? {
            val clean = raw.trim().replace("%", "").replace(" ", "")
            if (clean.isBlank()) return null
            // Cantidades y porcentajes del CSV son números enteros/decimales; admite coma decimal.
            return if (clean.contains(',') && !clean.contains('.')) clean.replace(',', '.').toDoubleOrNull()
            else clean.replace(",", "").toDoubleOrNull()
        }

        val allProducts = productDao.getAllRawProducts().toMutableList()
        val existingMacroRecords = macroDao.getAllMacroRecords().first().toMutableList()
        val recordsToInsert = mutableListOf<MacroRecordEntity>()
        var matchedCount = 0
        var createdCount = 0
        var processed = 0
        var skipped = 0
        // Un mismo archivo puede traer filas repetidas (por exportaciones, encabezados
        // repetidos o copias de Excel). Para cada PLU + vencimiento conservamos la última
        // fila válida encontrada: reimportar no debe crear un segundo lote.
        val rawDataLines = lines.drop(1)
        val uniqueRowsByLot = linkedMapOf<String, String>()
        var duplicateInputRows = 0
        rawDataLines.forEach { rawLine ->
            val cells = splitDelimitedLine(rawLine, delimiter)
            val rowPlu = cell(cells, pluIdx).trimStart('\uFEFF')
            val rowExpiry = DateUtils.parseAnyDateToIso(cell(cells, expiryIdx))
            if (rowPlu.isNotBlank() && rowExpiry != null) {
                val rowKey = "${normalizeProductKey(rowPlu)}|$rowExpiry"
                if (uniqueRowsByLot.containsKey(rowKey)) duplicateInputRows++
                uniqueRowsByLot[rowKey] = rawLine
            } else {
                // Se deja pasar al validador normal para contabilizar la fila como omitida.
                uniqueRowsByLot["invalid:${uniqueRowsByLot.size}:$rawLine"] = rawLine
            }
        }
        val dataLines = uniqueRowsByLot.values.toList()

        for (line in dataLines) {
            val row = splitDelimitedLine(line, delimiter)
            val plu = cell(row, pluIdx).trimStart('\uFEFF')
            val name = cell(row, nameIdx)
            val expiryIso = DateUtils.parseAnyDateToIso(cell(row, expiryIdx))
            val quantity = parseNumber(cell(row, qtyIdx))
            val startIso = DateUtils.parseAnyDateToIso(cell(row, startIdx))
            val endIso = DateUtils.parseAnyDateToIso(cell(row, endIdx))
            val percent = parseNumber(cell(row, percentIdx))

            // Nunca mover columnas por posición: cada dato se lee únicamente desde su encabezado.
            if (name.isBlank() || plu.isBlank() || expiryIso == null || quantity == null || quantity < 0 ||
                startIso == null || endIso == null || percent == null) {
                skipped++
                continue
            }

            // Primero busca por PLU. También repara registros de versiones anteriores que
            // guardaron erróneamente el PLU en barcode o toda la fila CSV en name.
            val normalizedPlu = normalizeProductKey(plu)
            val idMatches = allProducts.filter { candidate ->
                candidate.areaId == area.id && (
                    normalizeProductKey(candidate.plu) == normalizedPlu ||
                    normalizeProductKey(candidate.barcode) == normalizedPlu
                )
            }
            val candidates = if (idMatches.isNotEmpty()) idMatches else allProducts.filter {
                it.areaId == area.id && it.name.trim().equals(name.trim(), ignoreCase = true)
            }
            // Nunca mover un producto de otra área solo porque comparte el PLU.
            val existing = candidates.firstOrNull()
            val product = if (existing != null) {
                matchedCount++
                val repairedBarcode = if (normalizeProductKey(existing.barcode) == normalizedPlu) null else existing.barcode
                val updated = existing.copy(areaId = area.id, name = name, plu = plu, barcode = repairedBarcode)
                productDao.insertProduct(updated)
                val existingIndex = allProducts.indexOfFirst { it.id == existing.id }
                if (existingIndex >= 0) allProducts[existingIndex] = updated
                // Merge pre-existing duplicate catalog entries for the same PLU into one canonical product.
                candidates.filter { it.id != existing.id }.forEach { duplicate ->
                    val duplicateBatches = batchDao.getBatchesForProduct(duplicate.id).first()
                    duplicateBatches.forEach { duplicateBatch ->
                        val canonicalBatches = batchDao.getBatchesForProduct(updated.id).first()
                        val sameExpiry = canonicalBatches.firstOrNull { it.expiryDate == duplicateBatch.expiryDate }
                        if (sameExpiry == null) {
                            batchDao.updateBatch(duplicateBatch.copy(productId = updated.id))
                        } else {
                            // Keep one batch per expiry. Import will set its exact quantity below.
                            tombstones.add("batch", duplicateBatch.id)
                            batchDao.deleteBatchById(duplicateBatch.id)
                        }
                    }
                    tombstones.add("product", duplicate.id)
                    productDao.deleteProductById(duplicate.id)
                    allProducts.removeAll { it.id == duplicate.id }
                }
                updated
            } else {
                createdCount++
                ProductEntity(areaId = area.id, name = name, barcode = null, plu = plu).also {
                    productDao.insertProduct(it)
                    allProducts.add(it)
                }
            }

            // Los productos con devolución permanecen en el inventario, pero no se importan
            // en Macro ni se modifican sus lotes desde un archivo de Macro.
            if (product.hasReturn) {
                skipped++
                continue
            }

            // El vencimiento/cantidad pertenecen al lote. Las fechas de macro y el descuento
            // siempre se guardan en sus columnas propias. Actualizar también importaciones viejas.
            val productBatches = batchDao.getBatchesForProduct(product.id).first()
            val sameExpiryBatches = productBatches.filter { it.expiryDate == expiryIso }
            // Limpia duplicados históricos del mismo producto/vencimiento antes de actualizar.
            val sameExpiryBatch = sameExpiryBatches.maxByOrNull { it.createdAt }
            sameExpiryBatches.filter { it.id != sameExpiryBatch?.id }.forEach { duplicateBatch ->
                tombstones.add("batch", duplicateBatch.id)
                batchDao.deleteBatchById(duplicateBatch.id)
            }
            if (sameExpiryBatch != null) {
                if (sameExpiryBatch.quantity != quantity) batchDao.updateBatch(sameExpiryBatch.copy(quantity = quantity))
            } else {
                batchDao.insertBatch(BatchEntity(
                    productId = product.id,
                    batchNumber = "CSV-Macro-$plu-$expiryIso",
                    quantity = quantity,
                    expiryDate = expiryIso
                ))
            }

            // Si la versión anterior creó un registro mal formado, reutilizar su ID y corregirlo.
            val legacyExpiryToken = "${expiryIso.substring(8, 10)}-${expiryIso.substring(5, 7)}-${expiryIso.substring(0, 4)}"
            val previousRecord = (existingMacroRecords + recordsToInsert).firstOrNull { r ->
                r.areaId == area.id && (
                    (normalizeProductKey(r.plu) == normalizedPlu && r.expiryDate == expiryIso) ||
                    r.name.trim().startsWith("$plu,") || r.name.trim().startsWith("$plu ") ||
                    (r.name.trim().startsWith(name, ignoreCase = true) && r.name.contains(legacyExpiryToken))
                )
            }
            val record = MacroRecordEntity(
                id = previousRecord?.id ?: UUID.randomUUID().toString(),
                areaId = product.areaId,
                plu = plu,
                name = name,
                startDate = startIso,
                endDate = endIso,
                renewDate = DateUtils.calculateRenewDate(endIso, 2),
                expiryDate = expiryIso,
                quantity = quantity,
                discountPercent = percent,
                unmatched = false,
                updatedAt = System.currentTimeMillis()
            )
            recordsToInsert.removeAll { it.id == record.id }
            recordsToInsert.add(record)
            existingMacroRecords.removeAll { it.id == record.id }
            existingMacroRecords.add(record)
            processed++
        }
        if (recordsToInsert.isNotEmpty()) macroDao.insertMacroRecords(recordsToInsert)
        if (processed > 0) deduplicateMacroRecords()
        if (processed == 0) {
            return MacroImportResult(0, 0, 0, "No se importaron filas. Revisa que las fechas sean dd-MM-yyyy o yyyy-MM-dd y que cantidad y porcentaje sean números.")
        }
        val details = buildString {
            append("Importación correcta: $processed filas; $createdCount productos nuevos; $matchedCount productos vinculados.")
            if (skipped > 0) append(" Se omitieron $skipped filas por datos incompletos o productos con devolución.")
            if (duplicateInputRows > 0) append(" Se consolidaron $duplicateInputRows filas repetidas del CSV.")
        }
        return MacroImportResult(processed, matchedCount, createdCount, errorMessage = null, message = details)
    }

    suspend fun addProductsToMacro(
        products: List<ProductWithBatches>,
        startDate: String,
        endDate: String
    ): Int {
        val renewIso = DateUtils.calculateRenewDate(endDate, 2)
        val existingRecords = macroDao.getAllMacroRecords().first().toMutableList()
        val upserts = mutableListOf<MacroRecordEntity>()
        products.distinctBy { it.id }.filterNot { it.hasReturn }.forEach { p ->
            val batches = p.batches.filter { DateUtils.daysLeft(it.expiryDate) >= 0 }
            val rows = if (batches.isNotEmpty()) batches.map { batch ->
                Triple(batch.expiryDate, batch.quantity, batch.id)
            } else listOf(Triple(p.earliestExpiryDate, p.totalQuantity, ""))
            rows.forEach { (expiry, quantity, _) ->
                val key = normalizeProductKey(p.plu ?: p.barcode ?: p.name)
                val existing = (existingRecords + upserts).firstOrNull { r ->
                    r.areaId == p.areaId &&
                        normalizeProductKey(r.plu ?: r.name) == key &&
                        (r.expiryDate ?: "") == (expiry ?: "")
                }
                val record = MacroRecordEntity(
                    id = existing?.id ?: UUID.randomUUID().toString(),
                    areaId = p.areaId,
                    plu = p.plu ?: p.barcode,
                    name = p.name,
                    startDate = startDate,
                    endDate = endDate,
                    renewDate = renewIso,
                    expiryDate = expiry,
                    quantity = quantity,
                    discountPercent = existing?.discountPercent,
                    unmatched = false,
                    updatedAt = System.currentTimeMillis()
                )
                upserts.removeAll { it.id == record.id }
                upserts.add(record)
            }
        }
        if (upserts.isNotEmpty()) macroDao.insertMacroRecords(upserts)
        if (upserts.isNotEmpty()) deduplicateMacroRecords()
        return upserts.size
    }

    suspend fun updateMacroDiscount(id: String, percent: Double) {
        val record = macroDao.getAllMacroRecords().first().firstOrNull { it.id == id } ?: return
        macroDao.insertMacroRecord(record.copy(discountPercent = percent.coerceIn(10.0, 70.0), updatedAt = System.currentTimeMillis()))
    }

    suspend fun renewMacroRecord(id: String): Boolean {
        val record = macroDao.getAllMacroRecords().first().firstOrNull { it.id == id } ?: return false
        // No renovar una promoción para un lote cuyo vencimiento físico ya pasó.
        if (!record.expiryDate.isNullOrBlank() && DateUtils.daysLeft(record.expiryDate) < 0) {
            deleteMacroRecordById(id)
            return false
        }
        val today = java.time.LocalDate.now()
        val oldStart = record.startDate?.let { runCatching { java.time.LocalDate.parse(it) }.getOrNull() }
        val oldEnd = record.endDate?.let { runCatching { java.time.LocalDate.parse(it) }.getOrNull() }
        val duration = if (oldStart != null && oldEnd != null && !oldEnd.isBefore(oldStart))
            java.time.temporal.ChronoUnit.DAYS.between(oldStart, oldEnd).coerceAtLeast(1)
        else 7L
        // Al pulsar Renovar ahora se actualiza el mismo registro: no se crea un duplicado.
        // La nueva subida se registra hoy; la respuesta/descuento inicia en dos días.
        val newStart = today.plusDays(2)
        val newEnd = newStart.plusDays(duration)
        val newRenew = newEnd.minusDays(2)
        macroDao.insertMacroRecord(record.copy(
            startDate = newStart.toString(),
            endDate = newEnd.toString(),
            renewDate = newRenew.toString(),
            updatedAt = System.currentTimeMillis()
        ))
        return true
    }

    suspend fun deleteMacroRecordById(id: String) {
        val record = macroDao.getAllMacroRecords().first().firstOrNull { it.id == id }
        if (record != null && !record.expiryDate.isNullOrBlank() && DateUtils.daysLeft(record.expiryDate) < 0) {
            // Retirar de Macro también limpia el lote físico vencido vinculado a ese registro.
            // Si era el único lote, NO se elimina el producto: queda visible con stock 0.
            val matchingProducts = productDao.getAllProductsWithBatches().first().filter { p ->
                if (p.areaId != record.areaId) return@filter false
                val samePlu = !record.plu.isNullOrBlank() && (
                    normalizeProductKey(record.plu) == normalizeProductKey(p.plu) ||
                    normalizeProductKey(record.plu) == normalizeProductKey(p.barcode)
                )
                val sameName = record.name.trim().equals(p.name.trim(), ignoreCase = true)
                samePlu || sameName
            }
            matchingProducts.forEach { product ->
                product.batches.filter { it.expiryDate == record.expiryDate && DateUtils.daysLeft(it.expiryDate) < 0 }
                    .forEach { batch ->
                        tombstones.add("batch", batch.id)
                        batchDao.deleteBatchById(batch.id)
                    }
            }
        }
        tombstones.add("macro", id)
        macroDao.deleteById(id)
    }

    suspend fun clearMacroRecords(areaId: String? = null) {
        val records = macroDao.getAllMacroRecords().first().filter { areaId == null || it.areaId == areaId }
        records.forEach { tombstones.add("macro", it.id) }
        if (areaId != null) {
            macroDao.deleteByArea(areaId)
        } else {
            macroDao.clearAll()
        }
    }

    suspend fun exportBackupJson(): String {
        val allProducts = productDao.getAllProductsWithBatches().first()
        val array = JSONArray()

        for (p in allProducts) {
            val obj = JSONObject().apply {
                put("id", p.id)
                put("areaId", p.areaId)
                put("name", p.name)
                put("barcode", p.barcode ?: "")
                put("plu", p.plu ?: "")
                put("location", p.location)
                put("locationUpdatedAt", p.product.locationUpdatedAt)
                put("hasReturn", p.hasReturn)
                put("returnUpdatedAt", p.product.returnUpdatedAt)
                if (p.product.unitCost != null) put("unitCost", p.product.unitCost)
                put("createdAt", p.createdAt)

                val batchesArray = JSONArray()
                for (b in p.batches) {
                    val bObj = JSONObject().apply {
                        put("id", b.id)
                        put("batchNumber", b.batchNumber ?: "")
                        put("quantity", b.quantity)
                        put("expiryDate", b.expiryDate)
                        put("createdAt", b.createdAt)
                    }
                    batchesArray.put(bObj)
                }
                put("batches", batchesArray)
            }
            array.put(obj)
        }
        return array.toString(2)
    }

    suspend fun importBackupJson(jsonString: String): Boolean {
        return try {
            val array = JSONArray(jsonString)
            val productsToInsert = mutableListOf<ProductEntity>()
            val batchesToInsert = mutableListOf<BatchEntity>()

            for (i in 0 until array.length()) {
                val obj = array.getJSONObject(i)
                val productId = obj.optString("id", UUID.randomUUID().toString())
                val product = ProductEntity(
                    id = productId,
                    areaId = obj.optString("areaId", Area.LACTEOS.id),
                    name = obj.optString("name", "Producto"),
                    barcode = obj.optString("barcode").takeIf { it.isNotBlank() },
                    plu = obj.optString("plu").takeIf { it.isNotBlank() },
                    unitCost = if (obj.has("unitCost") && !obj.isNull("unitCost")) obj.optDouble("unitCost") else null,
                    location = obj.optString("location", ""),
                    locationUpdatedAt = obj.optLong("locationUpdatedAt", 0L),
                    hasReturn = obj.optBoolean("hasReturn", false),
                    returnUpdatedAt = obj.optLong("returnUpdatedAt", 0L),
                    createdAt = obj.optLong("createdAt", System.currentTimeMillis())
                )
                productsToInsert.add(product)

                if (obj.has("batches")) {
                    val bArray = obj.getJSONArray("batches")
                    for (j in 0 until bArray.length()) {
                        val bObj = bArray.getJSONObject(j)
                        val batch = BatchEntity(
                            id = bObj.optString("id", UUID.randomUUID().toString()),
                            productId = productId,
                            batchNumber = bObj.optString("batchNumber").takeIf { it.isNotBlank() },
                            quantity = bObj.optDouble("quantity", 1.0),
                            expiryDate = bObj.optString("expiryDate", DateUtils.todayIso()),
                            createdAt = bObj.optLong("createdAt", System.currentTimeMillis())
                        )
                        batchesToInsert.add(batch)
                    }
                } else {
                    // Backward-compatible con formato anterior plano (qty, date)
                    val legacyQty = obj.optDouble("qty", obj.optDouble("quantity", 1.0))
                    val legacyDate = obj.optString("date", obj.optString("expiry_date", DateUtils.todayIso()))
                    val batch = BatchEntity(
                        productId = productId,
                        quantity = legacyQty,
                        expiryDate = legacyDate
                    )
                    batchesToInsert.add(batch)
                }
            }

            if (productsToInsert.isNotEmpty()) {
                productDao.clearAllProducts()
                batchDao.clearAllBatches()
                productDao.insertProducts(productsToInsert)
                batchDao.insertBatches(batchesToInsert)
            }
            true
        } catch (e: Exception) {
            e.printStackTrace()
            false
        }
    }

    /**
     * Parsea el texto copiado de la hoja del CEDI (PLU/Código, Nombre opcional, Cantidad).
     * Cruza con el catálogo existente en el inventario para autocompletar nombres y códigos.
     */
    suspend fun parseCediText(areaId: String, text: String): CediParseResult {
        val lines = text.lines().map { it.trim() }.filter { it.isNotBlank() }
        val catalogProducts = if (areaId == Area.ADMIN.id) {
            productDao.getAllProductsWithBatches().first()
        } else {
            productDao.getProductsWithBatchesByArea(areaId).first()
        }

        val parsedItems = mutableListOf<CediParsedItem>()
        val errorRows = mutableListOf<String>()

        for (line in lines) {
            val delimiterRegex = Regex("[\\t;,|]")
            var tokens = line.split(delimiterRegex).map { it.trim() }.filter { it.isNotEmpty() }
            if (tokens.size < 2) {
                // Intentar separar por múltiples espacios (copiado desde texto plano o terminal)
                tokens = line.split(Regex("\\s{2,}")).map { it.trim() }.filter { it.isNotEmpty() }
            }

            if (tokens.isEmpty()) continue

            // Formatos comunes:
            // Caso 1 (2 columnas): [PLU_O_CODIGO, CANTIDAD] (ej. "43534 24" o "43534 \t 24")
            // Caso 2 (3 columnas): [PLU, NOMBRE, CANTIDAD]
            // Caso 3 (3 columnas): [CANTIDAD, PLU, NOMBRE]
            var code = ""
            var name = ""
            var quantity = 0.0

            if (tokens.size == 1) {
                // Solo un número o código sin cantidad, no se puede contar
                errorRows.add("Fila incompleta: $line")
                continue
            } else if (tokens.size == 2) {
                val firstNum = tokens[0].replace(',', '.').toDoubleOrNull()
                val secondNum = tokens[1].replace(',', '.').toDoubleOrNull()
                if (secondNum != null && secondNum > 0.0) {
                    code = tokens[0]
                    quantity = secondNum
                } else if (firstNum != null && firstNum > 0.0) {
                    quantity = firstNum
                    code = tokens[1]
                } else {
                    errorRows.add("No se detectó cantidad válida: $line")
                    continue
                }
            } else {
                // 3 o más columnas
                val lastNum = tokens.last().replace(',', '.').toDoubleOrNull()
                val firstNum = tokens.first().replace(',', '.').toDoubleOrNull()

                if (lastNum != null && lastNum > 0.0) {
                    quantity = lastNum
                    code = tokens[0]
                    name = tokens.subList(1, tokens.size - 1).joinToString(" ")
                } else if (firstNum != null && firstNum > 0.0) {
                    quantity = firstNum
                    code = tokens[1]
                    name = tokens.subList(2, tokens.size).joinToString(" ")
                } else {
                    // Buscar cualquier token que sea numérico para la cantidad (ej. decimal o entero)
                    val qtyIdx = tokens.indexOfLast { it.replace(',', '.').toDoubleOrNull() != null }
                    if (qtyIdx != -1) {
                        quantity = tokens[qtyIdx].replace(',', '.').toDouble()
                        val otherTokens = tokens.filterIndexed { index, _ -> index != qtyIdx }
                        code = otherTokens.firstOrNull() ?: ""
                        name = otherTokens.drop(1).joinToString(" ")
                    } else {
                        errorRows.add("Sin cantidad numérica: $line")
                        continue
                    }
                }
            }

            // Cruzar con catálogo
            val cleanCode = code.replace(Regex("[^0-9a-zA-Z]"), "")
            val match = catalogProducts.firstOrNull { p ->
                (!p.barcode.isNullOrBlank() && p.barcode.equals(cleanCode, ignoreCase = true)) ||
                        (!p.plu.isNullOrBlank() && p.plu.equals(cleanCode, ignoreCase = true)) ||
                        (!p.barcode.isNullOrBlank() && p.barcode.equals(code, ignoreCase = true)) ||
                        (!p.plu.isNullOrBlank() && p.plu.equals(code, ignoreCase = true)) ||
                        (name.isNotBlank() && p.name.contains(name, ignoreCase = true))
            }

            val finalName = if (match != null) match.name else (name.ifBlank { "Producto CEDI $code" })
            parsedItems.add(
                CediParsedItem(
                    pluOrBarcode = if (cleanCode.isNotBlank()) cleanCode else code,
                    name = finalName,
                    quantity = quantity,
                    isMatchedWithCatalog = match != null,
                    matchedCatalogName = match?.name,
                    matchedBarcode = match?.barcode,
                    matchedPlu = match?.plu
                )
            )
        }

        val totalUnits = parsedItems.sumOf { it.quantity }
        val unrecognized = parsedItems.count { !it.isMatchedWithCatalog }

        return CediParseResult(
            items = parsedItems,
            totalUnits = totalUnits,
            unrecognizedCount = unrecognized,
            errorRows = errorRows
        )
    }

    /**
     * Aplica la carga CEDI asignando los lotes correspondientes con la fecha de vencimiento verificada.
     */
    suspend fun applyCediArrival(
        areaId: String,
        items: List<CediParsedItem>,
        expiryDate: String
    ): Int {
        val targetArea = if (areaId == Area.ADMIN.id) Area.LACTEOS.id else areaId
        val catalog = productDao.getProductsWithBatchesByArea(targetArea).first()
        var savedCount = 0

        for (item in items) {
            val code = item.pluOrBarcode.trim()
            val existing = catalog.firstOrNull { p ->
                (!p.barcode.isNullOrBlank() && p.barcode.equals(code, ignoreCase = true)) ||
                        (!p.plu.isNullOrBlank() && p.plu.equals(code, ignoreCase = true)) ||
                        (item.matchedBarcode != null && !p.barcode.isNullOrBlank() && p.barcode.equals(item.matchedBarcode, ignoreCase = true)) ||
                        (item.matchedPlu != null && !p.plu.isNullOrBlank() && p.plu.equals(item.matchedPlu, ignoreCase = true))
            }

            val targetProductId = if (existing != null) {
                existing.id
            } else {
                val isBarcode = code.length >= 8
                val newProd = ProductEntity(
                    areaId = targetArea,
                    name = item.name,
                    barcode = if (isBarcode) code else item.matchedBarcode,
                    plu = if (!isBarcode) code else item.matchedPlu
                )
                productDao.insertProduct(newProd)
                newProd.id
            }

            addBatchToProduct(
                productId = targetProductId,
                quantity = item.quantity,
                expiryDate = expiryDate,
                batchNumber = "CEDI ${DateUtils.todayIso()}"
            )
            savedCount++
        }

        return savedCount
    }
}
