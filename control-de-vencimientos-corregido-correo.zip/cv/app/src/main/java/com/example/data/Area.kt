package com.example.data

enum class Area(val id: String, val displayName: String, val icon: String) {
    LACTEOS("lacteos", "Lácteos y embutidos", "🥛"),
    FRUVER("fruver", "Frutas y verduras", "🍎"),
    DULCES("dulces", "Harinas y dulces", "🥖"),
    GASEOSAS("gaseosas", "Gaseosas y snacks", "🥤"),
    OTROS("otros", "Otros", "📦"),
    BODEGA("bodega", "Bodega", "🏬"),
    ADMIN("admin", "Administrador (Todas)", "👑");

    companion object {
        fun fromId(id: String): Area {
            return entries.firstOrNull { it.id == id } ?: LACTEOS
        }

        val workAreas = listOf(LACTEOS, FRUVER, DULCES, GASEOSAS, OTROS, BODEGA)
    }
}
