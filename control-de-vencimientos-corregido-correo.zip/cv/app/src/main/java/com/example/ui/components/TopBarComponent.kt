package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.CropFree
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.LightMode
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.ViewAgenda
import androidx.compose.material.icons.filled.ViewCompact
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.Area

@Composable
fun TopBarComponent(
    currentArea: Area,
    inventoryProfileTitle: String,
    isSimpleMode: Boolean,
    isDarkTheme: Boolean,
    isAdminUnlocked: Boolean,
    syncStatus: String,
    onSyncNow: () -> Unit,
    onChangeInventory: () -> Unit,
    onAreaSelect: (Area) -> Unit,
    onLockAdmin: () -> Unit,
    onToggleSimpleMode: () -> Unit,
    onToggleTheme: () -> Unit,
    onOpenScanner: () -> Unit,
    onSendAlert: () -> Unit,
    onTriggerNotificationSound: () -> Unit,
    onOpenMacro: () -> Unit,
    onOpenReport: () -> Unit,
    onOpenBackup: () -> Unit,
    onOpenCediArrival: () -> Unit,
    modifier: Modifier = Modifier
) {
    var showMenu by remember { mutableStateOf(false) }
    var showAreaMenu by remember { mutableStateOf(false) }

    Surface(
        color = MaterialTheme.colorScheme.surface,
        tonalElevation = 2.dp,
        shadowElevation = 1.dp,
        modifier = modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .statusBarsPadding()
                .padding(horizontal = 14.dp, vertical = 8.dp)
                .testTag("app_header")
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Left title. Store-specific branding intentionally removed.
                Column {
                    if (currentArea == Area.ADMIN && isAdminUnlocked) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.15f))
                                    .clickable(onClick = onLockAdmin)
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                            ) {
                                Text(
                                    text = "Admin 🔓",
                                    fontSize = 8.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.primary
                                )
                            }
                        }
                    }
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(7.dp)
                    ) {
                        Text(
                            text = "Vencimientos",
                            fontSize = 17.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface,
                            letterSpacing = (-0.3).sp
                        )
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = MaterialTheme.colorScheme.secondaryContainer
                        ) {
                            Text(
                                text = if (isAdminUnlocked && currentArea == Area.ADMIN) "ADMIN" else inventoryProfileTitle.uppercase(),
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp),
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSecondaryContainer,
                                maxLines = 1
                            )
                        }
                    }
                }

                // Right Controls
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    // Area Selector Pill
                    Box {
                        Surface(
                            shape = RoundedCornerShape(20.dp),
                            color = MaterialTheme.colorScheme.surfaceVariant,
                            modifier = Modifier
                                .clickable { showAreaMenu = true }
                                .testTag("area_selector_btn")
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.padding(horizontal = 9.dp, vertical = 6.dp)
                            ) {
                                Text(text = currentArea.icon, fontSize = 11.sp)
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = currentArea.displayName.take(11),
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Icon(
                                    imageVector = Icons.Default.ArrowDropDown,
                                    contentDescription = null,
                                    modifier = Modifier.size(14.dp),
                                    tint = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }

                        DropdownMenu(
                            expanded = showAreaMenu,
                            onDismissRequest = { showAreaMenu = false },
                            modifier = Modifier.background(MaterialTheme.colorScheme.surface)
                        ) {
                            Area.entries.forEach { area ->
                                val isRestrictedAdmin = area == Area.ADMIN && !isAdminUnlocked
                                DropdownMenuItem(
                                    text = {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Text("${area.icon} ${area.displayName}", fontSize = 12.sp)
                                            if (isRestrictedAdmin) {
                                                Spacer(modifier = Modifier.width(6.dp))
                                                Icon(
                                                    imageVector = Icons.Default.Lock,
                                                    contentDescription = "Requiere autenticación",
                                                    tint = MaterialTheme.colorScheme.primary,
                                                    modifier = Modifier.size(13.dp)
                                                )
                                            }
                                        }
                                    },
                                    onClick = {
                                        onAreaSelect(area)
                                        showAreaMenu = false
                                    }
                                )
                            }
                        }
                    }

                    // Scanner button direct shortcut
                    IconButton(
                        onClick = onOpenScanner,
                        modifier = Modifier
                            .size(32.dp)
                            .clip(CircleShape)
                            .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.12f))
                            .testTag("top_bar_scanner_btn")
                    ) {
                        Icon(
                            imageVector = Icons.Default.CropFree,
                            contentDescription = "Escanear",
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(17.dp)
                        )
                    }

                    // Overflow Menu
                    Box {
                        IconButton(
                            onClick = { showMenu = true },
                            modifier = Modifier
                                .size(32.dp)
                                .clip(CircleShape)
                                .testTag("overflow_menu_btn")
                        ) {
                            Icon(
                                imageVector = Icons.Default.MoreVert,
                                contentDescription = "Opciones",
                                tint = MaterialTheme.colorScheme.onSurface,
                                modifier = Modifier.size(18.dp)
                            )
                        }

                        DropdownMenu(
                            expanded = showMenu,
                            onDismissRequest = { showMenu = false },
                            modifier = Modifier.background(MaterialTheme.colorScheme.surface)
                        ) {
                            DropdownMenuItem(
                                leadingIcon = {
                                    Icon(
                                        if (isDarkTheme) Icons.Default.LightMode else Icons.Default.DarkMode,
                                        contentDescription = null,
                                        modifier = Modifier.size(16.dp)
                                    )
                                },
                                text = { Text(if (isDarkTheme) "Modo claro" else "Modo oscuro", fontSize = 12.sp) },
                                onClick = {
                                    onToggleTheme()
                                    showMenu = false
                                }
                            )

                            DropdownMenuItem(
                                leadingIcon = {
                                    Icon(
                                        if (isSimpleMode) Icons.Default.ViewAgenda else Icons.Default.ViewCompact,
                                        contentDescription = null,
                                        modifier = Modifier.size(16.dp)
                                    )
                                },
                                text = { Text(if (isSimpleMode) "Vista completa" else "Vista simple", fontSize = 12.sp) },
                                onClick = {
                                    onToggleSimpleMode()
                                    showMenu = false
                                }
                            )

                            DropdownMenuItem(
                                text = { Text("Cambiar inventario / perfil", fontSize = 12.sp) },
                                onClick = {
                                    showMenu = false
                                    onChangeInventory()
                                }
                            )

                            DropdownMenuItem(
                                text = { Text("Sincronizar inventario", fontSize = 12.sp) },
                                onClick = {
                                    onSyncNow()
                                    showMenu = false
                                }
                            )

                            if (isAdminUnlocked && currentArea == Area.ADMIN) {
                                DropdownMenuItem(
                                    leadingIcon = {
                                        Icon(Icons.Default.Lock, contentDescription = null, modifier = Modifier.size(16.dp))
                                    },
                                    text = { Text("Cerrar sesión Administrador", fontSize = 12.sp) },
                                    onClick = {
                                        onLockAdmin()
                                        showMenu = false
                                    }
                                )
                            }
                        }
                    }
                }
            }
            Text(
                text = syncStatus,
                fontSize = 9.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(start = 2.dp, top = 3.dp)
            )
        }
    }
}
