package com.example.data

import androidx.room.Embedded
import androidx.room.Relation
import com.example.util.DateUtils

data class ProductWithBatches(
    @Embedded
    val product: ProductEntity,
    @Relation(
        parentColumn = "id",
        entityColumn = "productId"
    )
    val batches: List<BatchEntity> = emptyList()
) {
    val id: String get() = product.id
    val areaId: String get() = product.areaId
    val name: String get() = product.name
    val barcode: String? get() = product.barcode
    val plu: String? get() = product.plu
    val createdAt: Long get() = product.createdAt

    val totalQuantity: Double
        get() = batches.sumOf { it.quantity }

    val formattedTotalQuantity: String
        get() = com.example.util.QuantityFormatter.format(totalQuantity)

    val sortedBatches: List<BatchEntity>
        get() = batches.sortedBy { it.expiryDate }

    val earliestExpiryDate: String?
        get() = sortedBatches.firstOrNull()?.expiryDate

    val minDaysLeft: Long?
        get() = earliestExpiryDate?.let { DateUtils.daysLeft(it) }

    val hasExpiredBatch: Boolean
        get() = batches.any { DateUtils.daysLeft(it.expiryDate) < 0 }

    val hasSoonBatch: Boolean
        get() = batches.any { DateUtils.daysLeft(it.expiryDate) in 0..30 }
}
