package com.example.data

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface BatchDao {
    @Query("SELECT * FROM batches WHERE productId = :productId ORDER BY expiryDate ASC")
    fun getBatchesForProduct(productId: String): Flow<List<BatchEntity>>

    @Query("SELECT * FROM batches ORDER BY expiryDate ASC")
    fun getAllBatches(): Flow<List<BatchEntity>>

    @Query("SELECT * FROM batches WHERE productId = :productId ORDER BY expiryDate ASC")
    suspend fun getBatchesForProductDirect(productId: String): List<BatchEntity>

    @Query("SELECT * FROM batches WHERE id = :id LIMIT 1")
    suspend fun getBatchById(id: String): BatchEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertBatch(batch: BatchEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertBatches(batches: List<BatchEntity>)

    @Update
    suspend fun updateBatch(batch: BatchEntity)

    @Delete
    suspend fun deleteBatch(batch: BatchEntity)

    @Query("DELETE FROM batches WHERE id = :id")
    suspend fun deleteBatchById(id: String)

    @Query("DELETE FROM batches WHERE id IN (:ids)")
    suspend fun deleteBatchesByIds(ids: List<String>)

    @Query("DELETE FROM batches WHERE productId = :productId")
    suspend fun deleteBatchesByProductId(productId: String)

    @Query("DELETE FROM batches")
    suspend fun clearAllBatches()

    @Query("SELECT COUNT(*) FROM batches")
    suspend fun getBatchCount(): Int
}
