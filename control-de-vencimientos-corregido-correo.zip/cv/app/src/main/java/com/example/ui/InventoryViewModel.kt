package com.example.ui

import android.app.Application
import android.content.Context
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.Area
import com.example.data.BatchEntity
import com.example.data.CediParsedItem
import com.example.data.CediParseResult
import com.example.data.InventoryRepository
import com.example.data.AppDatabase
import com.example.data.ProductRelationEntity
import com.example.data.AisleEntryEntity
import com.example.data.RelationsAndAisleRepository
import com.example.data.MacroRecordEntity
import com.example.data.MultiScanItem
import com.example.data.ProductWithBatches
import com.example.data.SupabaseAdminRepository
import com.example.data.AdminOfflineVerifier
import com.example.data.SupabaseSyncRepository
import com.example.data.CloudAdminSession
import com.example.data.CloudInventoryUser
import com.example.data.CloudInventoryProduct
import com.example.data.CloudDeviceInvite
import com.example.data.CloudDeviceBinding
import com.example.profile.InventoryProfile
import com.example.util.DateUtils
import com.example.util.NotificationHelper
import com.example.util.QuantityFormatter
import com.example.worker.ExpiryNotificationWorker
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.debounce
import kotlinx.coroutines.flow.drop
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

class InventoryViewModel(application: Application) : AndroidViewModel(application) {
    private val repository = InventoryRepository(application)
    private val relationsAisleRepository = RelationsAndAisleRepository(AppDatabase.getInstance(application))
    private val _productRelations = MutableStateFlow<List<ProductRelationEntity>>(emptyList())
    val productRelations: StateFlow<List<ProductRelationEntity>> = _productRelations.asStateFlow()
    private val _aisleEntries = MutableStateFlow<List<AisleEntryEntity>>(emptyList())
    val aisleEntries: StateFlow<List<AisleEntryEntity>> = _aisleEntries.asStateFlow()
    private val supabaseAdminRepository = SupabaseAdminRepository()
    private val adminOfflineVerifier = AdminOfflineVerifier(application)
    private val supabaseSyncRepository = SupabaseSyncRepository(application, repository)
    private val httpClient = OkHttpClient.Builder()
        .followRedirects(true)
        .followSslRedirects(true)
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(25, TimeUnit.SECONDS)
        .writeTimeout(20, TimeUnit.SECONDS)
        .build()

    private val webhookUrl = "https://script.google.com/macros/s/AKfycbzIcUoVT0SnCmR3K52odcxzkr_N4D_De7oXM1RA21d6vrWk1C0igTJdlYMtze95fXG9/exec"

    private val _currentArea = MutableStateFlow(Area.LACTEOS)
    val currentArea: StateFlow<Area> = _currentArea.asStateFlow()

    private val simpleModePrefs = application.getSharedPreferences("app_preferences", android.content.Context.MODE_PRIVATE)
    // La primera apertura usa modo sencillo; después se conserva la elección del usuario.
    private val _isSimpleMode = MutableStateFlow(simpleModePrefs.getBoolean("simple_mode", true))
    val isSimpleMode: StateFlow<Boolean> = _isSimpleMode.asStateFlow()

    private val _isDarkTheme = MutableStateFlow(true)
    val isDarkTheme: StateFlow<Boolean> = _isDarkTheme.asStateFlow()

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _filterStatus = MutableStateFlow("ALL") // "ALL", "SOON", "EXPIRED", "MACRO"
    val filterStatus: StateFlow<String> = _filterStatus.asStateFlow()

    // Form inputs
    val editingProductId = MutableStateFlow<String?>(null)
    val editingBatchId = MutableStateFlow<String?>(null)
    val barcodeInput = MutableStateFlow("")
    val pluInput = MutableStateFlow("")
    val nameInput = MutableStateFlow("")
    val locationInput = MutableStateFlow("")
    val quantityInput = MutableStateFlow("")
    val unitCostInput = MutableStateFlow("")
    val expiryDateInput = MutableStateFlow(DateUtils.todayIso())
    val formError = MutableStateFlow<String?>(null)

    // Modals
    val showScannerModal = MutableStateFlow(false)
    val showCediModal = MutableStateFlow(false)
    val showMacroImportModal = MutableStateFlow(false)
    val showBackupModal = MutableStateFlow(false)
    val showReportModal = MutableStateFlow(false)
    val showAdminAuthDialog = MutableStateFlow(false)
    private val _adminAuthLoading = MutableStateFlow(false)
    val adminAuthLoading: StateFlow<Boolean> = _adminAuthLoading.asStateFlow()
    private val _adminAuthError = MutableStateFlow<String?>(null)
    val adminAuthError: StateFlow<String?> = _adminAuthError.asStateFlow()

    // Status toast
    private val _toastMessage = MutableStateFlow<String?>(null)
    val toastMessage: StateFlow<String?> = _toastMessage.asStateFlow()

    private val _syncStatus = MutableStateFlow("Sincronización pendiente")
    val syncStatus: StateFlow<String> = _syncStatus.asStateFlow()
    private val syncMutex = kotlinx.coroutines.sync.Mutex()

    private val _isSendingAlert = MutableStateFlow(false)
    val isSendingAlert: StateFlow<Boolean> = _isSendingAlert.asStateFlow()

    // Admin authorization state
    private val _isAdminUnlocked = MutableStateFlow(false)
    private var pendingAdminArea: Area? = null
    val isAdminUnlocked: StateFlow<Boolean> = _isAdminUnlocked.asStateFlow()
    private val _cloudAdminSession = MutableStateFlow<CloudAdminSession?>(null)
    val cloudAdminSession: StateFlow<CloudAdminSession?> = _cloudAdminSession.asStateFlow()
    private val _cloudUsers = MutableStateFlow<List<CloudInventoryUser>>(emptyList())
    val cloudUsers: StateFlow<List<CloudInventoryUser>> = _cloudUsers.asStateFlow()
    private val _selectedCloudUser = MutableStateFlow<CloudInventoryUser?>(null)
    val selectedCloudUser: StateFlow<CloudInventoryUser?> = _selectedCloudUser.asStateFlow()
    private val _cloudProducts = MutableStateFlow<List<CloudInventoryProduct>>(emptyList())
    val cloudProducts: StateFlow<List<CloudInventoryProduct>> = _cloudProducts.asStateFlow()
    private val _deviceInvite = MutableStateFlow<CloudDeviceInvite?>(null)
    val deviceInvite: StateFlow<CloudDeviceInvite?> = _deviceInvite.asStateFlow()
    private val _deviceBindings = MutableStateFlow<List<CloudDeviceBinding>>(emptyList())
    val deviceBindings: StateFlow<List<CloudDeviceBinding>> = _deviceBindings.asStateFlow()
    private val _cloudAdminMessage = MutableStateFlow<String?>(null)
    val cloudAdminMessage: StateFlow<String?> = _cloudAdminMessage.asStateFlow()
    private val _cloudAdminLoading = MutableStateFlow(false)
    val cloudAdminLoading: StateFlow<Boolean> = _cloudAdminLoading.asStateFlow()

    // Dynamic products with batches based on current area
    private val _areaProducts = MutableStateFlow<List<ProductWithBatches>>(emptyList())
    val areaProducts: StateFlow<List<ProductWithBatches>> = _areaProducts.asStateFlow()

    private val _allProducts = MutableStateFlow<List<ProductWithBatches>>(emptyList())
    val allProducts: StateFlow<List<ProductWithBatches>> = _allProducts.asStateFlow()

    private val _macroRecords = MutableStateFlow<List<MacroRecordEntity>>(emptyList())
    val macroRecords: StateFlow<List<MacroRecordEntity>> = _macroRecords.asStateFlow()

    // Selected batch IDs for multi-select delete
    private val _selectedBatchIds = MutableStateFlow<Set<String>>(emptySet())
    val selectedBatchIds: StateFlow<Set<String>> = _selectedBatchIds.asStateFlow()

    // Detected existing product for the current barcode / PLU in the form
    val existingProductMatch: StateFlow<ProductWithBatches?> = combine(
        _areaProducts,
        barcodeInput,
        pluInput,
        editingProductId
    ) { products, barcode, plu, editProdId ->
        if (editProdId != null) {
            products.firstOrNull { it.id == editProdId }
        } else {
            val b = barcode.trim()
            val p = plu.trim()
            if (b.isEmpty() && p.isEmpty()) null
            else {
                products.firstOrNull { item ->
                    (b.isNotEmpty() && item.barcode?.equals(b, ignoreCase = true) == true) ||
                    (p.isNotEmpty() && item.plu?.equals(p, ignoreCase = true) == true)
                }
            }
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    init {
        viewModelScope.launch { relationsAisleRepository.observeRelations().collect { _productRelations.value = it } }
        viewModelScope.launch { relationsAisleRepository.observeAisle().collect { _aisleEntries.value = it } }
        viewModelScope.launch {
            repository.getAllProducts().collect { _allProducts.value = it }
        }
        // Initialize the selected Room inventory once. Both startup sync and the local-change
        // observer wait for this signal, but run in independent sibling jobs: a cancelled first
        // network attempt must not permanently disable automatic synchronization for this VM.
        val inventoryReady = CompletableDeferred<Unit>()
        viewModelScope.launch {
            try {
                repository.initializeIfNeeded()
                loadDataForCurrentArea()
            } finally {
                inventoryReady.complete(Unit)
            }
        }
        viewModelScope.launch {
            inventoryReady.await()
            syncInventory(showSuccess = false)
        }
        viewModelScope.launch {
            inventoryReady.await()
            repository.getAllProducts().drop(1).debounce(1800).collect {
                syncInventory(showSuccess = false)
            }
        }
    }


    fun saveProductRelation(id: String?, parentId: String, childId: String, units: Int) {
        viewModelScope.launch {
            runCatching { relationsAisleRepository.saveRelation(id, parentId, childId, units) }
                .onSuccess { showToast("Relación guardada") }
                .onFailure { showToast(it.message ?: "No se pudo guardar la relación") }
        }
    }

    fun deleteProductRelation(id: String) {
        viewModelScope.launch {
            runCatching { relationsAisleRepository.deleteRelation(id) }
                .onSuccess { showToast("Relación eliminada; los productos siguen en el inventario") }
                .onFailure { showToast(it.message ?: "No se pudo eliminar la relación") }
        }
    }

    fun convertRelatedProducts(relationId: String, sourceBatchId: String, quantity: Int, parentToChild: Boolean, onResult: (String?) -> Unit) {
        viewModelScope.launch {
            val result = runCatching { relationsAisleRepository.convert(relationId, sourceBatchId, quantity, parentToChild) }
            result.onSuccess { showToast(it); onResult(null) }
                .onFailure { onResult(it.message ?: "No se pudo convertir el lote") }
        }
    }

    fun updateProductLocation(productId: String, location: String) {
        viewModelScope.launch {
            runCatching { repository.updateProductLocation(productId, location) }
                .onSuccess { showToast("Ubicación actualizada") }
                .onFailure { showToast(it.message ?: "No se pudo actualizar la ubicación") }
        }
    }

    fun addProductToAisle(productId: String, batchId: String?, quantity: Double) {
        viewModelScope.launch {
            runCatching { relationsAisleRepository.addToAisle(productId, batchId, quantity) }
                .onSuccess { showToast("Producto actualizado en Mi pasillo") }
                .onFailure { showToast(it.message ?: "No se pudo agregar al pasillo") }
        }
    }

    fun updateAisleEntry(id: String, quantity: Double? = null, status: String? = null) {
        viewModelScope.launch {
            runCatching { relationsAisleRepository.updateAisle(id, quantity, status) }
                .onSuccess { showToast("Cambio guardado") }
                .onFailure { showToast(it.message ?: "No se pudo guardar el cambio") }
        }
    }

    fun removeAisleEntry(id: String) {
        viewModelScope.launch {
            runCatching { relationsAisleRepository.removeFromAisle(id) }
                .onSuccess { showToast("Retirado de Mi pasillo; el inventario general no se modificó") }
                .onFailure { showToast(it.message ?: "No se pudo retirar") }
        }
    }

    fun syncInventoryNow() {
        viewModelScope.launch { syncInventory(showSuccess = true) }
    }

    private suspend fun syncInventory(showSuccess: Boolean) = syncMutex.withLock {
        try {
            _syncStatus.value = "Sincronizando…"
            val result = withContext(Dispatchers.IO) { supabaseSyncRepository.syncInventory() }
            _syncStatus.value = "Nube sincronizada"
            if (showSuccess) showToast(result.message)
        } catch (cancelled: CancellationException) {
            // A cancelled ViewModel/lifecycle job is not a connectivity failure. Show a useful
            // status instead of the raw "Job was cancelled" message, then preserve cancellation.
            _syncStatus.value = "Sincronización interrumpida; puedes volver a intentarlo"
            throw cancelled
        } catch (e: Exception) {
            _syncStatus.value = "Sin sincronizar; datos guardados en este dispositivo"
            if (showSuccess) showToast(e.message ?: "No se pudo sincronizar. El inventario local sigue disponible.")
        }
    }

    private fun loadDataForCurrentArea() {
        viewModelScope.launch {
            repository.getProducts(_currentArea.value).collect { list ->
                _areaProducts.value = list
            }
        }
        viewModelScope.launch {
            repository.getMacroRecords(_currentArea.value).collect { list ->
                _macroRecords.value = list
            }
        }
    }

    fun requestAreaChange(targetArea: Area) {
        if (targetArea == Area.ADMIN && !_isAdminUnlocked.value) {
            pendingAdminArea = targetArea
            showAdminAuthDialog.value = true
        } else {
            setArea(targetArea)
        }
    }

    fun setArea(newArea: Area) {
        _currentArea.value = newArea
        resetForm()
        _selectedBatchIds.value = emptySet()
        loadDataForCurrentArea()
    }

    fun toggleSimpleMode() {
        val newValue = !_isSimpleMode.value
        _isSimpleMode.value = newValue
        simpleModePrefs.edit().putBoolean("simple_mode", newValue).apply()
    }

    fun toggleTheme() {
        _isDarkTheme.value = !_isDarkTheme.value
    }

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun setFilterStatus(status: String) {
        _filterStatus.value = status
    }

    fun signInAndUnlockAdmin(password: String) {
        if (password.isBlank()) {
            _adminAuthError.value = "Introduce la contraseña de administrador."
            return
        }
        if (_adminAuthLoading.value) return
        _adminAuthError.value = null
        viewModelScope.launch {
            _adminAuthLoading.value = true
            try {
                val session = withContext(Dispatchers.IO) {
                    supabaseAdminRepository.signInAsAdmin(password)
                }
                _cloudAdminSession.value = session
                // Cache a device-bound verifier only after the server accepts the password.
                withContext(Dispatchers.IO) { adminOfflineVerifier.rememberAfterOnlineSuccess(password) }
                _isAdminUnlocked.value = true
                showAdminAuthDialog.value = false
                pendingAdminArea?.let { setArea(it) }
                pendingAdminArea = null
                _cloudAdminMessage.value = "Sesión de administrador autenticada con Supabase."
                showToast("Administrador autenticado")
            } catch (e: Exception) {
                val isConnectivityFailure = e is java.net.UnknownHostException ||
                    e is java.net.SocketTimeoutException || e is java.net.ConnectException ||
                    e is java.io.IOException
                val offlineMatch = if (isConnectivityFailure) {
                    withContext(Dispatchers.IO) { adminOfflineVerifier.canUnlockOffline(password) }
                } else false
                if (offlineMatch) {
                    // Local-only unlock: deliberately do not create a CloudAdminSession.
                    _cloudAdminSession.value = null
                    _isAdminUnlocked.value = true
                    showAdminAuthDialog.value = false
                    pendingAdminArea?.let { setArea(it) }
                    pendingAdminArea = null
                    _cloudAdminMessage.value = "Modo administrador sin conexión. Las funciones que requieren servidor están desactivadas hasta recuperar internet."
                    showToast("Administrador local · sin conexión")
                } else {
                    _adminAuthError.value = when {
                        isConnectivityFailure -> "Sin conexión y este dispositivo no tiene una validación local previa. Conéctate una vez e inicia sesión para habilitar el acceso sin internet."
                        else -> e.message ?: "No se pudo autenticar el administrador."
                    }
                }
            } finally {
                _adminAuthLoading.value = false
            }
        }
    }

    fun generateDeviceInvite(workspaceId: String) {
        val session = _cloudAdminSession.value ?: run {
            _cloudAdminMessage.value = "Conéctate e inicia sesión en línea como administrador para generar códigos."
            return
        }
        _deviceInvite.value = null
        viewModelScope.launch {
            _cloudAdminLoading.value = true
            try {
                val invite = withContext(Dispatchers.IO) {
                    supabaseAdminRepository.createDeviceInvite(session, workspaceId)
                }
                _deviceInvite.value = invite
                _cloudAdminMessage.value = "Código creado para ${invite.workspaceName}. Caduca en 10 minutos y solo puede usarse una vez."
            } catch (e: Exception) {
                _cloudAdminMessage.value = e.message ?: "No se pudo generar el código de vinculación."
            } finally {
                _cloudAdminLoading.value = false
            }
        }
    }

    fun refreshDeviceBindings() {
        val session = _cloudAdminSession.value ?: run {
            _cloudAdminMessage.value = "La consulta de dispositivos requiere una sesión administrativa en línea."
            return
        }
        viewModelScope.launch {
            _cloudAdminLoading.value = true
            try {
                _deviceBindings.value = withContext(Dispatchers.IO) {
                    supabaseAdminRepository.loadDeviceBindings(session)
                }
                _cloudAdminMessage.value = "Lista de dispositivos actualizada."
            } catch (e: Exception) {
                _cloudAdminMessage.value = e.message ?: "No se pudieron consultar los dispositivos."
            } finally {
                _cloudAdminLoading.value = false
            }
        }
    }

    fun revokeDeviceBinding(binding: CloudDeviceBinding) {
        val session = _cloudAdminSession.value ?: run {
            _cloudAdminMessage.value = "La revocación requiere una sesión administrativa en línea."
            return
        }
        if (binding.revokedAt != null) return
        viewModelScope.launch {
            _cloudAdminLoading.value = true
            try {
                withContext(Dispatchers.IO) {
                    supabaseAdminRepository.revokeDeviceBinding(session, binding.deviceHash)
                }
                _deviceBindings.value = withContext(Dispatchers.IO) {
                    supabaseAdminRepository.loadDeviceBindings(session)
                }
                _cloudAdminMessage.value = "Acceso revocado. El dispositivo dejará de sincronizar cuando vuelva a consultar al servidor."
            } catch (e: Exception) {
                _cloudAdminMessage.value = e.message ?: "No se pudo revocar el dispositivo."
            } finally {
                _cloudAdminLoading.value = false
            }
        }
    }

    fun refreshCloudUsers() {
        val session = _cloudAdminSession.value ?: run { _cloudAdminMessage.value = "Inicia sesión como administrador primero."; return }
        viewModelScope.launch {
            _cloudAdminLoading.value = true
            try {
                _cloudUsers.value = withContext(Dispatchers.IO) { supabaseAdminRepository.loadUsers(session) }
                _cloudAdminMessage.value = "Inventarios actualizados desde Supabase."
            } catch (e: Exception) { _cloudAdminMessage.value = e.message ?: "No se pudieron actualizar los usuarios." }
            finally { _cloudAdminLoading.value = false }
        }
    }

    fun selectCloudUser(user: CloudInventoryUser) {
        val session = _cloudAdminSession.value ?: return
        _selectedCloudUser.value = user
        viewModelScope.launch {
            _cloudAdminLoading.value = true
            _cloudProducts.value = emptyList()
            try {
                _cloudProducts.value = withContext(Dispatchers.IO) { supabaseAdminRepository.loadProducts(session, user.id) }
                _cloudAdminMessage.value = "Inventario cargado: ${user.name}."
            } catch (e: Exception) { _cloudAdminMessage.value = e.message ?: "No se pudo cargar este inventario." }
            finally { _cloudAdminLoading.value = false }
        }
    }

    fun cancelAdminAuth() {
        if (_adminAuthLoading.value) return
        pendingAdminArea = null
        _adminAuthError.value = null
        showAdminAuthDialog.value = false
    }

    fun lockAdmin() {
        pendingAdminArea = null
        showCediModal.value = false
        showMacroImportModal.value = false
        _isAdminUnlocked.value = false
        _cloudAdminSession.value = null
        _cloudUsers.value = emptyList()
        _cloudProducts.value = emptyList()
        _selectedCloudUser.value = null
        _deviceInvite.value = null
        _deviceBindings.value = emptyList()
        _cloudAdminMessage.value = null
        _adminAuthError.value = null
        if (_currentArea.value == Area.ADMIN) setArea(Area.LACTEOS)
        showToast("Sesión de administración cerrada")
    }

    fun onBarcodeChanged(code: String) {
        barcodeInput.value = code
        formError.value = null
        if (code.isNotBlank() && nameInput.value.isBlank()) {
            viewModelScope.launch {
                val match = repository.findAutoFillMatch(barcode = code, plu = null, name = null)
                if (match != null) {
                    nameInput.value = match.name
                    if (locationInput.value.isBlank()) locationInput.value = match.location
                    if (pluInput.value.isBlank() && !match.plu.isNullOrBlank()) {
                        pluInput.value = match.plu ?: ""
                    }
                    if (unitCostInput.value.isBlank()) unitCostInput.value = match.product.unitCost?.let { QuantityFormatter.format(it) } ?: ""
                }
            }
        }
    }

    fun onPluChanged(plu: String) {
        pluInput.value = plu
        formError.value = null
        if (plu.isNotBlank() && nameInput.value.isBlank()) {
            viewModelScope.launch {
                val match = repository.findAutoFillMatch(barcode = null, plu = plu, name = null)
                if (match != null) {
                    nameInput.value = match.name
                    if (locationInput.value.isBlank()) locationInput.value = match.location
                    if (barcodeInput.value.isBlank() && !match.barcode.isNullOrBlank()) {
                        barcodeInput.value = match.barcode ?: ""
                    }
                    if (unitCostInput.value.isBlank()) unitCostInput.value = match.product.unitCost?.let { QuantityFormatter.format(it) } ?: ""
                }
            }
        }
    }

    fun onNameChanged(name: String) {
        nameInput.value = name
        formError.value = null
    }

    fun saveProduct() {
        val name = nameInput.value.trim()
        val barcode = barcodeInput.value.trim()
        val plu = pluInput.value.trim()
        val location = locationInput.value.trim()
        val qtyStr = quantityInput.value.trim()
        val unitCostStr = unitCostInput.value.trim().replace(",", ".")
        val date = expiryDateInput.value.trim()

        if (name.isEmpty()) {
            formError.value = "Ingresa el nombre del producto."
            return
        }

        val qty = QuantityFormatter.parseQuantity(qtyStr)
        if (qty == null) {
            formError.value = "La cantidad o peso debe ser un número mayor a 0 (ej. 12 o 0.252)."
            return
        }

        val unitCost = if (unitCostStr.isBlank()) null else unitCostStr.toDoubleOrNull()
        if (unitCostStr.isNotBlank() && (unitCost == null || unitCost < 0.0)) {
            formError.value = "El costo unitario debe ser un valor válido en pesos colombianos."
            return
        }

        if (!DateUtils.isValidIsoDate(date)) {
            formError.value = "La fecha debe tener formato AAAA-MM-DD."
            return
        }

        viewModelScope.launch {
            val isEditing = editingBatchId.value != null || editingProductId.value != null
            // Al crear un producto nuevo, intenta conservar el área de un código ya conocido;
            // si no existe, clasifica por nombre. La selección actual de pantalla no lo limita.
            val existingByCode = if (!isEditing) {
                repository.findExistingProduct(null, barcode.ifEmpty { null }, plu.ifEmpty { null })
            } else null
            val destinationArea = if (isEditing) {
                _currentArea.value
            } else if (existingByCode != null) {
                Area.fromId(existingByCode.areaId)
            } else {
                inferAreaFromProductName(name)
            }

            repository.saveProductWithBatch(
                areaId = destinationArea.id,
                name = name,
                barcode = barcode.ifEmpty { null },
                plu = plu.ifEmpty { null },
                quantity = qty,
                expiryDate = date,
                editingProductId = editingProductId.value,
                editingBatchId = editingBatchId.value,
                unitCost = unitCost,
                location = location
            )

            val isExistingProduct = existingProductMatch.value != null && !isEditing
            resetForm()

            if (isEditing) {
                showToast("✅ Lote actualizado con éxito")
            } else if (isExistingProduct) {
                showToast("✅ Nuevo lote guardado en ${destinationArea.displayName}")
            } else {
                showToast("✅ Guardado en ${destinationArea.displayName}")
            }
        }
    }

    /** Clasificación automática básica por palabras del nombre; se puede ampliar con productos reales. */
    private fun inferAreaFromProductName(productName: String): Area {
        val n = java.text.Normalizer.normalize(productName.lowercase(), java.text.Normalizer.Form.NFD)
            .replace(Regex("\\p{Mn}+"), "")

        val gaseosas = listOf("coca cola", "coca-cola", "cocacola", "pepsi", "gaseosa", "soda", "sprite", "colombiana", "manzana postobon", "uvas postobon", "seven up", "7up", "schweppes", "speed max", "vive100", "vive 100", "red bull", "monster", "agua con gas", "snack", "papas", "detodito", "doritos", "chitos", "cheetos", "mani", "tostacos", "galletas saladas")
        val lacteos = listOf("leche", "yogur", "yogurt", "kumis", "queso", "mantequilla", "crema de leche", "suero costeño", "salchicha", "jamon", "mortadela", "chorizo", "butifarra", "embutido")
        val fruver = listOf("manzana", "banano", "banana", "platano", "naranja", "limon", "tomate", "cebolla", "papa", "yuca", "zanahoria", "lechuga", "aguacate", "mango", "papaya", "piña", "uva", "fresa", "fruta", "verdura", "cilantro", "perejil")
        val dulces = listOf("azucar", "harina", "arroz", "pasta", "espagueti", "panela", "chocolate", "dulce", "caramelo", "chicle", "bombon", "galleta dulce", "ponque", "torta", "cereal", "avena", "gelatina", "arequipe", "mermelada", "pan tajado")

        return when {
            gaseosas.any { n.contains(it) } -> Area.GASEOSAS
            lacteos.any { n.contains(it) } -> Area.LACTEOS
            fruver.any { n.contains(it) } -> Area.FRUVER
            dulces.any { n.contains(it) } -> Area.DULCES
            else -> Area.fromId(_currentArea.value.id).takeUnless { it == Area.ADMIN } ?: Area.OTROS
        }
    }

    fun startAddBatch(product: ProductWithBatches) {
        editingProductId.value = product.id
        editingBatchId.value = null
        barcodeInput.value = product.barcode ?: ""
        pluInput.value = product.plu ?: ""
        nameInput.value = product.name
        locationInput.value = product.location
        quantityInput.value = ""
        unitCostInput.value = product.product.unitCost?.let { QuantityFormatter.format(it) } ?: ""
        expiryDateInput.value = DateUtils.todayIso()
        formError.value = null
        showToast("➕ Agregando nuevo lote a: ${product.name}")
    }

    fun startEditBatch(product: ProductWithBatches, batch: BatchEntity) {
        editingProductId.value = product.id
        editingBatchId.value = batch.id
        barcodeInput.value = product.barcode ?: ""
        pluInput.value = product.plu ?: ""
        nameInput.value = product.name
        locationInput.value = product.location
        quantityInput.value = QuantityFormatter.format(batch.quantity)
        unitCostInput.value = product.product.unitCost?.let { QuantityFormatter.format(it) } ?: ""
        expiryDateInput.value = batch.expiryDate
        formError.value = null
        showToast("✏️ Editando ${batch.batchNumber ?: "lote"} de ${product.name}")
    }

    fun resetForm() {
        editingProductId.value = null
        editingBatchId.value = null
        barcodeInput.value = ""
        pluInput.value = ""
        nameInput.value = ""
        locationInput.value = ""
        quantityInput.value = ""
        unitCostInput.value = ""
        expiryDateInput.value = DateUtils.todayIso()
        formError.value = null
    }

    fun deleteBatch(batchId: String) {
        viewModelScope.launch {
            repository.deleteBatch(batchId)
            _selectedBatchIds.value = _selectedBatchIds.value - batchId
            showToast("🗑️ Lote eliminado")
        }
    }

    fun deleteProduct(productId: String) {
        viewModelScope.launch {
            repository.deleteProduct(productId)
            showToast("🗑️ Producto y sus lotes eliminados")
        }
    }

    fun moveProductToArea(productId: String, targetArea: Area) {
        if (targetArea == Area.ADMIN) return
        viewModelScope.launch {
            repository.moveProductToArea(productId, targetArea.id)
            showToast("Producto movido a ${targetArea.displayName}")
        }
    }

    fun toggleBatchSelection(batchId: String) {
        val current = _selectedBatchIds.value.toMutableSet()
        if (current.contains(batchId)) {
            current.remove(batchId)
        } else {
            current.add(batchId)
        }
        _selectedBatchIds.value = current
    }

    fun selectAllBatches(batchIds: List<String>) {
        _selectedBatchIds.value = batchIds.toSet()
    }

    fun selectAllExpiredBatches() {
        val expiredIds = _areaProducts.value
            .flatMap { it.batches }
            .filter { DateUtils.daysLeft(it.expiryDate) < 0 }
            .map { it.id }

        if (expiredIds.isNotEmpty()) {
            _selectedBatchIds.value = expiredIds.toSet()
            showToast("Seleccionados ${expiredIds.size} lote(s) vencido(s)")
        } else {
            showToast("No hay lotes vencidos para seleccionar")
        }
    }

    fun clearSelection() {
        _selectedBatchIds.value = emptySet()
    }

    fun deleteSelectedBatches() {
        val idsToDelete = _selectedBatchIds.value.toList()
        if (idsToDelete.isEmpty()) return
        viewModelScope.launch {
            repository.deleteBatchesBatch(idsToDelete)
            _selectedBatchIds.value = emptySet()
            showToast("🗑️ Se eliminaron ${idsToDelete.size} lote(s)")
        }
    }

    fun deleteExpiredBatchesDirectly() {
        viewModelScope.launch {
            val count = repository.deleteExpiredBatches(_currentArea.value.id)
            if (count > 0) {
                showToast("🗑️ Se eliminaron $count lote(s) vencido(s)")
            } else {
                showToast("No hay lotes vencidos en esta sección")
            }
        }
    }

    fun addMultiScannedBatch(items: List<MultiScanItem>, expiryDate: String) {
        viewModelScope.launch {
            repository.saveMultiScannedBatch(_currentArea.value.id, items, expiryDate)
            showToast("✅ Se registraron ${items.size} producto(s)/lote(s) escaneados")
        }
    }

    fun trigger30DayNotificationCheck(context: Context) {
        NotificationHelper.createNotificationChannel(context)
        ExpiryNotificationWorker.triggerImmediateCheck(context)
        showToast("🔔 Alarma sonora y verificación de vencimientos ejecutada")
    }

    fun importMacroPastedText(text: String) {
        viewModelScope.launch {
            val result = repository.importMacroPastedText(_currentArea.value, text)
            if (result.errorMessage != null) {
                showToast("❌ ${result.errorMessage}")
            } else {
                showToast("📥 ${result.message ?: "Importación de Macro completada: ${result.totalRows} filas."}")
                showMacroImportModal.value = false
            }
        }
    }

    fun addProductsToMacro(products: List<ProductWithBatches>, startDate: String, endDate: String) {
        viewModelScope.launch {
            val count = repository.addProductsToMacro(products, startDate, endDate)
            showToast("✓ $count producto(s) agregados al Control de Macro")
            showMacroImportModal.value = false
        }
    }

    fun renewMacroRecord(id: String) {
        viewModelScope.launch {
            val renewed = repository.renewMacroRecord(id)
            if (renewed) {
                showToast("🔄 Renovación guardada: fechas de Macro actualizadas")
            } else {
                showToast("⚠️ No se renovó: el lote está vencido o ya no existe en Macro")
            }
        }
    }

    fun updateMacroDiscount(id: String, percent: Double) {
        viewModelScope.launch {
            repository.updateMacroDiscount(id, percent)
            showToast("Descuento actualizado al ${percent.toInt()}%")
        }
    }

    fun deleteMacroRecord(id: String) {
        viewModelScope.launch {
            repository.deleteMacroRecordById(id)
            showToast("Producto retirado de Macro")
        }
    }

    fun setProductsReturnStatus(productIds: List<String>, hasReturn: Boolean) {
        if (productIds.isEmpty()) return
        viewModelScope.launch {
            runCatching { repository.setProductsReturnStatus(productIds, hasReturn) }
                .onSuccess { count ->
                    val state = if (hasReturn) "con devolución" else "sin devolución"
                    showToast("$count producto(s) marcado(s) $state${if (hasReturn) " y retirado(s) de Macro" else ""}")
                }
                .onFailure { showToast(it.message ?: "No se pudo actualizar la devolución") }
        }
    }

    fun sendManualAlertWebhook() {
        if (InventoryProfile.selected(getApplication())?.isLocalTest == true) {
            showToast("Modo prueba: el envío de correos reales está desactivado en este usuario.")
            return
        }
        if (_isSendingAlert.value) return
        _isSendingAlert.value = true
        showToast("Sincronizando inventario y preparando el correo...")

        viewModelScope.launch(Dispatchers.IO) {
            try {
                // Apps Script consulta Supabase, no la copia local enviada en el cuerpo HTTP.
                // Sincronizamos primero para que los productos/lotes recién guardados también
                // estén disponibles para el proceso de alertas del servidor.
                _syncStatus.value = "Sincronizando antes de enviar la alerta…"
                syncMutex.lock()
                val syncResult = try {
                    supabaseSyncRepository.syncInventory()
                } finally {
                    syncMutex.unlock()
                }
                _syncStatus.value = "Nube sincronizada"

                val currentProducts = repository.getAllProductsWithBatchesDirect()
                val inventoryArray = JSONArray()
                for (p in currentProducts) {
                    for (b in p.batches) {
                        val obj = JSONObject().apply {
                            put("id", p.id)
                            put("batchId", b.id)
                            put("name", p.name)
                            put("barcode", p.barcode ?: "")
                            put("plu", p.plu ?: "")
                            put("qty", b.quantity)
                            put("date", b.expiryDate)
                        }
                        inventoryArray.put(obj)
                    }
                }

                val payload = JSONObject().apply {
                    put("token", "CARULLA_ALERTAS_V1")
                    put("siteId", "calle_roman_app")
                    put("inventory", inventoryArray)
                    put("action", "sendAlert")
                    put("manual", true)
                    put("requestId", "REQ_${System.currentTimeMillis()}")
                }

                val requestBody = payload.toString().toRequestBody("application/json; charset=utf-8".toMediaType())
                val request = Request.Builder()
                    .url(webhookUrl)
                    .post(requestBody)
                    .build()

                httpClient.newCall(request).execute().use { response ->
                    val responseBody = response.body?.string().orEmpty()
                    val jsonResp = runCatching { JSONObject(responseBody) }.getOrNull()

                    withContext(Dispatchers.Main) {
                        _isSendingAlert.value = false
                        if (!response.isSuccessful) {
                            showToast("⚠️ Apps Script respondió HTTP ${response.code}. ${responseBody.take(140)}")
                            return@withContext
                        }
                        if (jsonResp == null) {
                            showToast("⚠️ El servidor respondió HTTP ${response.code}, pero no devolvió JSON válido. ${responseBody.take(120)}")
                            return@withContext
                        }

                        // El contrato actual de Apps Script devuelve los totales dentro de
                        // counts (emails_accepted, email_failures, general_candidates, etc.).
                        // También aceptamos sent/count para mantener compatibilidad con versiones previas.
                        val counts = jsonResp.optJSONObject("counts")
                        val ok = jsonResp.optBoolean("ok", false)
                        val accepted = if (counts?.has("emails_accepted") == true) {
                            counts.optInt("emails_accepted", 0)
                        } else if (jsonResp.optBoolean("sent", false)) 1 else 0
                        val failures = counts?.optInt("email_failures", 0) ?: 0
                        val general = counts?.optInt("general_candidates", 0) ?: 0
                        val special = counts?.optInt("special_candidates", 0) ?: 0
                        val duplicates = counts?.optInt("duplicates", 0) ?: 0
                        val eventUpdates = counts?.optInt("events_sent", 0) ?: 0
                        val candidates = general + special
                        val source = jsonResp.optString("source", "")
                        val skipped = jsonResp.optBoolean("skipped", false)
                        val serverError = jsonResp.optString("error", "")
                        val serverMessage = jsonResp.optString("message", "")

                        when {
                            accepted > 0 && failures > 0 -> showToast(
                                "⚠️ Envío parcial: Google aceptó $accepted correo(s), pero $failures fallaron. Revisa Apps Script."
                            )
                            accepted > 0 -> showToast(
                                "✅ Google aceptó $accepted correo(s) para envío. Alertas candidatas: $candidates. Sincronización: ${syncResult.products} productos y ${syncResult.batches} lotes."
                            )
                            failures > 0 -> showToast(
                                "❌ No se aceptaron correos: $failures error(es) de envío. ${serverError.ifBlank { serverMessage }}"
                            )
                            skipped -> showToast(
                                "ℹ️ Apps Script recibió la solicitud, pero la omitió por protección contra solicitudes repetidas. Espera más de 60 segundos y vuelve a intentarlo."
                            )
                            !ok -> showToast(
                                "❌ Apps Script no completó el proceso. ${serverError.ifBlank { serverMessage.ifBlank { "Revisa la ejecución de doPost." } }}"
                            )
                            candidates == 0 -> showToast(
                                "ℹ️ Apps Script revisó Supabase, pero no encontró lotes elegibles para alertas. Sincronización: ${syncResult.products} productos y ${syncResult.batches} lotes."
                            )
                            duplicates > 0 -> showToast(
                                "ℹ️ Hay $candidates alertas candidatas, pero $duplicates ya estaban registradas; no se reenvían correos duplicados. Correos nuevos aceptados: 0."
                            )
                            source.isNotBlank() && source != "APP_MANUAL" -> showToast(
                                "⚠️ La solicitud llegó con origen '$source', no APP_MANUAL. Revisa la versión desplegada y los campos action/manual."
                            )
                            else -> showToast(
                                "⚠️ El servidor revisó $candidates alertas candidatas, pero no confirmó correos nuevos (actualizaciones de historial: $eventUpdates). Revisa el resultado de Apps Script."
                            )
                        }
                    }
                }
            } catch (e: Exception) {
                e.printStackTrace()
                withContext(Dispatchers.Main) {
                    _isSendingAlert.value = false
                    _syncStatus.value = "Sin sincronizar; datos guardados en este dispositivo"
                    showToast("❌ No se confirmó el envío. ${e.message ?: e.javaClass.simpleName}. El correo NO debe darse por enviado.")
                }
            }
        }
    }

    suspend fun parseCediText(text: String): CediParseResult {
        return repository.parseCediText(_currentArea.value.id, text)
    }

    fun applyCediArrival(items: List<CediParsedItem>, expiryDate: String) {
        viewModelScope.launch {
            val totalUnits = items.sumOf { it.quantity }
            val count = repository.applyCediArrival(_currentArea.value.id, items, expiryDate)
            showCediModal.value = false
            showToast("🚚 Recepción CEDI cargada: $count productos (${QuantityFormatter.format(totalUnits)} unidades) con fecha $expiryDate")
        }
    }

    suspend fun getExportJson(): String {
        return repository.exportBackupJson()
    }

    fun importBackup(jsonString: String) {
        viewModelScope.launch {
            val ok = repository.importBackupJson(jsonString)
            if (ok) {
                showToast("✅ Respaldo restaurado correctamente")
                showBackupModal.value = false
            } else {
                showToast("❌ Error al restaurar respaldo JSON")
            }
        }
    }

    private fun showToast(msg: String) {
        _toastMessage.value = msg
    }

    fun clearToast() {
        _toastMessage.value = null
    }
}
