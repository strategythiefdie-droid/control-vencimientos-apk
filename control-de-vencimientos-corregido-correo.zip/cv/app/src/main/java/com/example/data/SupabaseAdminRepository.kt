package com.example.data

import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/** Admin gateway client: cloud inventory inspection plus device invite/binding administration. */
data class CloudInventoryUser(val id: String, val name: String, val role: String)
data class CloudInventoryProduct(
    val id: String,
    val userId: String,
    val name: String,
    val barcode: String?,
    val plu: String?,
    val quantity: String,
    val expiryDate: String?,
    val location: String = "",
    val hasReturn: Boolean = false
)

data class CloudAdminSession(val accessToken: String, val userId: String, val email: String, val displayName: String)
data class CloudDeviceInvite(
    val code: String,
    val workspaceId: String,
    val workspaceName: String,
    val expiresAt: String,
    val expiresInSeconds: Int
)
data class CloudDeviceBinding(
    val deviceHash: String,
    val workspaceId: String,
    val label: String,
    val createdAt: String,
    val lastSeenAt: String,
    val revokedAt: String?
)

class SupabaseAdminRepository {
    companion object {
        private const val BASE_URL = "https://hhncacdqvmxsilkpzniy.supabase.co"
        // Supabase publishable key. It is safe to ship only when database RLS policies are enabled.
        private const val PUBLISHABLE_KEY = "sb_publishable_Ebgl5rcG2WEq0Ra0BJiHjA_y1kkt-xz"
    }

    private val client = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(25, TimeUnit.SECONDS)
        .build()
    private val jsonType = "application/json; charset=utf-8".toMediaType()

    private fun request(path: String, token: String? = null): Request.Builder =
        Request.Builder().url("$BASE_URL$path")
            .header("apikey", PUBLISHABLE_KEY)
            .header("Accept", "application/json")
            .apply { if (token != null) header("Authorization", "Bearer $token") }

    private fun execute(req: Request): String {
        client.newCall(req).execute().use { response ->
            val body = response.body?.string().orEmpty()
            if (!response.isSuccessful) {
                val message = try { JSONObject(body).optString("message", body) } catch (_: Exception) { body }
                throw IllegalStateException("Supabase (${response.code}): ${message.ifBlank { "Error de servidor" }}")
            }
            return body
        }
    }

    private fun gateway(
        credential: String,
        action: String,
        userId: String? = null,
        extra: JSONObject = JSONObject()
    ): String {
        val payload = JSONObject(extra.toString()).put("action", action)
        if (action == "login") payload.put("password", credential)
        else payload.put("sessionToken", credential)
        if (userId != null) payload.put("userId", userId)
        val req = request("/functions/v1/admin-gateway")
            .post(payload.toString().toRequestBody(jsonType)).build()
        return execute(req)
    }

    fun signInAsAdmin(password: String): CloudAdminSession {
        val result = JSONObject(gateway(password, "login"))
        if (!result.optBoolean("ok")) throw SecurityException("Contraseña de administrador incorrecta.")
        val token = result.optString("sessionToken")
        if (token.isBlank()) throw SecurityException("El servidor no creó una sesión administrativa válida.")
        // Solo se conserva el token temporal; la contraseña no se reutiliza en consultas.
        return CloudAdminSession(token, "admin", "", result.optString("displayName", "Administrador"))
    }

    fun loadUsers(session: CloudAdminSession): List<CloudInventoryUser> {
        val arr = JSONArray(gateway(session.accessToken, "users"))
        return (0 until arr.length()).map { i -> arr.getJSONObject(i) }.map { o ->
            CloudInventoryUser(o.optString("id"), o.optString("full_name", "Usuario sin nombre"), o.optString("role", "user"))
        }
    }

    fun loadProducts(session: CloudAdminSession, userId: String): List<CloudInventoryProduct> {
        val arr = JSONArray(gateway(session.accessToken, "products", userId))
        return (0 until arr.length()).map { i -> arr.getJSONObject(i) }.map { o ->
            CloudInventoryProduct(
                id = o.optString("id"), userId = o.optString("user_id"), name = o.optString("name", "Producto"),
                barcode = o.optString("barcode").takeIf { it.isNotBlank() && it != "null" },
                plu = o.optString("plu").takeIf { it.isNotBlank() && it != "null" },
                quantity = o.optString("quantity", "0"),
                expiryDate = o.optString("expiry_date").takeIf { it.isNotBlank() && it != "null" },
                location = o.optString("location").takeIf { it.isNotBlank() && it != "null" } ?: "",
                hasReturn = o.optBoolean("has_return", false)
            )
        }
    }

    /** Generates a 36-character, one-use code on the server. The admin shares it manually. */
    fun createDeviceInvite(session: CloudAdminSession, workspaceId: String): CloudDeviceInvite {
        require(workspaceId.matches(Regex("^TUSK_ACT_[1-4]$"))) {
            "Selecciona uno de los inventarios ACT 1–ACT 4."
        }
        val response = JSONObject(gateway(
            session.accessToken,
            "create-device-invite",
            extra = JSONObject().put("workspaceId", workspaceId)
        ))
        if (!response.optBoolean("ok")) {
            throw IllegalStateException(response.optString("error").ifBlank { "No se pudo generar el código." })
        }
        val code = response.optString("code")
        if (!code.matches(Regex("^[A-F0-9]{36}$"))) {
            throw IllegalStateException("El servidor no devolvió un código válido.")
        }
        return CloudDeviceInvite(
            code = code,
            workspaceId = response.optString("workspaceId", workspaceId),
            workspaceName = response.optString("workspaceName", workspaceId.replace('_', ' ')),
            expiresAt = response.optString("expiresAt"),
            expiresInSeconds = response.optInt("expiresInSeconds", 600)
        )
    }

    fun loadDeviceBindings(session: CloudAdminSession): List<CloudDeviceBinding> {
        val arr = JSONArray(gateway(session.accessToken, "device-bindings"))
        return (0 until arr.length()).mapNotNull { i ->
            val o = arr.optJSONObject(i) ?: return@mapNotNull null
            val hash = o.optString("device_hash")
            if (hash.isBlank()) return@mapNotNull null
            CloudDeviceBinding(
                deviceHash = hash,
                workspaceId = o.optString("workspace_id"),
                label = o.optString("label", "Android"),
                createdAt = o.optString("created_at"),
                lastSeenAt = o.optString("last_seen_at"),
                revokedAt = o.optString("revoked_at").takeIf { it.isNotBlank() && it != "null" }
            )
        }
    }

    fun revokeDeviceBinding(session: CloudAdminSession, deviceHash: String) {
        require(deviceHash.matches(Regex("^[a-fA-F0-9]{64}$"))) { "Identificador de dispositivo inválido." }
        val response = JSONObject(gateway(
            session.accessToken,
            "revoke-device",
            extra = JSONObject().put("deviceId", deviceHash)
        ))
        if (!response.optBoolean("ok")) {
            throw IllegalStateException(response.optString("error").ifBlank { "No se pudo revocar el dispositivo." })
        }
    }
}
