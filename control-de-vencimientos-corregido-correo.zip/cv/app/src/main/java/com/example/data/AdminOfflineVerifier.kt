package com.example.data

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import java.security.KeyStore
import javax.crypto.KeyGenerator
import javax.crypto.Mac
import javax.crypto.SecretKey

/**
 * Device-local verifier used only to unlock the local admin UI after at least one
 * successful online admin login. It does not create a cloud session or authorize
 * any server operation. The HMAC key is held by Android Keystore.
 */
class AdminOfflineVerifier(context: Context) {
    private val prefs = context.getSharedPreferences("admin_offline_auth", Context.MODE_PRIVATE)

    @Synchronized
    fun rememberAfterOnlineSuccess(password: String) {
        val verifier = hmac(password.toByteArray(Charsets.UTF_8))
        prefs.edit().putString(KEY_VERIFIER, Base64.encodeToString(verifier, Base64.NO_WRAP)).apply()
    }

    @Synchronized
    fun canUnlockOffline(password: String): Boolean {
        val saved = prefs.getString(KEY_VERIFIER, null) ?: return false
        val expected = try { Base64.decode(saved, Base64.NO_WRAP) } catch (_: Exception) { return false }
        val actual = try { hmac(password.toByteArray(Charsets.UTF_8)) } catch (_: Exception) { return false }
        return java.security.MessageDigest.isEqual(expected, actual)
    }

    private fun hmac(data: ByteArray): ByteArray {
        val keyStore = KeyStore.getInstance(ANDROID_KEYSTORE).apply { load(null) }
        val key = (keyStore.getKey(KEY_ALIAS, null) as? SecretKey) ?: createKey()
        return Mac.getInstance("HmacSHA256").run {
            init(key)
            doFinal(data)
        }
    }

    private fun createKey(): SecretKey {
        val generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_HMAC_SHA256, ANDROID_KEYSTORE)
        generator.init(
            KeyGenParameterSpec.Builder(KEY_ALIAS, KeyProperties.PURPOSE_SIGN or KeyProperties.PURPOSE_VERIFY)
                .setDigests(KeyProperties.DIGEST_SHA256)
                .build()
        )
        return generator.generateKey()
    }

    companion object {
        private const val ANDROID_KEYSTORE = "AndroidKeyStore"
        private const val KEY_ALIAS = "control_vencimientos_admin_offline_hmac_v1"
        private const val KEY_VERIFIER = "password_hmac"
    }
}
