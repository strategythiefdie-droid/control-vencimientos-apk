package com.example.profile

/**
 * Local entry gate for the TUSK inventory.
 * This is intentionally checked inside the Android app and is independent
 * from Supabase authentication, device authorization, and administrator login.
 * NOTE: A password embedded in an APK can be extracted; this is a local access
 * prompt, not a security boundary for data exposed through Supabase/RLS.
 */
object LocalTuskAccess {
    const val PASSWORD: String = "TRACEON"

    fun isValid(candidate: String): Boolean = candidate.trim() == PASSWORD
}
