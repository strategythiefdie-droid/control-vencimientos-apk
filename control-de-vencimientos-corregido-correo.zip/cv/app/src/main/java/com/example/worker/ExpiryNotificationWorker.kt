package com.example.worker

import android.content.Context
import androidx.work.Constraints
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.ExistingWorkPolicy
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.OutOfQuotaPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import com.example.data.AppDatabase
import com.example.util.DateUtils
import com.example.util.NotificationHelper
import com.example.util.QuantityFormatter
import com.example.util.SpecialExpiryAlert
import java.util.concurrent.TimeUnit

class ExpiryNotificationWorker(
    private val context: Context,
    params: WorkerParameters
) : CoroutineWorker(context, params) {

    override suspend fun doWork(): Result {
        return try {
            val database = AppDatabase.getInstance(context)
            val products = database.productDao().getAllProductsWithBatchesDirect()
            SpecialExpiryAlert.checkAndNotify(context, products)

            val urgentItems = mutableListOf<String>()
            var urgentCount = 0
            var expiredCount = 0

            for (product in products) {
                for (batch in product.batches) {
                    val days = DateUtils.daysLeft(batch.expiryDate)
                    val isFruit = QuantityFormatter.isFruitArea(product.areaId)
                    val qtyStr = if (isFruit) "Peso: ${QuantityFormatter.format(batch.quantity)} kg" else "${QuantityFormatter.format(batch.quantity)} uds"
                    val batchTag = batch.batchNumber ?: "lote"

                    if (days < 0) {
                        expiredCount++
                        urgentItems.add("• ${product.name} [$batchTag]: VENCIDO hace ${kotlin.math.abs(days)}d ($qtyStr)")
                    } else if (days in 0..30) {
                        urgentCount++
                        val daysLabel = if (days == 0L) "vence HOY" else "vence en $days días"
                        urgentItems.add("• ${product.name} [$batchTag]: $daysLabel ($qtyStr)")
                    }
                }
            }

            if (urgentCount > 0 || expiredCount > 0) {
                val title = when {
                    expiredCount > 0 && urgentCount > 0 -> "⛔ $expiredCount lote(s) vencido(s) y $urgentCount por vencer"
                    expiredCount > 0 -> "⛔ ¡Atención! $expiredCount lote(s) vencido(s)"
                    else -> "⚠️ Alerta: $urgentCount lote(s) a 30 días o menos de vencer"
                }

                val body = buildString {
                    appendLine("Productos que requieren revisión:")
                    urgentItems.take(8).forEach { appendLine(it) }
                    if (urgentItems.size > 8) {
                        appendLine("... y ${urgentItems.size - 8} producto(s) más.")
                    }
                }

                NotificationHelper.sendExpiryNotification(
                    context = context,
                    title = title,
                    body = body,
                    notificationId = NotificationHelper.EXPIRY_NOTIFICATION_ID
                )
            }

            Result.success()
        } catch (e: Exception) {
            e.printStackTrace()
            Result.retry()
        }
    }

    companion object {
        const val PERIODIC_WORK_TAG = "periodic_expiry_check_worker"

        /**
         * Programa la tarea periódica con WorkManager en segundo plano.
         * Se ejecuta de forma regular (cada 4 horas) para garantizar que las notificaciones
         * salten tanto con la app en segundo plano como con la aplicación cerrada.
         */
        fun schedulePeriodicCheck(context: Context) {
            try {
                val constraints = Constraints.Builder()
                    .setRequiresBatteryNotLow(false)
                    .build()

                val periodicRequest = PeriodicWorkRequestBuilder<ExpiryNotificationWorker>(
                    repeatInterval = 4,
                    repeatIntervalTimeUnit = TimeUnit.HOURS,
                    flexTimeInterval = 30,
                    flexTimeIntervalUnit = TimeUnit.MINUTES
                )
                .setConstraints(constraints)
                .setInitialDelay(15, TimeUnit.MINUTES)
                .build()

                WorkManager.getInstance(context).enqueueUniquePeriodicWork(
                    PERIODIC_WORK_TAG,
                    ExistingPeriodicWorkPolicy.UPDATE,
                    periodicRequest
                )
            } catch (e: Throwable) {
                e.printStackTrace()
            }
        }

        /**
         * Ejecuta una verificación inmediata expedita con WorkManager.
         */
        fun triggerImmediateCheck(context: Context) {
            try {
                val oneTimeRequest = OneTimeWorkRequestBuilder<ExpiryNotificationWorker>()
                    .setExpedited(OutOfQuotaPolicy.RUN_AS_NON_EXPEDITED_WORK_REQUEST)
                    .build()

                WorkManager.getInstance(context).enqueueUniqueWork(
                    "immediate_expiry_check_worker",
                    ExistingWorkPolicy.REPLACE,
                    oneTimeRequest
                )
            } catch (e: Throwable) {
                e.printStackTrace()
            }
        }
    }
}
