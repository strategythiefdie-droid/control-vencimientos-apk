package com.example.profile

import android.content.Context

/** Inventories are isolated by local database file. TUSK keeps the legacy filename for data safety. */
enum class InventoryProfile(
    val id: String,
    val title: String,
    val databaseName: String,
    val isLocalTest: Boolean = false
) {
    TUSK("TUSK", "TUSK", "control_vencimientos.db"),
    ACT1("TUSK_ACT_1", "TUSK ACT 1", "control_vencimientos_act1.db"),
    ACT2("TUSK_ACT_2", "TUSK ACT 2", "control_vencimientos_act2.db"),
    ACT3("TUSK_ACT_3", "TUSK ACT 3", "control_vencimientos_act3.db"),
    ACT4("TUSK_ACT_4", "TUSK ACT 4", "control_vencimientos_act4.db"),
    /** Local-only sandbox. Separate database, no Supabase synchronization or real email alerts. */
    TEST("LOCAL_TEST", "Usuario de prueba", "control_vencimientos_test.db", isLocalTest = true);

    val requiresAdminCode: Boolean
        get() = this == ACT1 || this == ACT2 || this == ACT3 || this == ACT4

    companion object {
        const val PREFS = "inventory_profile_settings"
        const val KEY_ACTIVE_PROFILE = "active_inventory_profile"

        fun selected(context: Context): InventoryProfile? {
            val id = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .getString(KEY_ACTIVE_PROFILE, null) ?: return null
            return entries.firstOrNull { it.id == id }
        }

        fun select(context: Context, profile: InventoryProfile) {
            context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
                .putString(KEY_ACTIVE_PROFILE, profile.id).apply()
        }
    }
}
