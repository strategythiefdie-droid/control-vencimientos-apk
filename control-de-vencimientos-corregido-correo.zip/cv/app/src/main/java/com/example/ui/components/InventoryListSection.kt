package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.DeleteForever
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.Place
import androidx.compose.material.icons.filled.Print
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.Area
import com.example.data.BatchEntity
import com.example.data.ProductWithBatches
import com.example.ui.theme.StatusExpiredDark
import com.example.ui.theme.StatusOkDark
import com.example.ui.theme.StatusSoonDark
import com.example.util.DateUtils
import com.example.util.QuantityFormatter
import kotlin.math.abs

@Composable
fun InventoryListSection(
    products: List<ProductWithBatches>,
    searchQuery: String,
    selectedFilter: String,
    selectedBatchIds: Set<String>,
    onSetProductsReturnStatus: (List<String>, Boolean) -> Unit,
    onSearchChange: (String) -> Unit,
    onFilterChange: (String) -> Unit,
    onToggleSelectBatch: (String) -> Unit,
    onSelectAllBatches: (List<String>) -> Unit,
    onSelectAllExpiredBatches: () -> Unit,
    onClearSelection: () -> Unit,
    onDeleteSelectedBatches: () -> Unit,
    onDeleteExpiredBatchesDirectly: () -> Unit,
    onEditBatch: (ProductWithBatches, BatchEntity) -> Unit,
    onDeleteBatch: (String) -> Unit,
    onAddBatchToProduct: (ProductWithBatches) -> Unit,
    onDeleteProduct: (String) -> Unit,
    onMoveProduct: (String, Area) -> Unit,
    onOpenReport: () -> Unit,
    modifier: Modifier = Modifier
) {
    val shape = RoundedCornerShape(20.dp)
    var showBatchDeleteConfirmDialog by remember { mutableStateOf(false) }
    var showDirectExpiredDeleteConfirmDialog by remember { mutableStateOf(false) }
    var sortMenuExpanded by remember { mutableStateOf(false) }
    var sortOrder by remember { mutableStateOf("RECENT") }
    var productSelectionMode by remember { mutableStateOf(false) }
    var selectedProductIds by remember { mutableStateOf<Set<String>>(emptySet()) }

    // Filter products
    val filteredProducts = products.filter { p ->
        val q = searchQuery.trim().lowercase()
        val barcodeStr = p.barcode?.lowercase()
        val pluStr = p.plu?.lowercase()
        val matchesQuery = q.isEmpty() ||
                p.name.lowercase().contains(q) ||
                p.location.lowercase().contains(q) ||
                (barcodeStr != null && barcodeStr.contains(q)) ||
                (pluStr != null && pluStr.contains(q)) ||
                p.batches.any { it.expiryDate.contains(q) }

        val matchesFilter = when (selectedFilter) {
            "SOON" -> p.batches.any { DateUtils.daysLeft(it.expiryDate) in 0..30 }
            "DAYS_8" -> p.batches.any { DateUtils.daysLeft(it.expiryDate) in 0..8 }
            "DAYS_15" -> p.batches.any { DateUtils.daysLeft(it.expiryDate) in 0..15 }
            "DAYS_20" -> p.batches.any { DateUtils.daysLeft(it.expiryDate) in 0..20 }
            "EXPIRED" -> p.batches.any { DateUtils.daysLeft(it.expiryDate) < 0 }
            else -> true
        }

        matchesQuery && matchesFilter
    }

    val sortedProducts = when (sortOrder) {
        "NEAREST" -> filteredProducts.sortedWith(
            compareBy<ProductWithBatches> { it.minDaysLeft == null }
                .thenBy { it.minDaysLeft ?: Long.MAX_VALUE }
                .thenByDescending { it.createdAt }
        )
        "FARTHEST" -> filteredProducts.sortedWith(
            compareBy<ProductWithBatches> { it.minDaysLeft == null }
                .thenByDescending { it.minDaysLeft ?: Long.MIN_VALUE }
                .thenByDescending { it.createdAt }
        )
        else -> filteredProducts.sortedByDescending { it.createdAt }
    }

    val sortLabel = when (sortOrder) {
        "NEAREST" -> "Más cerca de vencer"
        "FARTHEST" -> "Más lejos de vencer"
        else -> "Más recientes agregados"
    }

    val allFilteredBatchIds = filteredProducts.flatMap { it.batches.map { b -> b.id } }
    val expiredBatchCount = products.sumOf { p -> p.batches.count { DateUtils.daysLeft(it.expiryDate) < 0 } }
    val soonBatchCount = products.sumOf { p -> p.batches.count { DateUtils.daysLeft(it.expiryDate) in 0..30 } }

    Column(
        modifier = modifier
            .fillMaxWidth()
            .testTag("inventory_list_section"),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        // Search Bar
        OutlinedTextField(
            value = searchQuery,
            onValueChange = onSearchChange,
            placeholder = { Text("Buscar producto, PLU, código o fecha...", fontSize = 12.sp) },
            leadingIcon = {
                Icon(
                    imageVector = Icons.Default.Search,
                    contentDescription = null,
                    modifier = Modifier.size(18.dp),
                    tint = MaterialTheme.colorScheme.onSurfaceVariant
                )
            },
            trailingIcon = {
                if (searchQuery.isNotEmpty()) {
                    IconButton(onClick = { onSearchChange("") }) {
                        Icon(
                            imageVector = Icons.Default.Clear,
                            contentDescription = "Limpiar",
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }
            },
            singleLine = true,
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier
                .fillMaxWidth()
                .testTag("inventory_search_bar"),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = MaterialTheme.colorScheme.primary,
                unfocusedBorderColor = MaterialTheme.colorScheme.outline.copy(alpha = 0.35f)
            )
        )

        // Selección independiente de los lotes: permite marcar devolución en varios productos.
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = if (productSelectionMode) "Selecciona los productos" else "Gestión de devolución",
                fontSize = 11.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                fontWeight = FontWeight.Medium
            )
            OutlinedButton(
                onClick = {
                    productSelectionMode = !productSelectionMode
                    selectedProductIds = emptySet()
                },
                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 5.dp),
                shape = RoundedCornerShape(9.dp)
            ) {
                Text(if (productSelectionMode) "Cancelar" else "Seleccionar productos", fontSize = 11.sp)
            }
        }
        if (productSelectionMode) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("${selectedProductIds.size} seleccionado(s)", fontSize = 11.sp, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.SemiBold)
                TextButton(onClick = {
                    val visibleIds = filteredProducts.map { it.id }.toSet()
                    selectedProductIds = if (selectedProductIds.containsAll(visibleIds) && visibleIds.isNotEmpty()) emptySet() else visibleIds
                }) { Text(if (filteredProducts.isNotEmpty() && selectedProductIds.containsAll(filteredProducts.map { it.id })) "Quitar selección" else "Seleccionar visibles", fontSize = 11.sp) }
            }
            if (selectedProductIds.isNotEmpty()) {
                Column(
                    modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.55f)).padding(10.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text("¿El producto tiene devolución?", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                        Button(
                            onClick = {
                                onSetProductsReturnStatus(selectedProductIds.toList(), true)
                                selectedProductIds = emptySet(); productSelectionMode = false
                            },
                            modifier = Modifier.weight(1f), contentPadding = PaddingValues(horizontal = 8.dp, vertical = 7.dp),
                            shape = RoundedCornerShape(9.dp)
                        ) { Text("Sí, tiene devolución", fontSize = 11.sp) }
                        OutlinedButton(
                            onClick = {
                                onSetProductsReturnStatus(selectedProductIds.toList(), false)
                                selectedProductIds = emptySet(); productSelectionMode = false
                            },
                            modifier = Modifier.weight(1f), contentPadding = PaddingValues(horizontal = 8.dp, vertical = 7.dp),
                            shape = RoundedCornerShape(9.dp)
                        ) { Text("No tiene devolución", fontSize = 11.sp) }
                    }
                }
            }
        }

        // Inventory sorting
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                text = "Ordenar por",
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                fontWeight = FontWeight.Medium
            )
            Box {
                OutlinedButton(
                    onClick = { sortMenuExpanded = true },
                    shape = RoundedCornerShape(10.dp),
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                    modifier = Modifier.testTag("inventory_sort_button")
                ) {
                    Text("↕", fontSize = 15.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Spacer(Modifier.width(6.dp))
                    Text(sortLabel, fontSize = 11.sp, maxLines = 1)
                    Spacer(Modifier.width(3.dp))
                    Icon(Icons.Default.KeyboardArrowDown, contentDescription = null, modifier = Modifier.size(16.dp))
                }
                DropdownMenu(
                    expanded = sortMenuExpanded,
                    onDismissRequest = { sortMenuExpanded = false }
                ) {
                    DropdownMenuItem(
                        text = { Text("Más recientes agregados") },
                        onClick = { sortOrder = "RECENT"; sortMenuExpanded = false },
                        modifier = Modifier.testTag("inventory_sort_recent")
                    )
                    DropdownMenuItem(
                        text = { Text("Más cerca de vencer") },
                        onClick = { sortOrder = "NEAREST"; sortMenuExpanded = false },
                        modifier = Modifier.testTag("inventory_sort_nearest")
                    )
                    DropdownMenuItem(
                        text = { Text("Más lejos de vencer") },
                        onClick = { sortOrder = "FARTHEST"; sortMenuExpanded = false },
                        modifier = Modifier.testTag("inventory_sort_farthest")
                    )
                }
            }
        }

        // Filter Pills Row
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            FilterCapsule(
                label = "Todos",
                count = products.size,
                isSelected = selectedFilter == "ALL",
                onClick = { onFilterChange("ALL") },
                testTag = "filter_chip_all",
                modifier = Modifier.weight(1f)
            )
            FilterCapsule(
                label = "≤ 30 días",
                count = soonBatchCount,
                isSelected = selectedFilter == "SOON",
                accentColor = StatusSoonDark,
                onClick = { onFilterChange("SOON") },
                testTag = "filter_chip_soon",
                modifier = Modifier.weight(1f)
            )
            FilterCapsule(
                label = "Vencidos",
                count = expiredBatchCount,
                isSelected = selectedFilter == "EXPIRED",
                accentColor = StatusExpiredDark,
                onClick = { onFilterChange("EXPIRED") },
                testTag = "filter_chip_expired",
                modifier = Modifier.weight(1f)
            )
        }

        // Filtros rápidos por proximidad del vencimiento
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            FilterCapsule(
                label = "≤ 8 días",
                count = products.sumOf { p -> p.batches.count { DateUtils.daysLeft(it.expiryDate) in 0..8 } },
                isSelected = selectedFilter == "DAYS_8",
                accentColor = StatusExpiredDark,
                onClick = { onFilterChange(if (selectedFilter == "DAYS_8") "ALL" else "DAYS_8") },
                testTag = "filter_chip_days_8",
                modifier = Modifier.weight(1f)
            )
            FilterCapsule(
                label = "≤ 15 días",
                count = products.sumOf { p -> p.batches.count { DateUtils.daysLeft(it.expiryDate) in 0..15 } },
                isSelected = selectedFilter == "DAYS_15",
                accentColor = Color(0xFFFF9800),
                onClick = { onFilterChange(if (selectedFilter == "DAYS_15") "ALL" else "DAYS_15") },
                testTag = "filter_chip_days_15",
                modifier = Modifier.weight(1f)
            )
            FilterCapsule(
                label = "≤ 20 días",
                count = products.sumOf { p -> p.batches.count { DateUtils.daysLeft(it.expiryDate) in 0..20 } },
                isSelected = selectedFilter == "DAYS_20",
                accentColor = StatusSoonDark,
                onClick = { onFilterChange(if (selectedFilter == "DAYS_20") "ALL" else "DAYS_20") },
                testTag = "filter_chip_days_20",
                modifier = Modifier.weight(1f)
            )
        }

        // Direct expired deletion button if expired batches exist
        if (expiredBatchCount > 0) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(StatusExpiredDark.copy(alpha = 0.12f))
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.DeleteForever,
                        contentDescription = null,
                        tint = StatusExpiredDark,
                        modifier = Modifier.size(16.dp)
                    )
                    Text(
                        text = "$expiredBatchCount lote(s) vencido(s)",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = StatusExpiredDark
                    )
                }

                Button(
                    onClick = { showDirectExpiredDeleteConfirmDialog = true },
                    colors = ButtonDefaults.buttonColors(containerColor = StatusExpiredDark),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.height(30.dp)
                ) {
                    Text("Eliminar vencidos", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }
        }

        // Selection Action Bar
        AnimatedVisibility(
            visible = selectedBatchIds.isNotEmpty(),
            enter = fadeIn() + expandVertically(),
            exit = fadeOut() + shrinkVertically()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(MaterialTheme.colorScheme.primaryContainer)
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "${selectedBatchIds.size} lote(s) seleccionados",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onPrimaryContainer
                )

                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    TextButton(
                        onClick = onClearSelection,
                        modifier = Modifier.height(32.dp)
                    ) {
                        Text("Deseleccionar", fontSize = 11.sp)
                    }

                    Button(
                        onClick = { showBatchDeleteConfirmDialog = true },
                        colors = ButtonDefaults.buttonColors(containerColor = StatusExpiredDark),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.height(32.dp).testTag("delete_selected_batches_btn")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Delete,
                            contentDescription = null,
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Eliminar", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // Product Cards List
        if (filteredProducts.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 32.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        imageVector = Icons.Default.Layers,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f),
                        modifier = Modifier.size(36.dp)
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "No se encontraron productos ni lotes.",
                        fontSize = 13.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        } else {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                sortedProducts.forEach { productWithBatches ->
                    ProductMultiBatchCard(
                        product = productWithBatches,
                        selectedBatchIds = selectedBatchIds,
                        isProductSelectionMode = productSelectionMode,
                        isProductSelected = productWithBatches.id in selectedProductIds,
                        onToggleProductSelected = { id ->
                            selectedProductIds = if (id in selectedProductIds) selectedProductIds - id else selectedProductIds + id
                        },
                        onToggleBatchSelect = onToggleSelectBatch,
                        onEditBatch = { batch -> onEditBatch(productWithBatches, batch) },
                        onDeleteBatch = onDeleteBatch,
                        onAddBatch = { onAddBatchToProduct(productWithBatches) },
                        onDeleteProduct = { onDeleteProduct(productWithBatches.id) },
                        onMoveProduct = { target -> onMoveProduct(productWithBatches.id, target) }
                    )
                }
            }
        }
    }

    // Confirmation dialog for deleting selected batches
    if (showBatchDeleteConfirmDialog) {
        AlertDialog(
            onDismissRequest = { showBatchDeleteConfirmDialog = false },
            title = { Text("Eliminar lotes seleccionados") },
            text = { Text("¿Deseas eliminar permanentemente los ${selectedBatchIds.size} lote(s) seleccionados?") },
            confirmButton = {
                Button(
                    onClick = {
                        showBatchDeleteConfirmDialog = false
                        onDeleteSelectedBatches()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = StatusExpiredDark)
                ) {
                    Text("Eliminar")
                }
            },
            dismissButton = {
                OutlinedButton(onClick = { showBatchDeleteConfirmDialog = false }) {
                    Text("Cancelar")
                }
            }
        )
    }

    // Confirmation dialog for direct expired delete
    if (showDirectExpiredDeleteConfirmDialog) {
        AlertDialog(
            onDismissRequest = { showDirectExpiredDeleteConfirmDialog = false },
            title = { Text("Eliminar lotes vencidos") },
            text = { Text("¿Deseas eliminar automáticamente todos los lotes vencidos de esta sección?") },
            confirmButton = {
                Button(
                    onClick = {
                        showDirectExpiredDeleteConfirmDialog = false
                        onDeleteExpiredBatchesDirectly()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = StatusExpiredDark)
                ) {
                    Text("Eliminar vencidos")
                }
            },
            dismissButton = {
                OutlinedButton(onClick = { showDirectExpiredDeleteConfirmDialog = false }) {
                    Text("Cancelar")
                }
            }
        )
    }
}

@Composable
fun ProductMultiBatchCard(
    product: ProductWithBatches,
    selectedBatchIds: Set<String>,
    isProductSelectionMode: Boolean = false,
    isProductSelected: Boolean = false,
    onToggleProductSelected: (String) -> Unit = {},
    onToggleBatchSelect: (String) -> Unit,
    onEditBatch: (BatchEntity) -> Unit,
    onDeleteBatch: (String) -> Unit,
    onAddBatch: () -> Unit,
    onDeleteProduct: () -> Unit,
    onMoveProduct: (Area) -> Unit,
    modifier: Modifier = Modifier
) {
    val shape = RoundedCornerShape(12.dp)
    var isExpanded by remember(product.id) { mutableStateOf(false) }
    var showDeleteProductDialog by remember { mutableStateOf(false) }
    var showMoveMenu by remember { mutableStateOf(false) }

    // If any batch is selected in this product, keep it expanded so the user sees what's selected
    val hasSelectedBatch = product.batches.any { selectedBatchIds.contains(it.id) }
    val currentlyExpanded = isExpanded || hasSelectedBatch

    Column(
        modifier = modifier
            .fillMaxWidth()
            .clip(shape)
            .background(MaterialTheme.colorScheme.surface)
            .border(
                1.dp,
                if (isProductSelected) MaterialTheme.colorScheme.primary.copy(alpha = 0.75f)
                else if (currentlyExpanded) MaterialTheme.colorScheme.primary.copy(alpha = 0.35f)
                else MaterialTheme.colorScheme.outline.copy(alpha = 0.2f),
                shape
            )
            .animateContentSize()
            .testTag("product_card_${product.id}")
    ) {
        // Product Header (Always visible by default: Name, EAN, PLU + tap to expand)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clickable {
                    if (isProductSelectionMode) onToggleProductSelected(product.id)
                    else isExpanded = !currentlyExpanded
                }
                .padding(12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (isProductSelectionMode) {
                Checkbox(
                    checked = isProductSelected,
                    onCheckedChange = { onToggleProductSelected(product.id) },
                    modifier = Modifier.size(38.dp),
                    colors = CheckboxDefaults.colors(checkedColor = MaterialTheme.colorScheme.primary)
                )
            }
            Column(
                modifier = Modifier
                    .weight(1f)
                    .padding(end = 8.dp)
            ) {
                Text(
                    text = product.name,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface,
                    maxLines = if (currentlyExpanded) 3 else 2,
                    overflow = TextOverflow.Ellipsis
                )
                if (product.location.isNotBlank()) {
                    Row(
                        modifier = Modifier.padding(top = 3.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Place,
                            contentDescription = "Lugar del producto",
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(12.dp)
                        )
                        Text(
                            text = product.location,
                            fontSize = 10.sp,
                            color = MaterialTheme.colorScheme.primary,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }

                if (product.hasReturn) {
                    Surface(
                        color = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.75f),
                        shape = RoundedCornerShape(6.dp),
                        modifier = Modifier.padding(top = 4.dp)
                    ) {
                        Text(
                            "Tiene devolución · Excluido de Macro",
                            fontSize = 9.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.onSecondaryContainer,
                            modifier = Modifier.padding(horizontal = 7.dp, vertical = 3.dp)
                        )
                    }
                }

                val barcode = product.barcode
                val plu = product.plu

                if (!barcode.isNullOrBlank() || !plu.isNullOrBlank()) {
                    Spacer(modifier = Modifier.height(6.dp))

                    @OptIn(ExperimentalLayoutApi::class)
                    FlowRow(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        // EAN Barcode Chip
                        if (!barcode.isNullOrBlank()) {
                            Surface(
                                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.65f),
                                shape = RoundedCornerShape(6.dp),
                                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.25f))
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 7.dp, vertical = 3.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.QrCodeScanner,
                                        contentDescription = "Código de barras EAN",
                                        tint = MaterialTheme.colorScheme.primary,
                                        modifier = Modifier.size(12.dp)
                                    )
                                    Text(
                                        text = "EAN",
                                        fontSize = 9.sp,
                                        fontWeight = FontWeight.ExtraBold,
                                        color = MaterialTheme.colorScheme.primary
                                    )
                                    Text(
                                        text = barcode,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.SemiBold,
                                        fontFamily = FontFamily.Monospace,
                                        letterSpacing = 0.5.sp,
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                }
                            }
                        }

                        // PLU Chip
                        if (!plu.isNullOrBlank()) {
                            Surface(
                                color = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.45f),
                                shape = RoundedCornerShape(6.dp),
                                border = BorderStroke(1.dp, MaterialTheme.colorScheme.secondary.copy(alpha = 0.3f))
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 7.dp, vertical = 3.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    Text(
                                        text = "PLU",
                                        fontSize = 9.sp,
                                        fontWeight = FontWeight.ExtraBold,
                                        color = MaterialTheme.colorScheme.secondary
                                    )
                                    Text(
                                        text = plu,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        fontFamily = FontFamily.Monospace,
                                        letterSpacing = 0.5.sp,
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // Controles de expansión y traslado manual entre perfiles
            Row(verticalAlignment = Alignment.CenterVertically) {
                Surface(
                    color = if (currentlyExpanded) MaterialTheme.colorScheme.primary.copy(alpha = 0.12f)
                            else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                    shape = CircleShape,
                    modifier = Modifier.size(32.dp)
                ) {
                    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Icon(
                            imageVector = if (currentlyExpanded) Icons.Default.KeyboardArrowUp else Icons.Default.KeyboardArrowDown,
                            contentDescription = if (currentlyExpanded) "Ocultar lotes y cantidades" else "Ver lotes y cantidades",
                            tint = if (currentlyExpanded) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
                Box {
                    IconButton(onClick = { showMoveMenu = true }) {
                        Icon(Icons.Default.Layers, contentDescription = "Mover producto a otra sección", tint = MaterialTheme.colorScheme.primary)
                    }
                    DropdownMenu(expanded = showMoveMenu, onDismissRequest = { showMoveMenu = false }) {
                        Area.workAreas.filter { it.id != product.areaId }.forEach { area ->
                            DropdownMenuItem(
                                text = { Text("Mover a ${area.icon} ${area.displayName}", fontSize = 12.sp) },
                                onClick = { showMoveMenu = false; onMoveProduct(area) }
                            )
                        }
                    }
                }
            }
        }

        // Expanded Content: Revealed when touched (Los lotes y las cantidades)
        AnimatedVisibility(
            visible = currentlyExpanded,
            enter = expandVertically() + fadeIn(),
            exit = shrinkVertically() + fadeOut()
        ) {
            val isFruit = QuantityFormatter.isFruitArea(product.areaId)
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(start = 12.dp, end = 12.dp, bottom = 12.dp)
            ) {
                // Subtle divider between header and details
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(1.dp)
                        .background(MaterialTheme.colorScheme.outline.copy(alpha = 0.15f))
                )

                Spacer(modifier = Modifier.height(10.dp))

                // Quantities Summary & Actions Row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Cantidades: Total Units & Batches
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Surface(
                            color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.85f),
                            shape = RoundedCornerShape(6.dp)
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 7.dp, vertical = 3.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Layers,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.onPrimaryContainer,
                                    modifier = Modifier.size(11.dp)
                                )
                                val totalUnitsLabel = if (isFruit) "kg totales" else "uds totales"
                                Text(
                                    text = "${QuantityFormatter.format(product.totalQuantity)} $totalUnitsLabel",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onPrimaryContainer
                                )
                            }
                        }

                        Surface(
                            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f),
                            shape = RoundedCornerShape(6.dp)
                        ) {
                            Text(
                                text = "${product.batches.size} lote(s)",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Medium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                            )
                        }
                        if (product.batches.isEmpty()) {
                            Surface(
                                color = MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.8f),
                                shape = RoundedCornerShape(6.dp)
                            ) {
                                Text(
                                    text = "Sin stock",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onErrorContainer,
                                    modifier = Modifier.padding(horizontal = 7.dp, vertical = 3.dp)
                                )
                            }
                        }
                    }

                    // Action buttons: + Lote and Delete
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Button(
                            onClick = onAddBatch,
                            shape = RoundedCornerShape(8.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.12f),
                                contentColor = MaterialTheme.colorScheme.primary
                            ),
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 0.dp),
                            modifier = Modifier
                                .height(30.dp)
                                .testTag("add_batch_btn_${product.id}")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Add,
                                contentDescription = "Agregar lote",
                                modifier = Modifier.size(13.dp)
                            )
                            Spacer(modifier = Modifier.width(3.dp))
                            Text("+ Lote", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }

                        IconButton(
                            onClick = { showDeleteProductDialog = true },
                            modifier = Modifier
                                .size(30.dp)
                                .testTag("delete_product_btn_${product.id}")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Delete,
                                contentDescription = "Eliminar producto",
                                tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f),
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Batches List for this Product (Los lotes)
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    product.sortedBatches.forEachIndexed { index, batch ->
                        BatchItemRow(
                            batch = batch,
                            index = index + 1,
                            isSelected = selectedBatchIds.contains(batch.id),
                            isFruitArea = isFruit,
                            onToggleSelect = { onToggleBatchSelect(batch.id) },
                            onEdit = { onEditBatch(batch) },
                            onDelete = { onDeleteBatch(batch.id) }
                        )
                    }
                }
            }
        }
    }

    if (showDeleteProductDialog) {
        AlertDialog(
            onDismissRequest = { showDeleteProductDialog = false },
            title = { Text("Eliminar producto") },
            text = { Text("¿Deseas eliminar '${product.name}' y todos sus ${product.batches.size} lote(s)?") },
            confirmButton = {
                Button(
                    onClick = {
                        showDeleteProductDialog = false
                        onDeleteProduct()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = StatusExpiredDark)
                ) {
                    Text("Eliminar todo")
                }
            },
            dismissButton = {
                OutlinedButton(onClick = { showDeleteProductDialog = false }) {
                    Text("Cancelar")
                }
            }
        )
    }
}

@Composable
fun BatchItemRow(
    batch: BatchEntity,
    index: Int,
    isSelected: Boolean,
    isFruitArea: Boolean = false,
    onToggleSelect: () -> Unit,
    onEdit: () -> Unit,
    onDelete: () -> Unit
) {
    val daysLeft = DateUtils.daysLeft(batch.expiryDate)
    val statusColor = when {
        daysLeft < 0 -> StatusExpiredDark
        daysLeft in 0..30 -> StatusSoonDark
        else -> StatusOkDark
    }

    val statusLabel = when {
        daysLeft < 0 -> "Vencido (${abs(daysLeft)}d)"
        daysLeft == 0L -> "Vence hoy"
        daysLeft in 1..30 -> "En ${daysLeft}d (Alerta)"
        else -> "En ${daysLeft}d (OK)"
    }

    // La celda del lote cambia progresivamente de amarillo a rojo según se acerca
    // la fecha real de vencimiento. Los lotes a más de 30 días mantienen el fondo normal.
    val expiryCellColor = when {
        daysLeft < 0 -> Color(0xFFE53935)
        daysLeft > 30 -> MaterialTheme.colorScheme.surfaceVariant
        daysLeft >= 8 -> lerp(
            Color(0xFFFFF176), // amarillo suave a 30 días
            Color(0xFFFFB74D), // naranja a 8 días
            ((30L - daysLeft).toFloat() / 22f).coerceIn(0f, 1f)
        )
        else -> lerp(
            Color(0xFFFFB74D), // naranja a 8 días
            Color(0xFFEF5350), // rojo al llegar a 0 días
            ((8L - daysLeft).toFloat() / 8f).coerceIn(0f, 1f)
        )
    }
    val expiryCellAlpha = if (daysLeft > 30) 0.5f else 0.30f

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .background(expiryCellColor.copy(alpha = expiryCellAlpha))
            .padding(horizontal = 8.dp, vertical = 5.dp)
            .testTag("batch_row_${batch.id}"),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.weight(1f)
        ) {
            Checkbox(
                checked = isSelected,
                onCheckedChange = { onToggleSelect() },
                colors = CheckboxDefaults.colors(
                    checkedColor = MaterialTheme.colorScheme.primary,
                    uncheckedColor = MaterialTheme.colorScheme.outline
                ),
                modifier = Modifier
                    .size(24.dp)
                    .testTag("checkbox_${batch.id}")
            )

            Spacer(modifier = Modifier.width(8.dp))

            Column {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(
                        text = batch.batchNumber ?: "Lote $index",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )

                    // Quantity / Weight pill
                    val weightOrQty = if (isFruitArea) "Peso: ${QuantityFormatter.format(batch.quantity)} kg" else "${QuantityFormatter.format(batch.quantity)} uds"
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(999.dp))
                            .background(MaterialTheme.colorScheme.surfaceVariant)
                            .padding(horizontal = 6.dp, vertical = 1.dp)
                    ) {
                        Text(
                            text = weightOrQty,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    // Expiration status badge
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(999.dp))
                            .background(statusColor.copy(alpha = 0.15f))
                            .padding(horizontal = 6.dp, vertical = 1.dp)
                    ) {
                        Text(
                            text = statusLabel,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = statusColor
                        )
                    }
                }

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp),
                    modifier = Modifier.padding(top = 2.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.CalendarMonth,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.size(11.dp)
                    )
                    Text(
                        text = "Vencimiento: ${DateUtils.formatDateEs(batch.expiryDate)}",
                        fontSize = 10.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }

        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(
                onClick = onEdit,
                modifier = Modifier.size(28.dp).testTag("edit_batch_${batch.id}")
            ) {
                Icon(
                    imageVector = Icons.Default.Edit,
                    contentDescription = "Editar lote",
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(15.dp)
                )
            }

            IconButton(
                onClick = onDelete,
                modifier = Modifier.size(28.dp).testTag("delete_batch_${batch.id}")
            ) {
                Icon(
                    imageVector = Icons.Default.Delete,
                    contentDescription = "Eliminar lote",
                    tint = StatusExpiredDark.copy(alpha = 0.8f),
                    modifier = Modifier.size(15.dp)
                )
            }
        }
    }
}

@Composable
private fun FilterCapsule(
    label: String,
    count: Int,
    isSelected: Boolean,
    accentColor: Color = MaterialTheme.colorScheme.primary,
    onClick: () -> Unit,
    testTag: String,
    modifier: Modifier = Modifier
) {
    val bgColor = if (isSelected) accentColor.copy(alpha = 0.15f) else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f)
    val textColor = if (isSelected) accentColor else MaterialTheme.colorScheme.onSurfaceVariant

    Box(
        modifier = modifier
            .clip(RoundedCornerShape(10.dp))
            .background(bgColor)
            .clickable(onClick = onClick)
            .padding(horizontal = 8.dp, vertical = 7.dp)
            .testTag(testTag),
        contentAlignment = Alignment.Center
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(5.dp)
        ) {
            Text(
                text = label,
                fontSize = 11.sp,
                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                color = textColor
            )
            Box(
                modifier = Modifier
                    .clip(CircleShape)
                    .background(if (isSelected) accentColor else MaterialTheme.colorScheme.surface)
                    .padding(horizontal = 5.dp, vertical = 1.dp)
            ) {
                Text(
                    text = count.toString(),
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}
