package com.example.receiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.example.data.AppDatabase
import com.example.util.DateUtils
import com.example.util.NotificationHelper
import com.example.util.QuantityFormatter
import com.example.util.SpecialExpiryAlert
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

class ExpiryAlarmReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent?) {
        // Reprogramar la siguiente alarma en segundo plano y asegurar WorkManager
        AlarmScheduler.scheduleDailyAlarms(context)
        com.example.worker.ExpiryNotificationWorker.schedulePeriodicCheck(context)

        // Si fue únicamente reinicio del dispositivo, solo dejamos programada la alarma y worker
        if (intent?.action == Intent.ACTION_BOOT_COMPLETED || intent?.action == Intent.ACTION_MY_PACKAGE_REPLACED) {
            return
        }

        val pendingResult = goAsync()
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val db = AppDatabase.getInstance(context)
                val products = db.productDao().getAllProductsWithBatchesDirect()
                SpecialExpiryAlert.checkAndNotify(context, products)

                val urgentItems = mutableListOf<String>()
                var urgentCount = 0
                var expiredCount = 0

                for (p in products) {
                    for (b in p.batches) {
                        val days = DateUtils.daysLeft(b.expiryDate)
                        val isFruit = QuantityFormatter.isFruitArea(p.areaId)
                        val qtyStr = if (isFruit) "Peso: ${QuantityFormatter.format(b.quantity)} kg" else "${QuantityFormatter.format(b.quantity)} uds"
                        val batchTag = b.batchNumber ?: "lote"

                        if (days < 0) {
                            expiredCount++
                            urgentItems.add("• ${p.name} [$batchTag]: VENCIDO hace ${kotlin.math.abs(days)}d ($qtyStr)")
                        } else if (days in 0..30) {
                            urgentCount++
                            val daysLabel = if (days == 0L) "vence HOY" else "vence en $days días"
                            urgentItems.add("• ${p.name} [$batchTag]: $daysLabel ($qtyStr)")
                        }
                    }
                }

                if (urgentCount > 0 || expiredCount > 0) {
                    val title = when {
                        expiredCount > 0 && urgentCount > 0 -> "⛔ $expiredCount lote(s) vencido(s) y $urgentCount por vencer"
                        expiredCount > 0 -> "⛔ ¡Atención! $expiredCount lote(s) vencido(s)"
                        else -> "⚠️ Alerta: $urgentCount lote(s) próximos a vencer (≤ 30 días)"
                    }

                    val body = buildString {
                        appendLine("Productos que requieren revisión:")
                        urgentItems.take(8).forEach { appendLine(it) }
                        if (urgentItems.size > 8) {
                            appendLine("... y ${urgentItems.size - 8} producto(s) más.")
                        }
                    }

                    // Suena UNA SOLA VEZ y muestra el listado detallado de productos
                    NotificationHelper.sendExpiryNotification(
                        context = context,
                        title = title,
                        body = body
                    )
                }
            } catch (e: Exception) {
                e.printStackTrace()
            } finally {
                pendingResult.finish()
            }
        }
    }
}
