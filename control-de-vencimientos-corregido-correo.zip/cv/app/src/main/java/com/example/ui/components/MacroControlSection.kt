package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Discount
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.Button
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.IconButton
import androidx.compose.material3.TextButton
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.MacroRecordEntity
import com.example.data.ProductWithBatches
import com.example.ui.theme.StatusExpiredDark
import com.example.ui.theme.StatusMacroDark
import com.example.ui.theme.StatusSoonDark
import com.example.util.DateUtils
import com.example.util.MacroStatus
import com.example.util.QuantityFormatter

data class MacroItemView(
    val productName: String,
    val plu: String,
    val expiryDate: String,
    val startDate: String?,
    val endDate: String?,
    val renewDate: String?,
    val status: MacroStatus,
    val quantity: Double = 0.0,
    val discountPercent: Double? = null,
    val areaId: String? = null,
    val recordId: String? = null
)

@Composable
fun MacroControlSection(
    products: List<ProductWithBatches>,
    macroRecords: List<MacroRecordEntity>,
    onOpenImport: () -> Unit,
    onRenew: (String) -> Unit = {},
    onDiscountChange: (String, Double) -> Unit = { _, _ -> },
    onDelete: (String) -> Unit = {},
    modifier: Modifier = Modifier
) {
    val shape = RoundedCornerShape(14.dp)

    // Render every Macro record separately. One product can have several lots/expiry dates.
    val macroItems = mutableListOf<MacroItemView>()
    val macroProductIds = mutableSetOf<String>()
    macroRecords.forEach { record ->
        val product = products.firstOrNull { p ->
            (!record.plu.isNullOrBlank() && p.plu?.trim() == record.plu.trim()) ||
                p.name.trim().equals(record.name.trim(), ignoreCase = true)
        }
        if (product != null) macroProductIds.add(product.id)
        val expiry = record.expiryDate ?: product?.earliestExpiryDate ?: DateUtils.todayIso()
        val status = DateUtils.getMacroStatus(expiry, record.startDate, record.endDate, record.renewDate)
        macroItems.add(MacroItemView(
            productName = record.name,
            // PLU is a separate field. Never display a barcode as if it were a PLU.
            plu = record.plu ?: product?.plu ?: "—",
            expiryDate = expiry,
            startDate = record.startDate,
            endDate = record.endDate,
            renewDate = record.renewDate,
            status = status,
            quantity = record.quantity ?: product?.totalQuantity ?: 0.0,
            discountPercent = record.discountPercent,
            areaId = product?.areaId ?: record.areaId,
            recordId = record.id
        ))
    }

    // Include eligible inventory products that have not yet been added to Macro.
    products.filter { p ->
        p.id !in macroProductIds && (p.minDaysLeft ?: 999L) in 0..30
    }.forEach { p ->
        val expiry = p.earliestExpiryDate ?: DateUtils.todayIso()
        val status = DateUtils.getMacroStatus(expiry, null, null, null)
        macroItems.add(MacroItemView(
            productName = p.name,
            plu = p.plu ?: "—",
            expiryDate = expiry,
            startDate = null,
            endDate = null,
            renewDate = null,
            status = status,
            quantity = p.totalQuantity,
            discountPercent = null,
            areaId = p.areaId
        ))
    }
    val prepareCount = macroItems.count { it.status == MacroStatus.PREPARE }
    val pendingCount = macroItems.count { it.status == MacroStatus.PENDING_RESPONSE }
    val activeCount = macroItems.count { it.status == MacroStatus.ACTIVE }
    val renewCount = macroItems.count { it.status == MacroStatus.RENEW }

    Column(
        modifier = modifier
            .fillMaxWidth()
            .clip(shape)
            .background(MaterialTheme.colorScheme.surface)
            .border(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.2f), shape)
            .padding(12.dp)
            .testTag("macro_section")
    ) {
        // Head
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "CONTROL DE MACRO",
                    fontSize = 9.sp,
                    letterSpacing = 1.2.sp,
                    fontWeight = FontWeight.Bold,
                    color = StatusMacroDark
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = "Productos en macro",
                    fontSize = 17.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
            }

            Box(
                modifier = Modifier
                    .size(32.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(StatusMacroDark.copy(alpha = 0.15f)),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "%",
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    color = StatusMacroDark
                )
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Macro Summary Badges Row
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            MacroStatBadge(label = "Por subir", count = prepareCount, color = StatusMacroDark, modifier = Modifier.weight(1f))
            MacroStatBadge(label = "En espera", count = pendingCount, color = MaterialTheme.colorScheme.tertiary, modifier = Modifier.weight(1f))
            MacroStatBadge(label = "Activo", count = activeCount, color = StatusSoonDark, modifier = Modifier.weight(1f))
            MacroStatBadge(label = "Renovar (2d)", count = renewCount, color = StatusMacroDark, modifier = Modifier.weight(1f))
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Regla de Macro Informativa
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(10.dp))
                .background(StatusMacroDark.copy(alpha = 0.08f))
                .border(1.dp, StatusMacroDark.copy(alpha = 0.25f), RoundedCornerShape(10.dp))
                .padding(10.dp)
        ) {
            Column {
                Text(
                    text = "⏱️ Regla Operativa de Macro (Respuesta de 2 días):",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = "• Al subir a la macro tarda 2 días en responder (el descuento inicia 2 días después de la subida).\n• Se debe volver a subir 2 días antes de finalizar para evitar corte de descuento.",
                    fontSize = 10.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    lineHeight = 14.sp
                )
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Action tool
        Button(
            onClick = onOpenImport,
            shape = RoundedCornerShape(12.dp),
            colors = ButtonDefaults.buttonColors(
                containerColor = StatusMacroDark,
                contentColor = Color.Black
            ),
            modifier = Modifier
                .fillMaxWidth()
                .height(42.dp)
                .testTag("open_macro_import_btn")
        ) {
            Icon(imageVector = Icons.Default.Discount, contentDescription = null, modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Text("➕ Colocar / Seleccionar productos en Macro", fontSize = 11.sp, fontWeight = FontWeight.Bold)
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Items list
        if (macroItems.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 16.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "No hay productos que requieran control de macro en este momento.",
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        } else {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                macroItems.forEach { item ->
                    MacroItemCard(item = item, onRenew = onRenew, onDiscountChange = onDiscountChange, onDelete = onDelete)
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Minimal help footer
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(12.dp))
                .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f))
                .padding(10.dp)
        ) {
            Text(
                text = "ℹ️ Regla de Macro: Para productos a ≤ 30 días. La renovación se calcula 2 días antes de la fecha final.",
                fontSize = 10.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                lineHeight = 14.sp
            )
        }
    }
}

@Composable
fun MacroStatBadge(
    label: String,
    count: Int,
    color: Color,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(12.dp))
            .background(color.copy(alpha = 0.1f))
            .padding(vertical = 8.dp, horizontal = 4.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = count.toString(),
            fontSize = 18.sp,
            fontWeight = FontWeight.Bold,
            color = color
        )
        Text(
            text = label,
            fontSize = 8.sp,
            fontWeight = FontWeight.Medium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

@Composable
fun MacroItemCard(
    item: MacroItemView,
    onRenew: (String) -> Unit = {},
    onDiscountChange: (String, Double) -> Unit = { _, _ -> },
    onDelete: (String) -> Unit = {},
    modifier: Modifier = Modifier
) {
    val cardShape = RoundedCornerShape(12.dp)
    val (statusLabel, statusColor) = when (item.status) {
        MacroStatus.PREPARE -> "Subir a macro (tarda 2d)" to StatusMacroDark
        MacroStatus.PENDING_RESPONSE -> "Esperando respuesta (+2d)" to MaterialTheme.colorScheme.tertiary
        MacroStatus.ACTIVE -> "Descuento activo" to StatusSoonDark
        MacroStatus.RENEW -> "⚠️ Volver a subir (restan 2d)" to StatusMacroDark
        MacroStatus.OVERDUE -> "Descuento finalizado" to StatusExpiredDark
        MacroStatus.EXPIRED_PRODUCT -> "Vencido" to StatusExpiredDark
        MacroStatus.NONE -> "Sin macro" to MaterialTheme.colorScheme.onSurfaceVariant
    }

    Column(
        modifier = modifier
            .fillMaxWidth()
            .clip(cardShape)
            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f))
            .padding(12.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = item.productName,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                val isFruit = QuantityFormatter.isFruitArea(item.areaId)
                val qtyOrWeight = if (isFruit) "Peso: ${QuantityFormatter.format(item.quantity)} kg" else "Cant: ${QuantityFormatter.format(item.quantity)} uds"
                Text(
                    text = "PLU: ${item.plu} | $qtyOrWeight | Vence: ${DateUtils.formatDateEs(item.expiryDate)}",
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                var discountMenuExpanded by remember(item.recordId, item.discountPercent) { mutableStateOf(false) }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "Descuento: ${item.discountPercent?.let { QuantityFormatter.format(it) + "%" } ?: "Sin definir"}",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = StatusMacroDark
                    )
                    if (item.recordId != null) {
                        TextButton(onClick = { discountMenuExpanded = true }) {
                            Text("Cambiar", fontSize = 10.sp)
                        }
                        DropdownMenu(expanded = discountMenuExpanded, onDismissRequest = { discountMenuExpanded = false }) {
                            (10..70 step 10).forEach { percent ->
                                DropdownMenuItem(
                                    text = { Text("$percent% de descuento") },
                                    onClick = {
                                        discountMenuExpanded = false
                                        onDiscountChange(item.recordId, percent.toDouble())
                                    }
                                )
                            }
                        }
                    }
                }
            }

            Column(horizontalAlignment = Alignment.End) {
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(999.dp))
                        .background(statusColor.copy(alpha = 0.15f))
                        .padding(horizontal = 8.dp, vertical = 3.dp)
                ) {
                    Text(
                        text = statusLabel,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        color = statusColor
                    )
                }
                if (item.recordId != null) {
                    IconButton(onClick = { onDelete(item.recordId) }, modifier = Modifier.size(32.dp)) {
                        Icon(Icons.Default.Delete, contentDescription = "Retirar de Macro", tint = StatusExpiredDark, modifier = Modifier.size(17.dp))
                    }
                }
            }
        }

        // La renovación manual está disponible en cualquier momento mientras el lote
        // siga vigente físicamente. No se condiciona al estado RENEW ni a la fecha sugerida.
        if (item.recordId != null && item.status != MacroStatus.EXPIRED_PRODUCT) {
            Spacer(modifier = Modifier.height(6.dp))
            Button(
                onClick = { onRenew(item.recordId) },
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = StatusMacroDark.copy(alpha = 0.18f), contentColor = MaterialTheme.colorScheme.onSurface),
                shape = RoundedCornerShape(6.dp)
            ) {
                Text(
                    text = if (item.status == MacroStatus.RENEW || item.status == MacroStatus.OVERDUE)
                        "🔄 Renovar ahora · volver a ingresar a Macro"
                    else
                        "↻ Renovar ahora · reiniciar periodo de Macro",
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    lineHeight = 12.sp
                )
            }
        }
        if (item.status == MacroStatus.PENDING_RESPONSE) {
            Spacer(modifier = Modifier.height(6.dp))
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(6.dp))
                    .background(MaterialTheme.colorScheme.tertiary.copy(alpha = 0.15f))
                    .padding(6.dp)
            ) {
                Text(
                    text = "⏳ Esperando respuesta de Macro (+2 días): Subido recientemente. El descuento iniciará el ${DateUtils.formatDateEs(item.startDate)}.",
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface,
                    lineHeight = 12.sp
                )
            }
        }

        if (!item.startDate.isNullOrBlank() || !item.endDate.isNullOrBlank()) {
            Spacer(modifier = Modifier.height(4.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "Vigencia: ${DateUtils.formatDateEs(item.startDate)} - ${DateUtils.formatDateEs(item.endDate)}",
                    fontSize = 9.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                if (!item.renewDate.isNullOrBlank()) {
                    Text(
                        text = "Renovar: ${DateUtils.formatDateEs(item.renewDate)}",
                        fontSize = 9.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = StatusMacroDark
                    )
                }
            }
        }
    }
}
