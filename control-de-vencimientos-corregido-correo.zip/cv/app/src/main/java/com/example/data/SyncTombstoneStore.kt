package com.example.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import com.example.profile.InventoryProfile

/** Persists deletions made offline so a later cloud sync does not resurrect them. */
class SyncTombstoneStore(context: Context) {
    private val appContext = context.applicationContext
    // Resolve the active profile for every operation. This matters when the same repository
    // instance survives a profile switch: cached SharedPreferences would mix tombstones.
    private fun preferences() = appContext.getSharedPreferences(preferencesName(), Context.MODE_PRIVATE)
    private fun preferencesName(): String {
        val profile = InventoryProfile.selected(appContext) ?: InventoryProfile.TUSK
        return if (profile == InventoryProfile.TUSK) "cloud_sync_tombstones" else "cloud_sync_tombstones_${profile.id}"
    }
    private val key = "pending"

    @Synchronized
    fun add(kind: String, id: String) {
        if (id.isBlank()) return
        val rows = readRows().toMutableList()
        if (rows.none { it.first == kind && it.second == id }) rows.add(kind to id)
        writeRows(rows)
    }

    @Synchronized
    fun all(): List<Pair<String, String>> = readRows()

    @Synchronized
    fun remove(items: List<Pair<String, String>>) {
        if (items.isEmpty()) return
        val removeSet = items.toSet()
        writeRows(readRows().filterNot { it in removeSet })
    }

    private fun readRows(): List<Pair<String, String>> {
        val array = try { JSONArray(preferences().getString(key, "[]")) } catch (_: Exception) { JSONArray() }
        return (0 until array.length()).mapNotNull { i ->
            val item = array.optJSONObject(i) ?: return@mapNotNull null
            val kind = item.optString("kind")
            val id = item.optString("id")
            if (kind.isBlank() || id.isBlank()) null else kind to id
        }
    }

    private fun writeRows(rows: List<Pair<String, String>>) {
        val array = JSONArray()
        rows.forEach { (kind, id) -> array.put(JSONObject().put("kind", kind).put("id", id)) }
        preferences().edit().putString(key, array.toString()).apply()
    }
}
