package com.example.ui.components

import android.app.DatePickerDialog
import android.content.Intent
import android.net.Uri
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Discount
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.ProductWithBatches
import com.example.ui.theme.StatusMacroDark
import com.example.ui.theme.StatusSoonDark
import com.example.util.DateUtils
import com.example.util.QuantityFormatter
import java.io.BufferedReader
import java.io.InputStreamReader
import java.util.Calendar
import java.util.Locale

@Composable
fun MacroImportModal(
    availableProducts: List<ProductWithBatches>,
    onAddProductsToMacro: (List<ProductWithBatches>, String, String) -> Unit,
    onImportText: (String) -> Unit,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    var selectedTab by remember { mutableStateOf("inventory") } // "inventory" or "paste"
    var searchQuery by remember { mutableStateOf("") }
    val selectedProductIds = remember { mutableStateListOf<String>() }

    // Fechas de descuento: El descuento inicia 2 días después de subirlo porque tarda 2 días en responder
    var startDate by remember { mutableStateOf(DateUtils.addDaysToIso(DateUtils.todayIso(), 2)) }
    var endDate by remember {
        val defaultEnd = DateUtils.addDaysToIso(DateUtils.addDaysToIso(DateUtils.todayIso(), 2), 7)
        mutableStateOf(defaultEnd)
    }

    // Input para pegar texto o cargar directamente un CSV/XLSX exportado como CSV.
    var textInput by remember { mutableStateOf("") }
    var selectedFileName by remember { mutableStateOf("") }
    val imagePicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            try {
                val image = InputImage.fromFilePath(context, uri)
                TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
                    .process(image)
                    .addOnSuccessListener { result ->
                        // OCR is shown as editable text; users should verify columns before importing.
                        textInput = result.text
                        selectedFileName = "OCR de imagen (revisar antes de importar)"
                        selectedTab = "paste"
                    }
                    .addOnFailureListener {
                        selectedFileName = "No se pudo reconocer la imagen; prueba un CSV"
                    }
            } catch (_: Exception) {
                selectedFileName = "No se pudo abrir la imagen"
            }
        }
    }

    val csvPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri != null) {
            try {
                context.contentResolver.openInputStream(uri)?.use { stream ->
                    textInput = BufferedReader(InputStreamReader(stream, Charsets.UTF_8)).readText()
                    selectedFileName = uri.lastPathSegment?.substringAfterLast('/') ?: "CSV seleccionado"
                    selectedTab = "paste"
                }
            } catch (e: Exception) {
                textInput = ""
                selectedFileName = "No se pudo leer el archivo"
            }
        }
    }

    // Filtrar productos
    val filteredProducts = remember(availableProducts, searchQuery) {
        if (searchQuery.isBlank()) {
            availableProducts
        } else {
            val q = searchQuery.trim().lowercase()
            availableProducts.filter {
                it.name.lowercase().contains(q) ||
                (it.plu?.lowercase()?.contains(q) == true) ||
                (it.barcode?.lowercase()?.contains(q) == true)
            }
        }
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(
            decorFitsSystemWindows = true,
            usePlatformDefaultWidth = false
        )
    ) {
        Surface(
            shape = RoundedCornerShape(24.dp),
            color = MaterialTheme.colorScheme.surface,
            tonalElevation = 6.dp,
            modifier = Modifier
                .fillMaxWidth(0.95f)
                .fillMaxHeight(0.88f)
                .imePadding()
                .testTag("macro_import_modal")
        ) {
            Column(modifier = Modifier.padding(18.dp)) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(34.dp)
                                .clip(CircleShape)
                                .background(StatusMacroDark.copy(alpha = 0.2f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Discount,
                                contentDescription = null,
                                tint = StatusMacroDark,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = "Colocar productos en Macro",
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = "Selecciona del inventario o pega lista de Excel",
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    IconButton(onClick = onDismiss, modifier = Modifier.size(28.dp)) {
                        Icon(imageVector = Icons.Default.Close, contentDescription = "Cerrar")
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Selector de pestañas
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    val isInv = selectedTab == "inventory"
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(10.dp))
                            .background(if (isInv) StatusMacroDark.copy(alpha = 0.15f) else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                            .border(
                                width = if (isInv) 2.dp else 1.dp,
                                color = if (isInv) StatusMacroDark else MaterialTheme.colorScheme.outline.copy(alpha = 0.3f),
                                shape = RoundedCornerShape(10.dp)
                            )
                            .clickable { selectedTab = "inventory" }
                            .padding(vertical = 8.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "📦 Seleccionar del inventario",
                            fontSize = 11.sp,
                            fontWeight = if (isInv) FontWeight.Bold else FontWeight.Medium,
                            color = if (isInv) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    val isPaste = selectedTab == "paste"
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(10.dp))
                            .background(if (isPaste) StatusMacroDark.copy(alpha = 0.15f) else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                            .border(
                                width = if (isPaste) 2.dp else 1.dp,
                                color = if (isPaste) StatusMacroDark else MaterialTheme.colorScheme.outline.copy(alpha = 0.3f),
                                shape = RoundedCornerShape(10.dp)
                            )
                            .clickable { selectedTab = "paste" }
                            .padding(vertical = 8.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "📋 Pegar de Excel",
                            fontSize = 11.sp,
                            fontWeight = if (isPaste) FontWeight.Bold else FontWeight.Medium,
                            color = if (isPaste) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                if (selectedTab == "inventory") {
                    // TAB 1: SELECCIONAR DIRECTAMENTE DEL INVENTARIO
                    // Configuración de fechas de descuento
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f))
                            .border(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.25f), RoundedCornerShape(12.dp))
                            .padding(10.dp)
                    ) {
                        Column {
                            Text(
                                text = "Vigencia del descuento en Macro:",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                // Fecha Inicio
                                OutlinedButton(
                                    onClick = {
                                        val cal = Calendar.getInstance()
                                        DatePickerDialog(context, { _, y, m, d ->
                                            startDate = String.format(Locale.US, "%04d-%02d-%02d", y, m + 1, d)
                                        }, cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH)).show()
                                    },
                                    modifier = Modifier.weight(1f).height(34.dp),
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Icon(imageVector = Icons.Default.CalendarMonth, contentDescription = null, modifier = Modifier.size(12.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Inicio: $startDate", fontSize = 10.sp)
                                }

                                // Fecha Fin
                                OutlinedButton(
                                    onClick = {
                                        val cal = Calendar.getInstance()
                                        DatePickerDialog(context, { _, y, m, d ->
                                            endDate = String.format(Locale.US, "%04d-%02d-%02d", y, m + 1, d)
                                        }, cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH)).show()
                                    },
                                    modifier = Modifier.weight(1f).height(34.dp),
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Icon(imageVector = Icons.Default.CalendarMonth, contentDescription = null, modifier = Modifier.size(12.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Fin: $endDate", fontSize = 10.sp)
                                }
                            }

                            // Atajos de días
                            Spacer(modifier = Modifier.height(6.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                listOf(7 to "+7 días", 15 to "+15 días", 30 to "+30 días").forEach { (days, label) ->
                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(6.dp))
                                            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.7f))
                                            .clickable {
                                                val cal = Calendar.getInstance().apply { add(Calendar.DAY_OF_YEAR, days) }
                                                endDate = String.format(Locale.US, "%04d-%02d-%02d", cal.get(Calendar.YEAR), cal.get(Calendar.MONTH) + 1, cal.get(Calendar.DAY_OF_MONTH))
                                            }
                                            .padding(horizontal = 8.dp, vertical = 3.dp)
                                    ) {
                                        Text(text = label, fontSize = 9.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(6.dp))
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(StatusMacroDark.copy(alpha = 0.1f))
                                    .padding(8.dp)
                            ) {
                                Text(
                                    text = "⏱️ Regla de respuesta (2 días): Cuando subes a la Macro (ej. miércoles), el descuento inicia 2 días después (viernes). Por la misma razón, debes volver a subirlo 2 días antes de que finalice el descuento para evitar que quede sin rebaja.",
                                    fontSize = 10.sp,
                                    color = MaterialTheme.colorScheme.onSurface,
                                    lineHeight = 13.sp
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Buscador y Atajo de Selección Rápida
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedTextField(
                            value = searchQuery,
                            onValueChange = { searchQuery = it },
                            placeholder = { Text("Buscar en inventario...", fontSize = 11.sp) },
                            leadingIcon = {
                                Icon(imageVector = Icons.Default.Search, contentDescription = null, modifier = Modifier.size(16.dp))
                            },
                            singleLine = true,
                            modifier = Modifier.weight(1f).height(44.dp),
                            shape = RoundedCornerShape(10.dp),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = StatusMacroDark,
                                unfocusedBorderColor = MaterialTheme.colorScheme.outline.copy(alpha = 0.3f)
                            )
                        )

                        // Seleccionar próximos a vencer (≤ 30 días)
                        OutlinedButton(
                            onClick = {
                                val nearExp = availableProducts.filter { (it.minDaysLeft ?: 999L) in 0..30 }
                                selectedProductIds.clear()
                                selectedProductIds.addAll(nearExp.map { it.id })
                            },
                            modifier = Modifier.height(44.dp),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Text("≤ 30d (${availableProducts.count { (it.minDaysLeft ?: 999L) in 0..30 }})", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    // Indicador de seleccionados
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "${selectedProductIds.size} de ${availableProducts.size} seleccionados",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = StatusMacroDark
                        )

                        Text(
                            text = if (selectedProductIds.size == filteredProducts.size) "Deseleccionar todos" else "Seleccionar todos",
                            fontSize = 10.sp,
                            color = MaterialTheme.colorScheme.primary,
                            fontWeight = FontWeight.SemiBold,
                            modifier = Modifier.clickable {
                                if (selectedProductIds.size == filteredProducts.size) {
                                    selectedProductIds.clear()
                                } else {
                                    selectedProductIds.clear()
                                    selectedProductIds.addAll(filteredProducts.map { it.id })
                                }
                            }
                        )
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    // Lista de productos con Checkboxes
                    LazyColumn(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(10.dp))
                            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.2f))
                            .padding(4.dp),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        items(filteredProducts, key = { it.id }) { product ->
                            val isSelected = selectedProductIds.contains(product.id)
                            val daysLeft = product.minDaysLeft

                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(if (isSelected) StatusMacroDark.copy(alpha = 0.12f) else MaterialTheme.colorScheme.surface)
                                    .border(
                                        width = if (isSelected) 1.5.dp else 1.dp,
                                        color = if (isSelected) StatusMacroDark else MaterialTheme.colorScheme.outline.copy(alpha = 0.2f),
                                        shape = RoundedCornerShape(8.dp)
                                    )
                                    .clickable {
                                        if (isSelected) selectedProductIds.remove(product.id)
                                        else selectedProductIds.add(product.id)
                                    }
                                    .padding(horizontal = 8.dp, vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Checkbox(
                                    checked = isSelected,
                                    onCheckedChange = { checked ->
                                        if (checked) selectedProductIds.add(product.id)
                                        else selectedProductIds.remove(product.id)
                                    },
                                    colors = CheckboxDefaults.colors(checkedColor = StatusMacroDark),
                                    modifier = Modifier.size(24.dp)
                                )

                                Spacer(modifier = Modifier.width(8.dp))

                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = product.name,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        maxLines = 1
                                    )
                                    Row(
                                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        if (!product.barcode.isNullOrBlank()) {
                                            Text(
                                                text = "EAN: ${product.barcode}",
                                                fontSize = 9.sp,
                                                fontFamily = FontFamily.Monospace,
                                                fontWeight = FontWeight.SemiBold,
                                                color = MaterialTheme.colorScheme.primary
                                            )
                                        }
                                        if (!product.plu.isNullOrBlank()) {
                                            Text(
                                                text = "PLU: ${product.plu}",
                                                fontSize = 9.sp,
                                                fontFamily = FontFamily.Monospace,
                                                fontWeight = FontWeight.Bold,
                                                color = MaterialTheme.colorScheme.secondary
                                            )
                                        }
                                        val isFruitProd = QuantityFormatter.isFruitArea(product.areaId)
                                        val qtyOrWeight = if (isFruitProd) "• ${QuantityFormatter.format(product.totalQuantity)} kg" else "• ${QuantityFormatter.format(product.totalQuantity)} uds"
                                        Text(
                                            text = qtyOrWeight,
                                            fontSize = 9.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                }

                                if (daysLeft != null) {
                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(6.dp))
                                            .background(
                                                when {
                                                    daysLeft < 0 -> MaterialTheme.colorScheme.error.copy(alpha = 0.15f)
                                                    daysLeft <= 15 -> StatusSoonDark.copy(alpha = 0.2f)
                                                    daysLeft <= 30 -> StatusMacroDark.copy(alpha = 0.2f)
                                                    else -> MaterialTheme.colorScheme.surfaceVariant
                                                }
                                            )
                                            .padding(horizontal = 6.dp, vertical = 2.dp)
                                    ) {
                                        Text(
                                            text = if (daysLeft < 0) "Vencido" else "$daysLeft d",
                                            fontSize = 9.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = if (daysLeft < 0) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurface
                                        )
                                    }
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Botón para Confirmar
                    Button(
                        onClick = {
                            val selectedProducts = availableProducts.filter { selectedProductIds.contains(it.id) }
                            if (selectedProducts.isNotEmpty()) {
                                onAddProductsToMacro(selectedProducts, startDate, endDate)
                            }
                        },
                        enabled = selectedProductIds.isNotEmpty(),
                        modifier = Modifier.fillMaxWidth().height(42.dp),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = StatusMacroDark,
                            contentColor = Color.Black
                        )
                    ) {
                        Icon(imageVector = Icons.Default.Check, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "✓ Agregar ${selectedProductIds.size} producto(s) a Macro",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                } else {
                    // TAB 2: PEGAR DESDE EXCEL
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(10.dp))
                            .background(StatusMacroDark.copy(alpha = 0.1f))
                            .border(1.dp, StatusMacroDark.copy(alpha = 0.3f), RoundedCornerShape(10.dp))
                            .padding(10.dp)
                    ) {
                        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text(
                                text = "CSV: se importan PLU, Descripcion, Fecha_Vencimiento, Cantidad_Vencer, DesdeCuando, HastaCuando y PorcentajeDescue por encabezado. Se ignoran Estado Solic... y Detalle Estado. OCR: extrae texto de una imagen, pero revisa/corrige las filas antes de importar; para precisión, prefiere CSV.",
                                fontSize = 10.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                lineHeight = 14.sp
                            )
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                OutlinedButton(onClick = { csvPicker.launch(arrayOf("text/*", "text/csv", "application/vnd.ms-excel", "application/octet-stream")) }) {
                                    Text("Seleccionar CSV", fontSize = 11.sp)
                                }
                                OutlinedButton(onClick = { imagePicker.launch("image/*") }) {
                                    Text("Leer imagen (OCR)", fontSize = 11.sp)
                                }
                            }
                            if (selectedFileName.isNotBlank()) Text("Archivo: $selectedFileName", fontSize = 10.sp, color = MaterialTheme.colorScheme.primary)
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    OutlinedTextField(
                        value = textInput,
                        onValueChange = { textInput = it },
                        placeholder = {
                            Text(
                                text = "Pega aquí filas de Excel o carga un archivo CSV...",
                                fontSize = 11.sp,
                                fontFamily = FontFamily.Monospace,
                                color = MaterialTheme.colorScheme.outline
                            )
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f)
                            .testTag("macro_paste_input"),
                        shape = RoundedCornerShape(10.dp)
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    Text(
                        text = "${textInput.lines().count { it.isNotBlank() }} fila(s) detectadas",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.primary,
                        fontWeight = FontWeight.SemiBold
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedButton(
                            onClick = onDismiss,
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Text("Cancelar", fontSize = 11.sp)
                        }

                        Button(
                            onClick = {
                                if (textInput.isNotBlank()) {
                                    onImportText(textInput)
                                }
                            },
                            enabled = textInput.isNotBlank(),
                            modifier = Modifier.weight(1.3f),
                            shape = RoundedCornerShape(10.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = StatusMacroDark,
                                contentColor = Color.Black
                            )
                        ) {
                            Text("Importar filas", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}
