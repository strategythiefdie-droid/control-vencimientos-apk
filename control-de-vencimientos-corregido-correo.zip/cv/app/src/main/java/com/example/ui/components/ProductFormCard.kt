package com.example.ui.components

import android.app.DatePickerDialog
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LocalTextStyle
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.ProductWithBatches
import com.example.ui.theme.StatusExpiredDark
import com.example.util.QuantityFormatter
import com.example.ui.theme.StatusMacroDark
import com.example.ui.theme.StatusSoonDark
import com.example.util.DateUtils
import java.util.Calendar
import java.util.Locale

@Composable
fun ProductFormCard(
    isEditing: Boolean,
    barcode: String,
    plu: String,
    name: String,
    location: String,
    quantity: String,
    unitCost: String,
    expiryDate: String,
    errorMessage: String?,
    existingProduct: ProductWithBatches? = null,
    isFruitArea: Boolean = false,
    onBarcodeChange: (String) -> Unit,
    onPluChange: (String) -> Unit,
    onNameChange: (String) -> Unit,
    onLocationChange: (String) -> Unit,
    onQuantityChange: (String) -> Unit,
    onUnitCostChange: (String) -> Unit,
    onExpiryDateChange: (String) -> Unit,
    onOpenScanner: () -> Unit,
    onSave: () -> Unit,
    onCancel: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val shape = RoundedCornerShape(14.dp)
    val fieldShape = RoundedCornerShape(10.dp)

    Column(
        modifier = modifier
            .fillMaxWidth()
            .clip(shape)
            .background(MaterialTheme.colorScheme.surface)
            .border(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.25f), shape)
            .padding(14.dp)
            .testTag("product_form_card")
    ) {
        // Form Title
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
            modifier = Modifier.fillMaxWidth()
        ) {
            Column {
                Text(
                    text = when {
                        isEditing -> "EDICIÓN DE LOTE"
                        existingProduct != null -> "AGREGAR NUEVO LOTE A PRODUCTO"
                        else -> "REGISTRO DE INVENTARIO"
                    },
                    fontSize = 9.sp,
                    letterSpacing = 1.2.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )
                Text(
                    text = when {
                        isEditing -> "Actualizar cantidad o fecha del lote"
                        existingProduct != null -> "Producto existente: mismo PLU/EAN con fecha distinta"
                        else -> "Nuevo producto y lote de vencimiento"
                    },
                    fontSize = 13.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.onSurface
                )
            }

            if (isEditing) {
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(999.dp))
                        .background(MaterialTheme.colorScheme.primaryContainer)
                        .padding(horizontal = 8.dp, vertical = 3.dp)
                ) {
                    Text(
                        text = "Editando",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onPrimaryContainer
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Codes Row (EAN + PLU)
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            OutlinedTextField(
                value = barcode,
                onValueChange = onBarcodeChange,
                label = { Text("Código / EAN", fontSize = 11.sp) },
                placeholder = { Text("770200...", fontSize = 11.sp) },
                singleLine = true,
                shape = fieldShape,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                textStyle = LocalTextStyle.current.copy(fontFamily = FontFamily.Monospace),
                modifier = Modifier
                    .weight(1f)
                    .testTag("barcode_input"),
                trailingIcon = {
                    IconButton(
                        onClick = onOpenScanner,
                        modifier = Modifier.size(32.dp).testTag("scan_barcode_btn")
                    ) {
                        Icon(
                            imageVector = Icons.Default.QrCodeScanner,
                            contentDescription = "Escanear código",
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = MaterialTheme.colorScheme.primary,
                    unfocusedBorderColor = MaterialTheme.colorScheme.outline.copy(alpha = 0.35f)
                )
            )

            OutlinedTextField(
                value = plu,
                onValueChange = onPluChange,
                label = { Text("PLU", fontSize = 11.sp) },
                placeholder = { Text("4011", fontSize = 11.sp) },
                singleLine = true,
                shape = fieldShape,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                textStyle = LocalTextStyle.current.copy(fontFamily = FontFamily.Monospace),
                modifier = Modifier
                    .weight(0.85f)
                    .testTag("plu_input"),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = MaterialTheme.colorScheme.primary,
                    unfocusedBorderColor = MaterialTheme.colorScheme.outline.copy(alpha = 0.35f)
                )
            )
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Product Name
        OutlinedTextField(
            value = name,
            onValueChange = onNameChange,
            label = { Text("Nombre del producto *", fontSize = 11.sp) },
            placeholder = { Text("Ej. Leche Entera 1L", fontSize = 11.sp) },
            singleLine = true,
            shape = fieldShape,
            modifier = Modifier
                .fillMaxWidth()
                .testTag("product_name_input"),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = MaterialTheme.colorScheme.primary,
                unfocusedBorderColor = MaterialTheme.colorScheme.outline.copy(alpha = 0.35f)
            )
        )


        // Physical location: optional and concise so the form stays compact.
        Spacer(modifier = Modifier.height(8.dp))
        OutlinedTextField(
            value = location,
            onValueChange = onLocationChange,
            label = { Text("Lugar", fontSize = 11.sp) },
            placeholder = { Text("Ej. Caja 3, estante B o pasillo 2", fontSize = 11.sp) },
            singleLine = true,
            shape = fieldShape,
            modifier = Modifier.fillMaxWidth().testTag("product_location_input"),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = MaterialTheme.colorScheme.primary,
                unfocusedBorderColor = MaterialTheme.colorScheme.outline.copy(alpha = 0.35f)
            )
        )

        // Existing product & batches helper card
        if (existingProduct != null && !isEditing) {
            Spacer(modifier = Modifier.height(10.dp))
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.08f))
                    .padding(10.dp)
            ) {
                Column {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Info,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(15.dp)
                        )
                        Text(
                            text = existingProduct.name,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }

                    Row(
                        modifier = Modifier.padding(top = 3.dp, bottom = 4.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        if (!existingProduct.barcode.isNullOrBlank()) {
                            Text(
                                text = "EAN: ${existingProduct.barcode}",
                                fontSize = 10.sp,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.SemiBold,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                        if (!existingProduct.plu.isNullOrBlank()) {
                            Text(
                                text = "PLU: ${existingProduct.plu}",
                                fontSize = 10.sp,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.secondary
                            )
                        }
                    }

                    Text(
                        text = "Tiene ${existingProduct.batches.size} lote(s) registrado(s). Al guardar, se sumará el nuevo lote sin duplicar el producto:",
                        fontSize = 10.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(bottom = 4.dp)
                    )
                    existingProduct.sortedBatches.forEachIndexed { index, b ->
                        val days = DateUtils.daysLeft(b.expiryDate)
                        val daysLabel = when {
                            days < 0 -> "Vencido (${kotlin.math.abs(days)}d)"
                            days == 0L -> "Vence hoy"
                            days in 1..30 -> "Vence en ${days}d (Alerta)"
                            else -> "Vence en ${days}d (OK)"
                        }
                        val unit = if (isFruitArea) "kg" else "uds"
                        Text(
                            text = "• ${b.batchNumber ?: "Lote ${index + 1}"}: ${QuantityFormatter.format(b.quantity)} $unit — Vence: ${DateUtils.formatDateEs(b.expiryDate)} ($daysLabel)",
                            fontSize = 10.sp,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Quantity and Expiration Date
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            OutlinedTextField(
                value = quantity,
                onValueChange = onQuantityChange,
                label = { Text(if (isFruitArea) "Peso (kg) *" else "Cantidad (uds) *", fontSize = 11.sp) },
                placeholder = { Text(if (isFruitArea) "Ej. 0.252 o 1.500" else "Ej. 12", fontSize = 11.sp) },
                singleLine = true,
                shape = fieldShape,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                modifier = Modifier
                    .weight(0.85f)
                    .testTag("quantity_input"),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = MaterialTheme.colorScheme.primary,
                    unfocusedBorderColor = MaterialTheme.colorScheme.outline.copy(alpha = 0.35f)
                )
            )

            OutlinedTextField(
                value = expiryDate,
                onValueChange = onExpiryDateChange,
                label = { Text("Vencimiento *", fontSize = 11.sp) },
                placeholder = { Text("AAAA-MM-DD", fontSize = 11.sp) },
                singleLine = true,
                shape = fieldShape,
                modifier = Modifier
                    .weight(1.15f)
                    .testTag("expiry_date_input"),
                trailingIcon = {
                    IconButton(
                        onClick = {
                            val cal = Calendar.getInstance()
                            DatePickerDialog(
                                context,
                                { _, year, month, day ->
                                    val dateStr = String.format(Locale.US, "%04d-%02d-%02d", year, month + 1, day)
                                    onExpiryDateChange(dateStr)
                                },
                                cal.get(Calendar.YEAR),
                                cal.get(Calendar.MONTH),
                                cal.get(Calendar.DAY_OF_MONTH)
                            ).show()
                        },
                        modifier = Modifier.size(32.dp).testTag("date_picker_btn")
                    ) {
                        Icon(
                            imageVector = Icons.Default.CalendarMonth,
                            contentDescription = "Elegir fecha",
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = MaterialTheme.colorScheme.primary,
                    unfocusedBorderColor = MaterialTheme.colorScheme.outline.copy(alpha = 0.35f)
                )
            )
        }

        // Quick date shortcuts
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "Accesos rápidos:",
                fontSize = 10.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            listOf(0 to "Hoy", 3 to "+3d", 7 to "+7d", 15 to "+15d", 30 to "+30d", 60 to "+60d").forEach { (days, label) ->
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(999.dp))
                        .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f))
                        .clickable {
                            val cal = Calendar.getInstance().apply { add(Calendar.DAY_OF_YEAR, days) }
                            val dateStr = String.format(Locale.US, "%04d-%02d-%02d", cal.get(Calendar.YEAR), cal.get(Calendar.MONTH) + 1, cal.get(Calendar.DAY_OF_MONTH))
                            onExpiryDateChange(dateStr)
                        }
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = label,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.primary
                    )
                }
            }
        }

        // Validations and Warnings for Expiry Date and Existing Stock
        val trimmedDate = expiryDate.trim()
        val isValidDate = DateUtils.isValidIsoDate(trimmedDate)
        val daysToNewDate = if (isValidDate) DateUtils.daysLeft(trimmedDate) else null

        // 1. Advertencia de fecha pasada o de hoy
        if (daysToNewDate != null && daysToNewDate < 0) {
            Spacer(modifier = Modifier.height(10.dp))
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(StatusExpiredDark.copy(alpha = 0.12f))
                    .border(1.dp, StatusExpiredDark.copy(alpha = 0.4f), RoundedCornerShape(12.dp))
                    .padding(10.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Warning,
                        contentDescription = null,
                        tint = StatusExpiredDark,
                        modifier = Modifier.size(20.dp)
                    )
                    Column {
                        Text(
                            text = "¡Atención! La fecha ingresada es anterior a hoy",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = StatusExpiredDark
                        )
                        Text(
                            text = "Este lote quedará marcado como VENCIDO (${kotlin.math.abs(daysToNewDate)} día(s) atrás). Verifica la fecha en el empaque.",
                            fontSize = 10.sp,
                            color = MaterialTheme.colorScheme.onSurface,
                            lineHeight = 14.sp
                        )
                    }
                }
            }
        } else if (daysToNewDate != null && daysToNewDate == 0L) {
            Spacer(modifier = Modifier.height(10.dp))
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(StatusMacroDark.copy(alpha = 0.12f))
                    .border(1.dp, StatusMacroDark.copy(alpha = 0.4f), RoundedCornerShape(12.dp))
                    .padding(10.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Info,
                        contentDescription = null,
                        tint = StatusMacroDark,
                        modifier = Modifier.size(18.dp)
                    )
                    Text(
                        text = "Aviso: La fecha seleccionada es HOY. El lote vencerá al terminar la jornada.",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }
            }
        }

        // 2. Advertencia si el producto ya tiene stock previo cercano a vencer (<= 30 días)
        val nearExpiryBatches = existingProduct?.batches?.filter { b ->
            val d = DateUtils.daysLeft(b.expiryDate)
            d in 0..30
        } ?: emptyList()

        if (nearExpiryBatches.isNotEmpty() && !isEditing) {
            val totalNearQty = nearExpiryBatches.sumOf { it.quantity }
            val earliestNearBatch = nearExpiryBatches.minByOrNull { it.expiryDate }
            val daysEarliest = earliestNearBatch?.let { DateUtils.daysLeft(it.expiryDate) } ?: 0

            Spacer(modifier = Modifier.height(10.dp))
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(StatusMacroDark.copy(alpha = 0.12f))
                    .border(1.dp, StatusMacroDark.copy(alpha = 0.35f), RoundedCornerShape(12.dp))
                    .padding(10.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.Top,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Warning,
                        contentDescription = null,
                        tint = StatusMacroDark,
                        modifier = Modifier.size(18.dp).padding(top = 1.dp)
                    )
                    Column {
                        Text(
                            text = "⚠️ Stock existente próximo a vencer ($totalNearQty uds en riesgo)",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = StatusMacroDark
                        )
                        Text(
                            text = "Este producto ya tiene ${nearExpiryBatches.size} lote(s) con vencimiento en ${daysEarliest} días (${DateUtils.formatDateEs(earliestNearBatch?.expiryDate ?: "")}). Recuerda rotar la mercancía antigua al frente (FIFO).",
                            fontSize = 10.sp,
                            color = MaterialTheme.colorScheme.onSurface,
                            lineHeight = 14.sp
                        )
                    }
                }
            }
        }

        if (errorMessage != null) {
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = "⚠️ $errorMessage",
                color = StatusExpiredDark,
                fontSize = 11.sp,
                fontWeight = FontWeight.SemiBold
            )
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Action Buttons
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (isEditing || existingProduct != null) {
                OutlinedButton(
                    onClick = onCancel,
                    modifier = Modifier
                        .weight(1f)
                        .height(44.dp)
                        .testTag("cancel_edit_btn"),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text("Cancelar", fontSize = 12.sp)
                }
            }

            Button(
                onClick = onSave,
                modifier = Modifier
                    .weight(if (isEditing || existingProduct != null) 1.5f else 1f)
                    .height(44.dp)
                    .testTag("save_product_btn"),
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    contentColor = MaterialTheme.colorScheme.onPrimary
                )
            ) {
                Text(
                    text = when {
                        isEditing -> "Guardar cambios de lote"
                        existingProduct != null -> "Guardar nuevo lote"
                        else -> "Guardar producto"
                    },
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp
                )
            }
        }
    }
}
