package com.example

import android.os.Bundle
import android.content.Intent
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.InventoryViewModel
import com.example.ui.screens.MainInventoryScreen
import com.example.ui.theme.MyApplicationTheme
import com.example.profile.InventoryProfile
import com.example.data.DeviceAuthorizationRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import com.example.ui.screens.ProfileSelectionScreen

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        com.example.util.NotificationHelper.createNotificationChannel(this)
        com.example.receiver.AlarmScheduler.scheduleDailyAlarms(this)
        com.example.worker.ExpiryNotificationWorker.schedulePeriodicCheck(this)
        setContent {
            val selectedProfile = InventoryProfile.selected(this)
            if (selectedProfile == null) {
                MyApplicationTheme(darkTheme = true) {
                    ProfileSelectionScreen { profile, code ->
                        try {
                            if (profile.requiresAdminCode) {
                                val suppliedCode = code.orEmpty()
                                if (suppliedCode.length != 36) throw IllegalArgumentException("Introduce el código de 36 caracteres que generó el administrador para ${profile.title}.")
                                withContext(Dispatchers.IO) {
                                    DeviceAuthorizationRepository(this@MainActivity).bind(suppliedCode, profile)
                                }
                            }
                            InventoryProfile.select(this@MainActivity, profile)
                            recreate()
                            null
                        } catch (e: Exception) {
                            e.message ?: "No se pudo vincular el dispositivo."
                        }
                    }
                }
            } else {
                InventoryContent(onChangeInventory = { returnToProfileSelection() })
            }
        }
    }

    private fun returnToProfileSelection() {
        getSharedPreferences(InventoryProfile.PREFS, MODE_PRIVATE).edit()
            .remove(InventoryProfile.KEY_ACTIVE_PROFILE)
            .apply()
        val restart = Intent(this, MainActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
        }
        startActivity(restart)
        finish()
    }
}

@androidx.compose.runtime.Composable
private fun InventoryContent(onChangeInventory: () -> Unit) {
    val viewModel: InventoryViewModel = androidx.lifecycle.viewmodel.compose.viewModel()
    val isDarkTheme by viewModel.isDarkTheme.collectAsState()
    MyApplicationTheme(darkTheme = isDarkTheme) {
        MainInventoryScreen(viewModel = viewModel, onChangeInventory = onChangeInventory)
    }
}
