package com.example.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface AisleEntryDao {
    @Query("SELECT * FROM aisle_entries ORDER BY updatedAt DESC") fun observeAll(): Flow<List<AisleEntryEntity>>
    @Query("SELECT * FROM aisle_entries WHERE id = :id LIMIT 1") suspend fun getById(id: String): AisleEntryEntity?
    @Query("SELECT * FROM aisle_entries WHERE productId = :productId AND ((batchId IS NULL AND :batchId IS NULL) OR batchId = :batchId) LIMIT 1") suspend fun find(productId: String, batchId: String?): AisleEntryEntity?
    @Insert(onConflict = OnConflictStrategy.ABORT) suspend fun insert(item: AisleEntryEntity)
    @Update suspend fun update(item: AisleEntryEntity)
    @Query("DELETE FROM aisle_entries WHERE id = :id") suspend fun deleteById(id: String)
}
