package com.example.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface ProductRelationDao {
    @Query("SELECT * FROM product_relations ORDER BY createdAt DESC") fun observeAll(): Flow<List<ProductRelationEntity>>
    @Query("SELECT * FROM product_relations ORDER BY createdAt DESC") suspend fun getAll(): List<ProductRelationEntity>
    @Query("SELECT * FROM product_relations WHERE id = :id LIMIT 1") suspend fun getById(id: String): ProductRelationEntity?
    @Query("SELECT * FROM product_relations WHERE parentProductId = :parentId OR childProductId = :childId LIMIT 1") suspend fun findRelated(parentId: String, childId: String): ProductRelationEntity?
    @Insert(onConflict = OnConflictStrategy.ABORT) suspend fun insert(item: ProductRelationEntity)
    @Update suspend fun update(item: ProductRelationEntity)
    @Query("DELETE FROM product_relations WHERE id = :id") suspend fun deleteById(id: String)
}
