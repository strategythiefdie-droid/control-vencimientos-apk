package com.example.data

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey
import java.util.UUID

@Entity(
    tableName = "batches",
    foreignKeys = [
        ForeignKey(
            entity = ProductEntity::class,
            parentColumns = ["id"],
            childColumns = ["productId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index(value = ["productId"])]
)
data class BatchEntity(
    @PrimaryKey
    val id: String = UUID.randomUUID().toString(),
    val productId: String,
    val batchNumber: String? = null,
    val quantity: Double = 1.0,
    val expiryDate: String, // "YYYY-MM-DD"
    val createdAt: Long = System.currentTimeMillis()
) {
    constructor(
        id: String = UUID.randomUUID().toString(),
        productId: String,
        batchNumber: String? = null,
        quantity: Int,
        expiryDate: String,
        createdAt: Long = System.currentTimeMillis()
    ) : this(id, productId, batchNumber, quantity.toDouble(), expiryDate, createdAt)
}
