package com.example.data

import android.content.Context
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import com.example.profile.InventoryProfile
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import java.util.concurrent.TimeUnit

/** Offline-first sync for the normal TUSK inventory. The local Room database remains usable offline. */
class SupabaseSyncRepository(context: Context, private val inventory: InventoryRepository) {
    companion object {
        private const val BASE_URL = "https://hhncacdqvmxsilkpzniy.supabase.co"
        private const val PUBLISHABLE_KEY = "sb_publishable_Ebgl5rcG2WEq0Ra0BJiHjA_y1kkt-xz"
    }

    private val appContext = context.applicationContext
    private val prefs = appContext.getSharedPreferences("tusk_supabase_session", Context.MODE_PRIVATE)
    private val tombstones = SyncTombstoneStore(appContext)
    private val client = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(25, TimeUnit.SECONDS)
        .writeTimeout(25, TimeUnit.SECONDS)
        .build()
    private val jsonType = "application/json; charset=utf-8".toMediaType()

    data class Result(val products: Int, val batches: Int, val message: String)
    private data class Session(val accessToken: String, val userId: String)

    @Synchronized
    private fun saveSession(json: JSONObject) {
        val token = json.optString("access_token")
        val refresh = json.optString("refresh_token")
        val userId = json.optJSONObject("user")?.optString("id").orEmpty()
        if (token.isBlank() || userId.isBlank()) throw IllegalStateException("Supabase no devolvió una sesión TUSK válida.")
        val expiresIn = json.optLong("expires_in", 3600L)
        prefs.edit()
            .putString("access_token", token)
            .putString("refresh_token", refresh)
            .putString("user_id", userId)
            .putLong("expires_at", System.currentTimeMillis() + expiresIn * 1000L)
            .apply()
    }

    private fun rawRequest(path: String, token: String? = null): Request.Builder =
        Request.Builder().url("$BASE_URL$path")
            .header("apikey", PUBLISHABLE_KEY)
            .header("Accept", "application/json")
            .apply { if (token != null) header("Authorization", "Bearer $token") }

    private fun execute(request: Request): String {
        client.newCall(request).execute().use { response ->
            val body = response.body?.string().orEmpty()
            if (!response.isSuccessful) {
                val message = try {
                    val json = JSONObject(body)
                    json.optString("msg").ifBlank { json.optString("message", body) }
                } catch (_: Exception) { body }
                throw IllegalStateException("Supabase (${response.code}): ${message.ifBlank { "Error de servidor" }}")
            }
            return body
        }
    }

    private fun getSession(): Session {
        val token = prefs.getString("access_token", null)
        val userId = prefs.getString("user_id", null)
        val expiresAt = prefs.getLong("expires_at", 0L)
        if (!token.isNullOrBlank() && !userId.isNullOrBlank() && expiresAt > System.currentTimeMillis() + 60_000L) {
            return Session(token, userId)
        }

        val refresh = prefs.getString("refresh_token", null)
        if (!refresh.isNullOrBlank()) {
            try {
                val payload = JSONObject().put("refresh_token", refresh)
                val refreshed = JSONObject(execute(rawRequest("/auth/v1/token?grant_type=refresh_token")
                    .post(payload.toString().toRequestBody(jsonType)).build()))
                saveSession(refreshed)
                return Session(prefs.getString("access_token", "")!!, prefs.getString("user_id", "")!!)
            } catch (_: Exception) {
                // Do not silently create a different identity if an existing TUSK session is broken.
                throw IllegalStateException("No se pudo renovar la sesión TUSK. Revisa la configuración de Auth en Supabase.")
            }
        }

        // Supabase Auth must have Anonymous Sign-Ins enabled for this request to succeed.
        val payload = JSONObject().put("data", JSONObject().put("full_name", "TUSK"))
        val created = JSONObject(execute(rawRequest("/auth/v1/signup")
            .post(payload.toString().toRequestBody(jsonType)).build()))
        saveSession(created)
        return Session(prefs.getString("access_token", "")!!, prefs.getString("user_id", "")!!)
    }

    suspend fun syncInventory(): Result {
        val profile = InventoryProfile.selected(appContext)
            ?: throw IllegalStateException("Selecciona un perfil antes de sincronizar.")
        if (profile.isLocalTest) {
            val localProducts = inventory.snapshotProducts().size
            val localBatches = inventory.snapshotBatches().size
            return Result(localProducts, localBatches,
                "Usuario de prueba: $localProducts productos y $localBatches lotes guardados solo en este dispositivo. No se sincronizó con la nube.")
        }
        if (profile != InventoryProfile.TUSK) {
            return withContext(Dispatchers.IO) { syncSecondaryInventory(profile) }
        }
        val session = getSession()
        val pendingDeletes = tombstones.all().filter { it.first == "product" || it.first == "batch" }
        // Apply tombstones before downloading so offline deletions are not re-created locally.
        deleteRemoteTombstones(session, pendingDeletes)

        val remoteProducts = readArray("/rest/v1/products?select=id,user_id,workspace_id,name,barcode,plu,area_id,unit_cost,created_at&workspace_id=eq.TUSK", session.accessToken)
        val remoteBatches = readArray("/rest/v1/inventory_batches?select=id,user_id,workspace_id,product_id,batch_number,quantity,expiry_date,created_at&workspace_id=eq.TUSK", session.accessToken)
        val deletedProducts = pendingDeletes.filter { it.first == "product" }.map { it.second }.toSet()
        val deletedBatches = pendingDeletes.filter { it.first == "batch" }.map { it.second }.toSet()

        val localProductIds = inventory.snapshotProducts().map { it.id }.toSet()
        val localBatchIds = inventory.snapshotBatches().map { it.id }.toSet()
        val productsToImport = remoteProducts.mapNotNull { row ->
            val id = row.optString("id")
            if (id.isBlank() || id in localProductIds || id in deletedProducts) null else ProductEntity(
                id = id,
                areaId = row.optString("area_id").ifBlank { "otros" },
                name = row.optString("name", "Producto"),
                barcode = row.optString("barcode").takeUnless { it.isBlank() || it == "null" },
                plu = row.optString("plu").takeUnless { it.isBlank() || it == "null" },
                unitCost = row.optNullableDouble("unit_cost"),
                createdAt = parseMillis(row.optString("created_at"))
            )
        }
        val remoteProductIdSet = (remoteProducts.map { it.optString("id") }.filterNot { it in deletedProducts } + productsToImport.map { it.id }).toSet()
        val batchesToImport = remoteBatches.mapNotNull { row ->
            val id = row.optString("id")
            val productId = row.optString("product_id")
            if (id.isBlank() || id in localBatchIds || id in deletedBatches || (productId !in localProductIds && productId !in remoteProductIdSet)) null else BatchEntity(
                id = id,
                productId = productId,
                batchNumber = row.optString("batch_number").takeUnless { it.isBlank() || it == "null" },
                quantity = row.optDouble("quantity", 1.0),
                expiryDate = row.optString("expiry_date"),
                createdAt = parseMillis(row.optString("created_at"))
            )
        }
        inventory.mergeCloudInventory(productsToImport, batchesToImport)

        val localProducts = inventory.snapshotProducts()
        val localBatches = inventory.snapshotBatches()
        val productPayload = JSONArray()
        val batchesByProduct = localBatches.groupBy { it.productId }
        localProducts.forEach { product ->
            val productBatches = batchesByProduct[product.id].orEmpty()
            val totalQuantity = productBatches.sumOf { it.quantity }
            val earliestExpiry = productBatches.map { it.expiryDate }.filter { it.isNotBlank() }.minOrNull()
            val obj = JSONObject()
                .put("id", product.id)
                .put("user_id", session.userId)
                .put("workspace_id", "TUSK")
                .put("name", product.name)
                .put("barcode", product.barcode?.let { it as Any } ?: JSONObject.NULL)
                .put("plu", product.plu?.let { it as Any } ?: JSONObject.NULL)
                .put("area_id", product.areaId)
                .put("category", product.areaId)
                .put("unit_cost", product.unitCost?.let { it as Any } ?: JSONObject.NULL)
                .put("quantity", totalQuantity)
                .put("expiry_date", earliestExpiry?.let { it as Any } ?: JSONObject.NULL)
                .put("created_at", isoDate(product.createdAt))
            productPayload.put(obj)
        }
        upsert("/rest/v1/products?on_conflict=id", productPayload, session.accessToken)

        val batchPayload = JSONArray()
        localBatches.forEach { batch ->
            batchPayload.put(JSONObject()
                .put("id", batch.id)
                .put("user_id", session.userId)
                .put("workspace_id", "TUSK")
                .put("product_id", batch.productId)
                .put("batch_number", batch.batchNumber?.let { it as Any } ?: JSONObject.NULL)
                .put("quantity", batch.quantity)
                .put("expiry_date", batch.expiryDate)
                .put("created_at", isoDate(batch.createdAt)))
        }
        upsert("/rest/v1/inventory_batches?on_conflict=id", batchPayload, session.accessToken)
        tombstones.remove(pendingDeletes)
        return Result(localProducts.size, localBatches.size, "Sincronización completada: ${localProducts.size} productos y ${localBatches.size} lotes.")
    }

    /** Multi-inventory flow. Every request is authenticated by the server-side device binding. */
    private suspend fun syncSecondaryInventory(profile: InventoryProfile): Result {
        val deviceSync = DeviceAuthorizationRepository(appContext)
        val pendingDeletes = tombstones.all().filter { it.first == "product" || it.first == "batch" }
        // Delete remotely first so pull cannot resurrect records deleted while offline.
        pendingDeletes.filter { it.first == "batch" }.map { it.second }.chunked(2000).forEach { ids ->
            if (ids.isNotEmpty()) deviceSync.syncInventory(profile, "delete", JSONObject().put("deleteBatches", JSONArray(ids)))
        }
        pendingDeletes.filter { it.first == "product" }.map { it.second }.chunked(500).forEach { ids ->
            if (ids.isNotEmpty()) deviceSync.syncInventory(profile, "delete", JSONObject().put("deleteProducts", JSONArray(ids)))
        }

        val pulled = deviceSync.syncInventory(profile, "pull")
        val remoteProducts = pulled.optJSONArray("products") ?: JSONArray()
        val remoteBatches = pulled.optJSONArray("batches") ?: JSONArray()
        val deletedProducts = pendingDeletes.filter { it.first == "product" }.map { it.second }.toSet()
        val deletedBatches = pendingDeletes.filter { it.first == "batch" }.map { it.second }.toSet()
        val localProductsBefore = inventory.snapshotProducts()
        val localBatchesBefore = inventory.snapshotBatches()
        val localProductIds = localProductsBefore.map { it.id }.toSet()
        val localBatchIds = localBatchesBefore.map { it.id }.toSet()
        val productsToImport = (0 until remoteProducts.length()).mapNotNull { i ->
            val row = remoteProducts.optJSONObject(i) ?: return@mapNotNull null
            val id = row.optString("id")
            if (id.isBlank() || id in localProductIds || id in deletedProducts) null else ProductEntity(
                id = id,
                areaId = row.optString("area_id").ifBlank { "otros" },
                name = row.optString("name", "Producto"),
                barcode = row.optString("barcode").takeUnless { it.isBlank() || it == "null" },
                plu = row.optString("plu").takeUnless { it.isBlank() || it == "null" },
                unitCost = row.optNullableDouble("unit_cost"),
                createdAt = parseMillis(row.optString("created_at"))
            )
        }
        val availableProductIds = localProductIds + productsToImport.map { it.id }
        val batchesToImport = (0 until remoteBatches.length()).mapNotNull { i ->
            val row = remoteBatches.optJSONObject(i) ?: return@mapNotNull null
            val id = row.optString("id")
            val productId = row.optString("product_id")
            if (id.isBlank() || id in localBatchIds || id in deletedBatches || productId !in availableProductIds) null else BatchEntity(
                id = id, productId = productId,
                batchNumber = row.optString("batch_number").takeUnless { it.isBlank() || it == "null" },
                quantity = row.optDouble("quantity", 1.0), expiryDate = row.optString("expiry_date"),
                createdAt = parseMillis(row.optString("created_at"))
            )
        }
        inventory.mergeCloudInventory(productsToImport, batchesToImport)

        val localProducts = inventory.snapshotProducts()
        val localBatches = inventory.snapshotBatches()
        // Product rows first so the server can validate each batch's product relationship.
        localProducts.chunked(500).forEach { chunk ->
            val rows = JSONArray()
            chunk.forEach { p -> rows.put(JSONObject()
                .put("id", p.id).put("name", p.name).put("area_id", p.areaId)
                .put("barcode", p.barcode?.let { it as Any } ?: JSONObject.NULL)
                .put("plu", p.plu?.let { it as Any } ?: JSONObject.NULL)
                .put("unit_cost", p.unitCost?.let { it as Any } ?: JSONObject.NULL)
                .put("created_at", isoDate(p.createdAt)))
            }
            deviceSync.syncInventory(profile, "push", JSONObject().put("products", rows))
        }
        localBatches.chunked(2000).forEach { chunk ->
            val rows = JSONArray()
            chunk.forEach { b -> rows.put(JSONObject()
                .put("id", b.id).put("product_id", b.productId)
                .put("batch_number", b.batchNumber?.let { it as Any } ?: JSONObject.NULL)
                .put("quantity", b.quantity).put("expiry_date", b.expiryDate)
                .put("created_at", isoDate(b.createdAt)))
            }
            deviceSync.syncInventory(profile, "push", JSONObject().put("batches", rows))
        }
        tombstones.remove(pendingDeletes)
        return Result(localProducts.size, localBatches.size,
            "Sincronización completada para ${profile.title}: ${localProducts.size} productos y ${localBatches.size} lotes.")
    }

    private fun readArray(path: String, token: String): List<JSONObject> {
        val array = JSONArray(execute(rawRequest(path, token).get().build()))
        return (0 until array.length()).mapNotNull { array.optJSONObject(it) }
    }

    private fun upsert(path: String, array: JSONArray, token: String) {
        if (array.length() == 0) return
        val req = rawRequest(path, token)
            .header("Prefer", "resolution=merge-duplicates,return=minimal")
            .post(array.toString().toRequestBody(jsonType)).build()
        execute(req)
    }

    private fun deleteRemoteTombstones(session: Session, deletes: List<Pair<String, String>>) {
        val batches = deletes.filter { it.first == "batch" }.map { it.second }.filter { it.matches(Regex("[0-9a-fA-F-]{36}")) }
        val products = deletes.filter { it.first == "product" }.map { it.second }.filter { it.matches(Regex("[0-9a-fA-F-]{36}")) }
        batches.chunked(50).forEach { ids ->
            if (ids.isNotEmpty()) execute(rawRequest("/rest/v1/inventory_batches?workspace_id=eq.TUSK&id=in.(${ids.joinToString(",")})", session.accessToken).delete().build())
        }
        products.chunked(50).forEach { ids ->
            if (ids.isNotEmpty()) execute(rawRequest("/rest/v1/products?workspace_id=eq.TUSK&id=in.(${ids.joinToString(",")})", session.accessToken).delete().build())
        }
    }

    private fun JSONObject.optNullableDouble(name: String): Double? =
        if (isNull(name) || !has(name)) null else optDouble(name).takeUnless { it.isNaN() }

    private fun parseMillis(value: String): Long = try {
        val fmt = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss", Locale.US).apply { timeZone = TimeZone.getTimeZone("UTC") }
        fmt.parse(value.take(19))?.time ?: System.currentTimeMillis()
    } catch (_: Exception) { System.currentTimeMillis() }

    private fun isoDate(millis: Long): String = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", Locale.US)
        .apply { timeZone = TimeZone.getTimeZone("UTC") }.format(Date(millis))
}
