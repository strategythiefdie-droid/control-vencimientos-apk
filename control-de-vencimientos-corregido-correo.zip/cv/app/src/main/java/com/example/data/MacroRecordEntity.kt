package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.util.UUID

@Entity(tableName = "macro_records")
data class MacroRecordEntity(
    @PrimaryKey
    val id: String = UUID.randomUUID().toString(),
    val areaId: String,
    val plu: String? = null,
    val name: String,
    val startDate: String? = null, // "YYYY-MM-DD"
    val endDate: String? = null,   // "YYYY-MM-DD"
    val renewDate: String? = null, // "YYYY-MM-DD" (usually endDate - 2 days)
    val expiryDate: String? = null, // vencimiento físico del producto/lote
    val quantity: Double? = null, // Cantidad_Vencer importada desde la macro
    val discountPercent: Double? = null, // PorcentajeDescue importado
    val unmatched: Boolean = false,
    val updatedAt: Long = System.currentTimeMillis()
)
