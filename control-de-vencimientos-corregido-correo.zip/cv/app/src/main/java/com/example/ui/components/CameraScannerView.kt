package com.example.ui.components

import android.content.Context
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.util.Log
import android.view.ViewGroup
import androidx.annotation.OptIn
import androidx.camera.core.Camera
import androidx.camera.core.CameraSelector
import androidx.camera.core.ExperimentalGetImage
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.FlashOff
import androidx.compose.material.icons.filled.FlashOn
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.google.mlkit.vision.barcode.common.Barcode
import com.google.mlkit.vision.barcode.BarcodeScannerOptions
import com.google.mlkit.vision.barcode.BarcodeScanning
import com.google.mlkit.vision.common.InputImage
import java.util.concurrent.Executors

@Composable
fun CameraScannerView(
    onBarcodeDetected: (String) -> Unit,
    continuousScan: Boolean = false,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current

    var camera by remember { mutableStateOf<Camera?>(null) }
    var activeCameraProvider by remember { mutableStateOf<ProcessCameraProvider?>(null) }
    var isTorchOn by remember { mutableStateOf(false) }
    var hasDetected by remember { mutableStateOf(false) }

    val cameraExecutor = remember { Executors.newSingleThreadExecutor() }
    // Limita el detector a formatos habituales de productos comerciales. Evita que
    // códigos QR u otros formatos del empaque se confundan con el EAN del producto.
    val barcodeOptions = remember {
        BarcodeScannerOptions.Builder()
            .setBarcodeFormats(
                Barcode.FORMAT_EAN_13,
                Barcode.FORMAT_EAN_8,
                Barcode.FORMAT_UPC_A,
                Barcode.FORMAT_UPC_E,
                Barcode.FORMAT_CODE_128,
                Barcode.FORMAT_CODE_39,
                Barcode.FORMAT_ITF
            )
            .build()
    }
    val barcodeScanner = remember { BarcodeScanning.getClient(barcodeOptions) }

    DisposableEffect(Unit) {
        onDispose {
            try {
                activeCameraProvider?.unbindAll()
            } catch (e: Exception) {
                Log.e("CameraScannerView", "Error unbinding camera", e)
            }
            try {
                cameraExecutor.shutdown()
            } catch (e: Exception) {
                Log.e("CameraScannerView", "Error shutting down camera executor", e)
            }
            try { barcodeScanner.close() } catch (e: Exception) { Log.e("CameraScannerView", "Error closing barcode scanner", e) }
        }
    }

    Box(
        modifier = modifier
            .fillMaxWidth()
            .height(280.dp)
            .clip(RoundedCornerShape(16.dp))
            .background(Color.Black)
            .border(2.dp, MaterialTheme.colorScheme.primary, RoundedCornerShape(16.dp))
    ) {
        AndroidView(
            factory = { ctx ->
                val previewView = PreviewView(ctx).apply {
                    layoutParams = ViewGroup.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.MATCH_PARENT
                    )
                    scaleType = PreviewView.ScaleType.FILL_CENTER
                    // Use COMPATIBLE (TextureView) instead of PERFORMANCE (SurfaceView)
                    // to prevent SurfaceView BufferQueue abandonment when dismissing or in dialogs
                    implementationMode = PreviewView.ImplementationMode.COMPATIBLE
                }

                val cameraProviderFuture = ProcessCameraProvider.getInstance(ctx)
                cameraProviderFuture.addListener({
                    try {
                        val cameraProvider = cameraProviderFuture.get()
                        activeCameraProvider = cameraProvider

                        val preview = Preview.Builder().build().also {
                            it.surfaceProvider = previewView.surfaceProvider
                        }

                        val imageAnalysis = ImageAnalysis.Builder()
                            // Resolución mayor para que los bordes de las barras sean más claros.
                            .setTargetResolution(android.util.Size(1280, 720))
                            .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                            .build()

                        var lastBarcode = ""
                        var lastBarcodeSeenAt = 0L

                        imageAnalysis.setAnalyzer(cameraExecutor) { imageProxy ->
                            if (!continuousScan && hasDetected) {
                                imageProxy.close()
                                return@setAnalyzer
                            }
                            processImageProxy(imageProxy, barcodeScanner) { barcodeValue ->
                                val now = System.currentTimeMillis()
                                if (continuousScan) {
                                    if (barcodeValue.isNullOrBlank()) {
                                        // El mismo código solo cuenta una vez mientras permanezca delante de la cámara.
                                        // Debe desaparecer brevemente del visor antes de volver a contarse.
                                        if (now - lastBarcodeSeenAt > 650L) lastBarcode = ""
                                    } else {
                                        lastBarcodeSeenAt = now
                                        if (barcodeValue != lastBarcode) {
                                            lastBarcode = barcodeValue
                                            vibrateDevice(context)
                                            ContextCompat.getMainExecutor(context).execute { onBarcodeDetected(barcodeValue) }
                                        }
                                    }
                                } else if (!barcodeValue.isNullOrBlank() && !hasDetected) {
                                    hasDetected = true
                                    vibrateDevice(context)
                                    try { cameraProvider.unbindAll() } catch (_: Exception) {}
                                    ContextCompat.getMainExecutor(context).execute { onBarcodeDetected(barcodeValue) }
                                }
                            }
                        }

                        val cameraSelector = CameraSelector.DEFAULT_BACK_CAMERA

                        cameraProvider.unbindAll()
                        camera = cameraProvider.bindToLifecycle(
                            lifecycleOwner,
                            cameraSelector,
                            preview,
                            imageAnalysis
                        )
                    } catch (exc: Exception) {
                        Log.e("CameraScannerView", "Error al inicializar cámara", exc)
                    }
                }, ContextCompat.getMainExecutor(ctx))

                previewView
            },
            modifier = Modifier.fillMaxSize()
        )

        // Viewfinder overlay frame
        Box(
            modifier = Modifier
                .size(width = 220.dp, height = 120.dp)
                .align(Alignment.Center)
                .border(2.dp, Color(0xFF70C8FF), RoundedCornerShape(12.dp))
                .background(Color(0x2270C8FF))
        )

        // Instruction label at bottom
        Box(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(bottom = 12.dp)
                .clip(RoundedCornerShape(8.dp))
                .background(Color(0xCC080B12))
                .padding(horizontal = 12.dp, vertical = 6.dp)
        ) {
            Text(
                text = "Enfoca el código de barras dentro del recuadro",
                fontSize = 11.sp,
                fontWeight = FontWeight.Medium,
                color = Color.White
            )
        }

        // Torch toggle button at top right
        IconButton(
            onClick = {
                val nextTorch = !isTorchOn
                isTorchOn = nextTorch
                camera?.cameraControl?.enableTorch(nextTorch)
            },
            modifier = Modifier
                .align(Alignment.TopEnd)
                .padding(8.dp)
                .background(Color(0x88000000), RoundedCornerShape(20.dp))
        ) {
            Icon(
                imageVector = if (isTorchOn) Icons.Default.FlashOn else Icons.Default.FlashOff,
                contentDescription = "Flash",
                tint = if (isTorchOn) Color(0xFFFFB148) else Color.White,
                modifier = Modifier.size(20.dp)
            )
        }

    }
}


@OptIn(ExperimentalGetImage::class)
private fun processImageProxy(
    imageProxy: ImageProxy,
    barcodeScanner: com.google.mlkit.vision.barcode.BarcodeScanner,
    onResult: (String?) -> Unit
) {
    val mediaImage = imageProxy.image
    if (mediaImage != null) {
        val image = InputImage.fromMediaImage(mediaImage, imageProxy.imageInfo.rotationDegrees)
        barcodeScanner.process(image)
            .addOnSuccessListener { barcodes ->
                // Prioriza EAN/UPC de productos y el código más cercano al centro del visor,
                // en vez de aceptar simplemente el primer resultado devuelto por ML Kit.
                val centerX = imageProxy.width / 2f
                val centerY = imageProxy.height / 2f
                val preferred = barcodes
                    .filter { !it.rawValue.isNullOrBlank() }
                    .filter { barcode ->
                        when (barcode.format) {
                            Barcode.FORMAT_EAN_13, Barcode.FORMAT_EAN_8, Barcode.FORMAT_UPC_A ->
                                isValidRetailCheckDigit(barcode.rawValue.orEmpty(), barcode.format)
                            Barcode.FORMAT_UPC_E, Barcode.FORMAT_CODE_128,
                            Barcode.FORMAT_CODE_39, Barcode.FORMAT_ITF -> true
                            else -> false
                        }
                    }
                    .sortedWith(compareBy<Barcode> {
                        when (it.format) {
                            Barcode.FORMAT_EAN_13, Barcode.FORMAT_EAN_8,
                            Barcode.FORMAT_UPC_A, Barcode.FORMAT_UPC_E -> 0
                            else -> 1
                        }
                    }.thenBy { barcode ->
                        val box = barcode.boundingBox
                        if (box == null) Float.MAX_VALUE else {
                            val dx = box.centerX() - centerX
                            val dy = box.centerY() - centerY
                            dx * dx + dy * dy
                        }
                    })
                val selected = preferred.firstOrNull()
                onResult(selected?.rawValue)
            }
            .addOnCompleteListener {
                try {
                    imageProxy.close()
                } catch (_: Exception) {}
            }
    } else {
        onResult(null)
        try {
            imageProxy.close()
        } catch (_: Exception) {}
    }
}


/** Rechaza lecturas EAN/UPC con dígito de control incorrecto. */
private fun isValidRetailCheckDigit(value: String, format: Int): Boolean {
    val digits = value.filter { it.isDigit() }
    val expectedLength = when (format) {
        Barcode.FORMAT_EAN_13 -> 13
        Barcode.FORMAT_EAN_8 -> 8
        Barcode.FORMAT_UPC_A -> 12
        else -> return true
    }
    if (digits.length != expectedLength || digits != value) return false
    val body = digits.dropLast(1)
    val sum = body.reversed().mapIndexed { index, char ->
        char.digitToInt() * if (index % 2 == 0) 3 else 1
    }.sum()
    val checkDigit = (10 - (sum % 10)) % 10
    return checkDigit == digits.last().digitToInt()
}

private fun vibrateDevice(context: Context) {
    try {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val vibratorManager = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
            vibratorManager?.defaultVibrator?.vibrate(VibrationEffect.createOneShot(100, VibrationEffect.DEFAULT_AMPLITUDE))
        } else {
            @Suppress("DEPRECATION")
            val vibrator = context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
            @Suppress("DEPRECATION")
            vibrator?.vibrate(100)
        }
    } catch (_: Exception) {}
}
