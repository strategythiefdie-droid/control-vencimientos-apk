package com.example.ui.theme

import android.app.Activity
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

private val DarkColorScheme = darkColorScheme(
    primary = BrandBlueDark,
    onPrimary = DarkBg,
    primaryContainer = BrandBlueSoftDark,
    onPrimaryContainer = BrandBlueDark,
    secondary = StatusSoonDark,
    onSecondary = DarkBg,
    secondaryContainer = StatusSoonBgDark,
    onSecondaryContainer = StatusSoonDark,
    tertiary = StatusMacroDark,
    onTertiary = DarkBg,
    tertiaryContainer = StatusMacroBgDark,
    onTertiaryContainer = StatusMacroDark,
    error = StatusExpiredDark,
    onError = DarkBg,
    errorContainer = StatusExpiredBgDark,
    onErrorContainer = StatusExpiredDark,
    background = DarkBg,
    onBackground = DarkTextPrimary,
    surface = DarkSurface,
    onSurface = DarkTextPrimary,
    surfaceVariant = DarkSurfaceVariant,
    onSurfaceVariant = DarkTextSecondary,
    outline = DarkBorder
)

private val LightColorScheme = lightColorScheme(
    primary = BrandBlueLight,
    onPrimary = LightSurface,
    primaryContainer = BrandBlueSoftLight,
    onPrimaryContainer = BrandBlueLight,
    secondary = StatusSoonLight,
    onSecondary = LightSurface,
    secondaryContainer = StatusSoonBgLight,
    onSecondaryContainer = StatusSoonLight,
    tertiary = StatusMacroLight,
    onTertiary = LightSurface,
    tertiaryContainer = StatusMacroBgLight,
    onTertiaryContainer = StatusMacroLight,
    error = StatusExpiredLight,
    onError = LightSurface,
    errorContainer = StatusExpiredBgLight,
    onErrorContainer = StatusExpiredLight,
    background = LightBg,
    onBackground = LightTextPrimary,
    surface = LightSurface,
    onSurface = LightTextPrimary,
    surfaceVariant = LightSurfaceVariant,
    onSurfaceVariant = LightTextSecondary,
    outline = LightBorder
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme
    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as? Activity)?.window
            if (window != null) {
                WindowCompat.getInsetsController(window, view).isAppearanceLightStatusBars = !darkTheme
                WindowCompat.getInsetsController(window, view).isAppearanceLightNavigationBars = !darkTheme
            }
        }
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
