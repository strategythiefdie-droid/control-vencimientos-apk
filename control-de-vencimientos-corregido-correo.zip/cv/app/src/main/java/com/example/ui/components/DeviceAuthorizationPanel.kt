package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.CloudDeviceBinding
import com.example.data.CloudDeviceInvite
import com.example.profile.InventoryProfile

@Composable
fun DeviceAuthorizationPanel(
    canManage: Boolean,
    invite: CloudDeviceInvite?,
    bindings: List<CloudDeviceBinding>,
    loading: Boolean,
    message: String?,
    onGenerate: (String) -> Unit,
    onCopyCode: (String) -> Unit,
    onShareCode: (CloudDeviceInvite) -> Unit,
    onRefreshBindings: () -> Unit,
    onRevoke: (CloudDeviceBinding) -> Unit,
    modifier: Modifier = Modifier
) {
    var selectedWorkspace by remember { mutableStateOf(InventoryProfile.ACT1) }
    var showWorkspaceMenu by remember { mutableStateOf(false) }
    var pendingRevocation by remember { mutableStateOf<CloudDeviceBinding?>(null) }
    val linkableProfiles = listOf(
        InventoryProfile.ACT1,
        InventoryProfile.ACT2,
        InventoryProfile.ACT3,
        InventoryProfile.ACT4
    )

    Card(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f))
    ) {
        Column(
            modifier = Modifier.fillMaxWidth().padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Text("VINCULAR DISPOSITIVOS", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
            Text(
                "Genera un código para permitir que otro dispositivo entre a un inventario ACT.",
                style = MaterialTheme.typography.bodyMedium
            )
            if (!canManage) {
                Text(
                    "Para generar códigos, inicia sesión como administrador con conexión a internet. El acceso administrativo sin conexión solo permite funciones locales.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = MaterialTheme.colorScheme.surface,
                    modifier = Modifier.weight(1f)
                ) {
                    TextButton(
                        enabled = canManage && !loading,
                        onClick = { showWorkspaceMenu = true },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(selectedWorkspace.title, fontWeight = FontWeight.SemiBold)
                    }
                }
                DropdownMenu(expanded = showWorkspaceMenu, onDismissRequest = { showWorkspaceMenu = false }) {
                    linkableProfiles.forEach { profile ->
                        DropdownMenuItem(
                            text = { Text(profile.title) },
                            onClick = {
                                selectedWorkspace = profile
                                showWorkspaceMenu = false
                            }
                        )
                    }
                }
                Button(
                    enabled = canManage && !loading,
                    onClick = { onGenerate(selectedWorkspace.id) }
                ) {
                    Text(if (loading) "Procesando…" else "Generar código")
                }
            }

            if (invite != null) {
                Spacer(Modifier.height(2.dp))
                Surface(
                    shape = RoundedCornerShape(14.dp),
                    color = MaterialTheme.colorScheme.surface,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.fillMaxWidth().padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text("Código para ${invite.workspaceName}", fontWeight = FontWeight.SemiBold)
                        Text(
                            invite.code.chunked(6).joinToString(" "),
                            textAlign = TextAlign.Center,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Text(
                            "Válido por 10 minutos · uso único. Caducidad del servidor: ${invite.expiresAt}",
                            style = MaterialTheme.typography.bodySmall,
                            textAlign = TextAlign.Center,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedButton(onClick = { onCopyCode(invite.code) }, enabled = canManage) {
                                Text("Copiar código")
                            }
                            Button(onClick = { onShareCode(invite) }, enabled = canManage) {
                                Text("Compartir")
                            }
                        }
                    }
                }
                Text(
                    "Compartir abre las aplicaciones disponibles del teléfono para enviar el código. Caduca en 10 minutos y la persona debe seleccionar el mismo inventario.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            if (message != null) {
                Text(message, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text("Dispositivos vinculados", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                OutlinedButton(
                    enabled = canManage && !loading,
                    onClick = onRefreshBindings
                ) { Text("Actualizar") }
            }

            if (bindings.isEmpty()) {
                Text("No hay dispositivos para mostrar o todavía no se han consultado.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            } else {
                bindings.forEach { binding ->
                    Row(
                        modifier = Modifier.fillMaxWidth().background(
                            MaterialTheme.colorScheme.surface,
                            RoundedCornerShape(12.dp)
                        ).padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                            Text(binding.label.ifBlank { "Dispositivo Android" }, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                            Text(binding.workspaceId.replace('_', ' '), fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text("ID: ${binding.deviceHash.take(10)}…", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text(
                                if (binding.revokedAt == null) "Activo" else "Revocado",
                                fontSize = 10.sp,
                                color = if (binding.revokedAt == null) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error
                            )
                        }
                        if (binding.revokedAt == null) {
                            TextButton(enabled = canManage && !loading, onClick = { pendingRevocation = binding }) {
                                Text("Revocar", color = MaterialTheme.colorScheme.error)
                            }
                        }
                    }
                }
            }
        }
    }

    val revokeTarget = pendingRevocation
    if (revokeTarget != null) {
        AlertDialog(
            onDismissRequest = { pendingRevocation = null },
            title = { Text("Revocar dispositivo") },
            text = { Text("El dispositivo ${revokeTarget.label.ifBlank { revokeTarget.deviceHash.take(10) }} perderá la autorización para sincronizar ${revokeTarget.workspaceId.replace('_', ' ')}. ¿Continuar?") },
            confirmButton = {
                TextButton(onClick = {
                    pendingRevocation = null
                    onRevoke(revokeTarget)
                }) { Text("Revocar acceso", color = MaterialTheme.colorScheme.error) }
            },
            dismissButton = { TextButton(onClick = { pendingRevocation = null }) { Text("Cancelar") } }
        )
    }
}
