package com.example.util

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.Ringtone
import android.media.RingtoneManager
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import androidx.core.app.NotificationCompat
import com.example.MainActivity
import com.example.R

object NotificationHelper {
    const val CHANNEL_ID = "vencimientos_alarm_sound_v4"
    const val CHANNEL_NAME = "Alarmas de Vencimiento de Lotes"
    const val EXPIRY_NOTIFICATION_ID = 1030
    const val SPECIAL_EXPIRY_CHANNEL_ID = "refrigerados_expiry_special_v1"
    const val SPECIAL_EXPIRY_NOTIFICATION_ID = 1031

    private var lastSoundTimestamp = 0L
    private var lastNotificationTimestamp = 0L
    private const val MIN_SOUND_INTERVAL_MS = 15_000L
    private const val MIN_NOTIFICATION_INTERVAL_MS = 60_000L // 1 minuto de protección para no duplicar notificaciones idénticas

    fun getAlarmSoundUri(): Uri {
        return RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
            ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE)
            ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
    }

    fun createNotificationChannel(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

            val audioAttributes = AudioAttributes.Builder()
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .setUsage(AudioAttributes.USAGE_ALARM)
                .setFlags(AudioAttributes.FLAG_AUDIBILITY_ENFORCED)
                .build()

            val channel = NotificationChannel(
                CHANNEL_ID,
                CHANNEL_NAME,
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Alarmas sonoras para productos y lotes a 30 días o menos de su fecha de vencimiento"
                enableLights(true)
                enableVibration(true)
                vibrationPattern = longArrayOf(0, 450, 150, 450, 150, 450, 150, 600)
                setSound(getAlarmSoundUri(), audioAttributes)
            }

            notificationManager.createNotificationChannel(channel)

            // Canal independiente para la alerta de carnes y lácteos. Usa el tono de
            // notificación del sistema, distinto del tono de alarma de los avisos normales.
            val specialSound = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
                ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE)
            val specialChannel = NotificationChannel(
                SPECIAL_EXPIRY_CHANNEL_ID,
                "Alerta especial: carnes y lácteos",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Aviso prioritario 8 días antes del vencimiento de carnes, pescados y lácteos"
                enableLights(true)
                enableVibration(true)
                vibrationPattern = longArrayOf(0, 250, 100, 250, 100, 700)
                setSound(specialSound, AudioAttributes.Builder()
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .setUsage(AudioAttributes.USAGE_NOTIFICATION_EVENT)
                    .build())
            }
            notificationManager.createNotificationChannel(specialChannel)
        }
    }

    /**
     * Emite una alarma sonora y vibración corta una única vez.
     * Diseñado para el botón de prueba rápida en la barra superior.
     */
    @Synchronized
    fun playShortAlarmSound(context: Context) {
        val now = System.currentTimeMillis()
        if (now - lastSoundTimestamp < MIN_SOUND_INTERVAL_MS) {
            return
        }
        lastSoundTimestamp = now

        try {
            triggerShortAlarmVibration(context)

            val soundUri = getAlarmSoundUri()
            val ringtone: Ringtone? = RingtoneManager.getRingtone(context.applicationContext, soundUri)
            if (ringtone != null) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                    ringtone.audioAttributes = AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_ALARM)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                        .setFlags(AudioAttributes.FLAG_AUDIBILITY_ENFORCED)
                        .build()
                }
                ringtone.play()

                Handler(Looper.getMainLooper()).postDelayed({
                    try {
                        if (ringtone.isPlaying) {
                            ringtone.stop()
                        }
                    } catch (_: Exception) {}
                }, 2500)
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    @Suppress("DEPRECATION")
    private fun triggerShortAlarmVibration(context: Context) {
        try {
            val timings = longArrayOf(0, 400, 120, 400, 120, 400)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val vibratorManager = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
                vibratorManager?.defaultVibrator?.vibrate(VibrationEffect.createWaveform(timings, -1))
            } else {
                val vibrator = context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    vibrator?.vibrate(VibrationEffect.createWaveform(timings, -1))
                } else {
                    vibrator?.vibrate(timings, -1)
                }
            }
        } catch (_: Exception) {}
    }

    /**
     * Envía UNA SOLA notificación agrupada con sonido y vibración únicos.
     * Si hay múltiples productos, todos van consolidados en esta única notificación.
     */
    fun sendExpiryNotification(
        context: Context,
        title: String,
        body: String,
        notificationId: Int = EXPIRY_NOTIFICATION_ID
    ) {
        val now = System.currentTimeMillis()
        if (now - lastNotificationTimestamp < MIN_NOTIFICATION_INTERVAL_MS) {
            return
        }
        lastNotificationTimestamp = now

        createNotificationChannel(context)

        val intent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }

        val pendingIntent = PendingIntent.getActivity(
            context,
            notificationId,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val soundUri = getAlarmSoundUri()

        // El sonido y vibración son gestionados por el canal de notificación del sistema
        // garantizando que suena EXACTAMENTE UNA VEZ por evento, sin duplicarse.
        val builder = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentTitle(title)
            .setContentText(body.lines().firstOrNull() ?: title)
            .setStyle(NotificationCompat.BigTextStyle().bigText(body))
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setSound(soundUri)
            .setVibrate(longArrayOf(0, 450, 150, 450, 150, 450, 150, 600))
            .setContentIntent(pendingIntent)
            .setAutoCancel(true)

        val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        try {
            notificationManager.notify(notificationId, builder.build())
        } catch (e: SecurityException) {
            e.printStackTrace()
        }
    }

    /** Notificación agrupada para lotes refrigerados que vencen en exactamente 8 días. */
    fun sendSpecialExpiryNotification(context: Context, title: String, body: String) {
        createNotificationChannel(context)
        val intent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val pendingIntent = PendingIntent.getActivity(
            context,
            SPECIAL_EXPIRY_NOTIFICATION_ID,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val builder = NotificationCompat.Builder(context, SPECIAL_EXPIRY_CHANNEL_ID)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentTitle(title)
            .setContentText(body.lines().firstOrNull() ?: title)
            .setStyle(NotificationCompat.BigTextStyle().bigText(body))
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setContentIntent(pendingIntent)
            .setAutoCancel(true)
        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        try {
            manager.notify(SPECIAL_EXPIRY_NOTIFICATION_ID, builder.build())
        } catch (e: SecurityException) {
            e.printStackTrace()
        }
    }

}
