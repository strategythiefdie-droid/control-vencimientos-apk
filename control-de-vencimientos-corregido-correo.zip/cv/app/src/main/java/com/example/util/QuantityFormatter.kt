package com.example.util

import java.util.Locale

object QuantityFormatter {
    /**
     * Formatea una cantidad o peso para visualización limpia:
     * - Si es un número entero exacto (ej. 12.0), devuelve "12"
     * - Si tiene decimales (ej. 0.252), devuelve "0.252" sin ceros a la derecha innecesarios
     */
    fun format(quantity: Double): String {
        return if (quantity % 1.0 == 0.0) {
            quantity.toLong().toString()
        } else {
            String.format(Locale.US, "%.4f", quantity).trimEnd('0').trimEnd('.')
        }
    }

    /**
     * Devuelve el valor formateado con la unidad deseada ("uds", "kg", etc.)
     */
    fun formatWithUnit(quantity: Double, unit: String = "uds"): String {
        return "${format(quantity)} $unit"
    }

    /**
     * Determina si el área corresponde a Frutas y Verduras (pesable)
     */
    fun isFruitArea(areaId: String?): Boolean {
        return areaId?.lowercase() == "fruver"
    }

    /**
     * Retorna la unidad de medida según el área: "kg" para fruver, "uds" para los demás
     */
    fun unitForArea(areaId: String?): String {
        return if (isFruitArea(areaId)) "kg" else "uds"
    }

    /**
     * Formatea la cantidad con la unidad correcta según el área (ej. "0.252 kg" o "12 uds")
     */
    fun formatForArea(quantity: Double, areaId: String?): String {
        return "${format(quantity)} ${unitForArea(areaId)}"
    }

    /**
     * Formatea el total con la unidad correcta según el área (ej. "0.252 kg totales" o "12 uds totales")
     */
    fun formatTotalForArea(quantity: Double, areaId: String?): String {
        val suffix = if (isFruitArea(areaId)) "kg totales" else "uds totales"
        return "${format(quantity)} $suffix"
    }

    /**
     * Parsea un string admitiendo tanto punto como coma decimal (ej. "0.252" o "0,252").
     * Retorna null si no es un número válido estrictamente mayor a 0.
     */
    fun parseQuantity(input: String): Double? {
        val clean = input.trim().replace(',', '.')
        val value = clean.toDoubleOrNull()
        return if (value != null && value > 0.0) value else null
    }
}
