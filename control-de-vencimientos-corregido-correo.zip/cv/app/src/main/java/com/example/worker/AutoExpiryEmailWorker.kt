package com.example.worker

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import com.example.profile.InventoryProfile
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/** Sends one daily inventory snapshot to the Apps Script email service. */
class AutoExpiryEmailWorker(context: Context, params: WorkerParameters) : CoroutineWorker(context, params) {
    private val endpoint = "https://script.google.com/macros/s/AKfycbzIcUoVT0SnCmR3K52odcxzkr_N4D_De7oXM1RA21d6vrWk1C0igTJdlYMtze95fXG9/exec"
    private val client = OkHttpClient.Builder()
        .followRedirects(true).followSslRedirects(true)
        .connectTimeout(20, TimeUnit.SECONDS).readTimeout(25, TimeUnit.SECONDS)
        .writeTimeout(20, TimeUnit.SECONDS).build()

    override suspend fun doWork(): Result = withContext(Dispatchers.IO) {
        val prefs = applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val now = System.currentTimeMillis()
        try {
            val activeProfile = InventoryProfile.selected(applicationContext)
            if (activeProfile == null || activeProfile.isLocalTest) {
                // No sincronizar ni enviar correos reales desde el usuario de prueba.
                return@withContext Result.success()
            }

            // El Apps Script consulta Supabase. Sincronizar antes evita que un lote recién
            // agregado o editado solo en Room quede fuera del cálculo de alertas.
            val inventoryRepository = com.example.data.InventoryRepository(applicationContext)
            val syncRepository = com.example.data.SupabaseSyncRepository(applicationContext, inventoryRepository)
            val syncResult = syncRepository.syncInventory()
            val products = inventoryRepository.getAllProductsWithBatchesDirect()
            val inventory = JSONArray()
            products.forEach { p ->
                p.batches.forEach { b ->
                    inventory.put(JSONObject().apply {
                        put("id", p.id)
                        put("batchId", b.id)
                        put("name", p.name)
                        put("barcode", p.barcode ?: "")
                        put("plu", p.plu ?: "")
                        put("qty", b.quantity)
                        put("date", b.expiryDate)
                        put("area", p.areaId)
                    })
                }
            }

            val payload = JSONObject().apply {
                put("token", "CARULLA_ALERTAS_V1")
                put("siteId", "calle_roman_app")
                put("inventory", inventory)
                // "sync" deja claro que es la revisión automática; sendAlert está
                // reservado para la orden manual que pulsa el usuario.
                put("action", "sync")
                put("manual", false)
                put("requestId", "AUTO_${now}")
            }
            val request = Request.Builder().url(endpoint)
                .post(payload.toString().toRequestBody("application/json; charset=utf-8".toMediaType()))
                .build()

            client.newCall(request).execute().use { response ->
                val body = response.body?.string().orEmpty()
                val json = runCatching { JSONObject(body) }.getOrNull()
                val counts = json?.optJSONObject("counts")
                val ok = response.isSuccessful && json?.optBoolean("ok", false) == true
                val accepted = if (counts?.has("emails_accepted") == true) {
                    counts.optInt("emails_accepted", 0)
                } else if (json?.optBoolean("sent", false) == true) 1 else 0
                val failures = counts?.optInt("email_failures", 0) ?: 0
                val general = counts?.optInt("general_candidates", 0) ?: 0
                val special = counts?.optInt("special_candidates", 0) ?: 0
                val candidates = general + special
                val duplicates = counts?.optInt("duplicates", 0) ?: 0
                val error = json?.optString("error")?.takeIf { it.isNotBlank() }
                val message = json?.optString("message")?.takeIf { it.isNotBlank() }
                val sent = accepted > 0
                val status = when {
                    sent && failures > 0 -> "Envío automático parcial: Google aceptó $accepted correo(s), $failures fallaron."
                    sent -> "Correo(s) automático(s) aceptado(s) por Google: $accepted. Alertas candidatas: $candidates."
                    failures > 0 -> "Falló el envío automático ($failures error(es)). ${error ?: message.orEmpty()}"
                    ok && candidates == 0 -> "Revisión automática completada: Apps Script no encontró lotes elegibles."
                    ok && duplicates > 0 -> "Había $candidates alertas candidatas, pero $duplicates ya estaban registradas; no se reenviaron correos duplicados."
                    ok -> message ?: "Apps Script revisó el inventario, pero no confirmó correos nuevos."
                    else -> "No se pudo confirmar la revisión automática (HTTP ${response.code}). ${error ?: message ?: body.take(180)}"
                }
                saveStatus(prefs, now, sent, "$status Sincronización: ${syncResult.products} productos y ${syncResult.batches} lotes.", candidates)
                if (ok) Result.success() else Result.retry()
            }
        } catch (e: Exception) {
            saveStatus(prefs, now, false, "No se pudo sincronizar o revisar el correo: ${e.message ?: e.javaClass.simpleName}. No se confirmó ningún envío.", 0)
            Result.retry()
        }
    }

    private fun saveStatus(prefs: android.content.SharedPreferences, time: Long, sent: Boolean, message: String, count: Int) {
        prefs.edit().putLong(KEY_LAST_CHECK, time).putBoolean(KEY_LAST_SENT, sent)
            .putString(KEY_LAST_MESSAGE, message).putInt(KEY_LAST_COUNT, count).apply()
    }

    companion object {
        const val PREFS = "expiry_email_status"
        const val KEY_LAST_CHECK = "auto_last_check"
        const val KEY_LAST_SENT = "auto_last_sent"
        const val KEY_LAST_MESSAGE = "auto_last_message"
        const val KEY_LAST_COUNT = "auto_last_count"
        private const val UNIQUE_WORK = "daily_auto_expiry_email_check"

        fun schedule(context: Context) {
            val request = PeriodicWorkRequestBuilder<AutoExpiryEmailWorker>(24, TimeUnit.HOURS)
                .setInitialDelay(30, TimeUnit.MINUTES)
                .build()
            WorkManager.getInstance(context).enqueueUniquePeriodicWork(
                UNIQUE_WORK, ExistingPeriodicWorkPolicy.UPDATE, request
            )
        }
    }
}
