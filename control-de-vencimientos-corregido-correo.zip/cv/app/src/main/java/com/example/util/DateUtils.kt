package com.example.util

import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.concurrent.TimeUnit

enum class ExpiryStatus(val label: String, val badgeColorType: String) {
    EXPIRED("VENCIDO", "danger"),
    TODAY("VENCE HOY", "soon"),
    SOON("PRÓXIMO", "soon"),
    OK("OK", "ok")
}

enum class MacroStatus(val label: String, val badgeColorType: String) {
    PREPARE("Subir a macro", "warn"),
    PENDING_RESPONSE("En espera respuesta (+2d)", "pending"),
    ACTIVE("En macro", "active"),
    RENEW("Volver a subir (restan 2d)", "renew"),
    OVERDUE("Macro terminada", "overdue"),
    EXPIRED_PRODUCT("Vencido", "danger"),
    NONE("Sin macro", "none")
}

object DateUtils {
    private val isoFormat = SimpleDateFormat("yyyy-MM-dd", Locale.US)
    private val esFormat = SimpleDateFormat("dd/MM/yyyy", Locale("es", "CO"))

    fun todayIso(): String {
        return isoFormat.format(Date())
    }

    fun isValidIsoDate(str: String?): Boolean {
        if (str.isNullOrBlank()) return false
        return str.trim().matches(Regex("^\\d{4}-\\d{2}-\\d{2}$"))
    }

    fun daysLeft(dateStr: String?): Long {
        if (dateStr.isNullOrBlank()) return 9999L
        return try {
            val target = isoFormat.parse(dateStr) ?: return 9999L
            val calToday = Calendar.getInstance().apply {
                set(Calendar.HOUR_OF_DAY, 0)
                set(Calendar.MINUTE, 0)
                set(Calendar.SECOND, 0)
                set(Calendar.MILLISECOND, 0)
            }
            val calTarget = Calendar.getInstance().apply {
                time = target
                set(Calendar.HOUR_OF_DAY, 0)
                set(Calendar.MINUTE, 0)
                set(Calendar.SECOND, 0)
                set(Calendar.MILLISECOND, 0)
            }
            val diffMs = calTarget.timeInMillis - calToday.timeInMillis
            TimeUnit.MILLISECONDS.toDays(diffMs)
        } catch (_: Exception) {
            9999L
        }
    }

    fun formatDateEs(dateStr: String?): String {
        if (dateStr.isNullOrBlank()) return "—"
        return try {
            val date = isoFormat.parse(dateStr) ?: return dateStr
            esFormat.format(date)
        } catch (_: Exception) {
            dateStr
        }
    }

    fun parseAnyDateToIso(raw: String?): String? {
        if (raw.isNullOrBlank()) return null
        val clean = raw.trim()
        if (clean.matches(Regex("^\\d{4}-\\d{2}-\\d{2}$"))) return clean

        val dmyRegex = Regex("^(\\d{1,2})[\\/.-](\\d{1,2})[\\/.-](\\d{4})$")
        val match = dmyRegex.find(clean)
        if (match != null) {
            val (day, month, year) = match.destructured
            val d = day.padStart(2, '0')
            val m = month.padStart(2, '0')
            return "$year-$m-$d"
        }
        return null
    }

    fun addDaysToIso(baseDateIso: String, daysToAdd: Int): String {
        return try {
            val date = isoFormat.parse(baseDateIso) ?: return baseDateIso
            val cal = Calendar.getInstance().apply {
                time = date
                add(Calendar.DAY_OF_YEAR, daysToAdd)
            }
            isoFormat.format(cal.time)
        } catch (_: Exception) {
            baseDateIso
        }
    }

    fun calculateRenewDate(endDateIso: String?, daysBefore: Int = 2): String? {
        if (endDateIso.isNullOrBlank()) return null
        return try {
            val date = isoFormat.parse(endDateIso) ?: return null
            val cal = Calendar.getInstance().apply {
                time = date
                add(Calendar.DAY_OF_YEAR, -daysBefore)
            }
            isoFormat.format(cal.time)
        } catch (_: Exception) {
            null
        }
    }

    fun getExpiryStatus(daysLeft: Long): ExpiryStatus {
        return when {
            daysLeft < 0 -> ExpiryStatus.EXPIRED
            daysLeft == 0L -> ExpiryStatus.TODAY
            daysLeft <= 20 -> ExpiryStatus.SOON
            else -> ExpiryStatus.OK
        }
    }

    fun getMacroStatus(productExpiryIso: String, macroStartIso: String?, macroEndIso: String?, macroRenewIso: String?): MacroStatus {
        val days = daysLeft(productExpiryIso)
        if (days < 0) return MacroStatus.EXPIRED_PRODUCT

        if (macroEndIso.isNullOrBlank()) {
            return if (days <= 30) MacroStatus.PREPARE else MacroStatus.NONE
        }

        val today = todayIso()

        // 1. Si la fecha actual es anterior a la fecha de inicio (tarda 2 días en responder tras subirlo)
        if (!macroStartIso.isNullOrBlank() && today < macroStartIso) {
            return MacroStatus.PENDING_RESPONSE
        }

        // 2. Si ya pasó la fecha fin del descuento
        if (today > macroEndIso) return MacroStatus.OVERDUE

        // 3. Dos días antes de que finalice el descuento se debe volver a subir a la macro
        val effectiveRenew = macroRenewIso ?: calculateRenewDate(macroEndIso, 2)
        if (!effectiveRenew.isNullOrBlank() && today >= effectiveRenew) {
            return MacroStatus.RENEW
        }

        return MacroStatus.ACTIVE
    }
}
