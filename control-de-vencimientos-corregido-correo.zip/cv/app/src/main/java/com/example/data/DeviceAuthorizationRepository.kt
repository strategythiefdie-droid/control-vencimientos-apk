package com.example.data

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import com.example.profile.InventoryProfile
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.security.KeyStore
import java.util.UUID
import java.util.concurrent.TimeUnit
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/** Device enrollment/authorization client. The raw token is encrypted with an Android Keystore key. */
class DeviceAuthorizationRepository(context: Context) {
    companion object {
        private const val BASE_URL = "https://hhncacdqvmxsilkpzniy.supabase.co"
        private const val PUBLISHABLE_KEY = "sb_publishable_Ebgl5rcG2WEq0Ra0BJiHjA_y1kkt-xz"
        private const val PREFS = "inventory_device_authorization"
        private const val KEY_DEVICE_ID = "device_id"
        private const val KEY_TOKEN = "encrypted_device_token"
        private const val KEY_WORKSPACE = "authorized_workspace"
        private const val ANDROID_KEY_ALIAS = "cv_device_token_aes_v1"
    }

    private val app = context.applicationContext
    private val prefs = app.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
    private val client = OkHttpClient.Builder().connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(25, TimeUnit.SECONDS).writeTimeout(25, TimeUnit.SECONDS).build()
    private val jsonType = "application/json; charset=utf-8".toMediaType()

    private fun deviceId(): String {
        val existing = prefs.getString(KEY_DEVICE_ID, null)
        if (!existing.isNullOrBlank()) return existing
        return UUID.randomUUID().toString().also { prefs.edit().putString(KEY_DEVICE_ID, it).apply() }
    }

    private fun key(): SecretKey {
        val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (ks.getKey(ANDROID_KEY_ALIAS, null) as? SecretKey)?.let { return it }
        val generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        generator.init(KeyGenParameterSpec.Builder(ANDROID_KEY_ALIAS,
            KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
            .setBlockModes(KeyProperties.BLOCK_MODE_GCM).setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
            .setRandomizedEncryptionRequired(true).build())
        return generator.generateKey()
    }

    private fun encrypt(value: String): String {
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, key())
        val encrypted = cipher.doFinal(value.toByteArray(Charsets.UTF_8))
        return Base64.encodeToString(cipher.iv + encrypted, Base64.NO_WRAP)
    }

    private fun decrypt(value: String): String {
        val packed = Base64.decode(value, Base64.NO_WRAP)
        require(packed.size > 12) { "Credencial local dañada." }
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.DECRYPT_MODE, key(), GCMParameterSpec(128, packed.copyOfRange(0, 12)))
        return cipher.doFinal(packed.copyOfRange(12, packed.size)).toString(Charsets.UTF_8)
    }

    private fun call(payload: JSONObject): JSONObject {
        val req = Request.Builder().url("$BASE_URL/functions/v1/admin-gateway")
            .header("apikey", PUBLISHABLE_KEY).header("Accept", "application/json")
            .post(payload.toString().toRequestBody(jsonType)).build()
        client.newCall(req).execute().use { response ->
            val body = response.body?.string().orEmpty()
            val result = try { JSONObject(body) } catch (_: Exception) { JSONObject() }
            if (!response.isSuccessful) throw SecurityException(result.optString("error").ifBlank { "Error de autorización (${response.code})." })
            return result
        }
    }

    /** Consumes a one-time code and stores the returned device token encrypted at rest. */
    fun bind(code: String, profile: InventoryProfile, label: String = "Android"): String {
        require(profile != InventoryProfile.TUSK && !profile.isLocalTest) { "Este perfil no requiere vinculación con el servidor." }
        val normalized = code.trim().uppercase()
        require(Regex("^[A-F0-9]{36}$").matches(normalized)) { "El código debe tener 36 caracteres hexadecimales." }
        val result = call(JSONObject().put("action", "bind-device").put("code", normalized)
            .put("deviceId", deviceId()).put("label", label).put("workspaceId", profile.id))
        if (!result.optBoolean("ok")) throw SecurityException(result.optString("error", "No se pudo vincular el dispositivo."))
        val workspace = result.optString("workspaceId")
        if (workspace != profile.id) throw SecurityException("El código pertenece a otro inventario ($workspace).")
        val token = result.optString("deviceToken")
        require(Regex("^[a-f0-9]{64}$").matches(token)) { "El servidor devolvió una credencial inválida." }
        prefs.edit().putString(KEY_TOKEN, encrypt(token)).putString(KEY_WORKSPACE, workspace).apply()
        return workspace
    }

    /** Re-checks server state; revocation or workspace mismatch fails closed. */
    fun authorize(profile: InventoryProfile): Boolean {
        if (profile == InventoryProfile.TUSK || profile.isLocalTest) return true // Legacy TUSK and local sandbox do not use device binding.
        val encrypted = prefs.getString(KEY_TOKEN, null) ?: throw SecurityException("Este dispositivo aún no está vinculado. Solicita un código al administrador.")
        val workspace = prefs.getString(KEY_WORKSPACE, null).orEmpty()
        if (workspace != profile.id) throw SecurityException("El dispositivo está vinculado a $workspace, no a ${profile.id}.")
        val token = try { decrypt(encrypted) } catch (_: Exception) {
            throw SecurityException("No se pudo descifrar la credencial. Debes volver a vincular este dispositivo.")
        }
        val result = call(JSONObject().put("action", "authorize-device").put("deviceId", deviceId())
            .put("deviceToken", token).put("workspaceId", profile.id))
        if (!result.optBoolean("authorized")) throw SecurityException(result.optString("error").ifBlank { "Dispositivo no autorizado." })
        return true
    }

    /** Calls the server-side sync endpoint. The endpoint revalidates authorization on every request. */
    fun syncInventory(profile: InventoryProfile, mode: String, payload: JSONObject = JSONObject()): JSONObject {
        require(profile != InventoryProfile.TUSK && !profile.isLocalTest) { "Este perfil no permite sincronización por dispositivo." }
        require(mode in setOf("pull", "push", "delete")) { "Operación de sincronización inválida." }
        val encrypted = prefs.getString(KEY_TOKEN, null)
            ?: throw SecurityException("Este dispositivo aún no está vinculado. Solicita un código al administrador.")
        val workspace = prefs.getString(KEY_WORKSPACE, null).orEmpty()
        if (workspace != profile.id) throw SecurityException("El dispositivo está vinculado a $workspace, no a ${profile.id}.")
        val token = try { decrypt(encrypted) } catch (_: Exception) {
            throw SecurityException("No se pudo descifrar la credencial. Debes volver a vincular este dispositivo.")
        }
        val request = JSONObject(payload.toString())
            .put("action", "sync-inventory")
            .put("deviceId", deviceId())
            .put("deviceToken", token)
            .put("workspaceId", profile.id)
            .put("mode", mode)
        return call(request)
    }

    fun clearLocalBinding() { prefs.edit().remove(KEY_TOKEN).remove(KEY_WORKSPACE).apply() }
}
