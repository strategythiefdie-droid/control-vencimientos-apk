package com.example.ui.components

import android.Manifest
import android.app.DatePickerDialog
import android.media.AudioManager
import android.media.ToneGenerator
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.FlashOn
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.core.content.ContextCompat
import com.example.data.MultiScanItem
import com.example.data.ProductWithBatches
import com.example.ui.theme.StatusSoonDark
import com.example.util.DateUtils
import org.json.JSONArray
import org.json.JSONObject
import java.util.Calendar
import java.util.Locale

@Composable
fun ScannerModal(
    initialMode: String = "cam", // "cam", "multi", "gun"
    existingProducts: List<ProductWithBatches> = emptyList(),
    onCodeScanned: (String) -> Unit,
    onMultiScanFinished: (List<MultiScanItem>, String) -> Unit = { _, _ -> },
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    val haptics = LocalHapticFeedback.current
    val burstPrefs = remember(context) { context.getSharedPreferences("burst_session_v2", android.content.Context.MODE_PRIVATE) }
    val toneGenerator = remember { runCatching { ToneGenerator(AudioManager.STREAM_NOTIFICATION, 70) }.getOrNull() }
    DisposableEffect(toneGenerator) { onDispose { toneGenerator?.release() } }
    var selectedMode by remember { mutableStateOf(initialMode) }
    var manualCode by remember { mutableStateOf("") }

    // Multi-scan session state
    val multiScanItems = remember {
        mutableStateListOf<MultiScanItem>().apply {
            runCatching {
                val saved = JSONArray(burstPrefs.getString("items", "[]") ?: "[]")
                for (i in 0 until saved.length()) {
                    val o = saved.getJSONObject(i)
                    add(MultiScanItem(
                        barcode = o.optString("barcode"),
                        plu = o.optString("plu").takeIf { it.isNotBlank() },
                        name = o.optString("name", "Producto"),
                        quantity = o.optDouble("quantity", 1.0),
                        expiryDate = o.optString("expiryDate").takeIf { it.isNotBlank() }
                    ))
                }
            }
        }
    }
    var lastScannedName by remember { mutableStateOf<String?>(null) }
    var pendingScanCode by remember { mutableStateOf<String?>(null) }
    var pendingQuantity by remember { mutableStateOf("1") }
    var pendingName by remember { mutableStateOf("") }
    var pendingExpiryDate by remember { mutableStateOf(DateUtils.todayIso()) }
    var batchExpiryDate by remember { mutableStateOf(DateUtils.todayIso()) }
    var quickScanMode by remember { mutableStateOf(burstPrefs.getBoolean("quick_mode", false)) }
    var lastUndo by remember { mutableStateOf<Triple<String, String, Double>?>(null) }
    var lastFeedback by remember { mutableStateOf("Sesión lista para escanear") }

    LaunchedEffect(multiScanItems.map { "${it.barcode}|${it.name}|${it.quantity}|${it.expiryDate}" }) {
        val array = JSONArray()
        multiScanItems.forEach { item ->
            array.put(JSONObject().put("barcode", item.barcode).put("plu", item.plu ?: "")
                .put("name", item.name).put("quantity", item.quantity).put("expiryDate", item.expiryDate ?: batchExpiryDate))
        }
        burstPrefs.edit().putString("items", array.toString()).apply()
    }

    var hasCameraPermission by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
        )
    }

    val cameraPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        hasCameraPermission = isGranted
    }

    LaunchedEffect(selectedMode) {
        if ((selectedMode == "cam" || selectedMode == "multi") && !hasCameraPermission) {
            cameraPermissionLauncher.launch(Manifest.permission.CAMERA)
        }
    }

    fun resolveProductName(code: String): String {
        val existing = existingProducts.firstOrNull {
            (!it.barcode.isNullOrBlank() && it.barcode == code) ||
            (!it.plu.isNullOrBlank() && it.plu == code)
        }
        if (existing != null) return existing.name
        return "Producto $code"
    }

    // Cada detección pausa la cámara y solicita la cantidad; así un código
    // sostenido frente al lente nunca suma unidades repetidamente por sí solo.
    fun addBurstItem(code: String, quantityToAdd: Int, name: String, expiryDate: String) {
        val cleanName = name.trim().ifBlank { "Producto $code" }
        val existingIndex = multiScanItems.indexOfFirst { it.barcode.equals(code, true) && (it.expiryDate ?: batchExpiryDate) == expiryDate }
        lastUndo = if (existingIndex >= 0) Triple(code, expiryDate, multiScanItems[existingIndex].quantity) else Triple(code, expiryDate, 0.0)
        if (existingIndex >= 0) {
            val item = multiScanItems[existingIndex]
            multiScanItems[existingIndex] = item.copy(name = cleanName, quantity = item.quantity + quantityToAdd, expiryDate = expiryDate)
        } else {
            multiScanItems.add(MultiScanItem(barcode = code, name = cleanName, quantity = quantityToAdd.toDouble(), expiryDate = expiryDate))
        }
        lastScannedName = cleanName
        lastFeedback = "✓ $cleanName · +$quantityToAdd · ${DateUtils.formatDateEs(expiryDate)}"
        haptics.performHapticFeedback(HapticFeedbackType.LongPress)
        toneGenerator?.startTone(ToneGenerator.TONE_PROP_ACK, 100)
    }

    fun handleMultiScanBarcode(code: String) {
        if (pendingScanCode != null) return
        haptics.performHapticFeedback(HapticFeedbackType.TextHandleMove)
        toneGenerator?.startTone(ToneGenerator.TONE_PROP_BEEP, 80)
        if (quickScanMode) {
            addBurstItem(code, 1, resolveProductName(code), batchExpiryDate)
        } else {
            pendingScanCode = code
            pendingQuantity = "1"
            pendingName = resolveProductName(code)
            pendingExpiryDate = batchExpiryDate
            lastScannedName = pendingName
            lastFeedback = if (pendingName.startsWith("Producto ")) "Código nuevo: completa el nombre antes de agregar" else "Código reconocido: confirma las unidades"
        }
    }

    fun confirmMultiScanQuantity() {
        val code = pendingScanCode ?: return
        val quantityToAdd = pendingQuantity.trim().toIntOrNull()?.takeIf { it > 0 } ?: return
        addBurstItem(code, quantityToAdd, pendingName, pendingExpiryDate)
        pendingScanCode = null
        pendingQuantity = "1"
        pendingName = ""
    }

    fun undoLastOperation() {
        val undo = lastUndo ?: return
        val idx = multiScanItems.indexOfFirst { it.barcode.equals(undo.first, true) && (it.expiryDate ?: batchExpiryDate) == undo.second }
        if (idx >= 0) {
            if (undo.third <= 0.0) multiScanItems.removeAt(idx)
            else multiScanItems[idx] = multiScanItems[idx].copy(quantity = undo.third)
            lastFeedback = "↶ Último registro deshecho"
            toneGenerator?.startTone(ToneGenerator.TONE_PROP_NACK, 120)
        }
        lastUndo = null
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(
            decorFitsSystemWindows = true,
            usePlatformDefaultWidth = false
        )
    ) {
        Surface(
            shape = RoundedCornerShape(24.dp),
            color = MaterialTheme.colorScheme.surface,
            tonalElevation = 6.dp,
            modifier = Modifier
                .fillMaxWidth(0.93f)
                .testTag("scanner_modal")
        ) {
            Column(
                modifier = Modifier
                    .padding(18.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(34.dp)
                                .clip(RoundedCornerShape(10.dp))
                                .background(MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.QrCodeScanner,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                        Spacer(modifier = Modifier.size(8.dp))
                        Column {
                            Text(
                                text = "Lector de código",
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = "Elige cámara individual, ráfaga o pistola",
                                fontSize = 10.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    IconButton(onClick = onDismiss, modifier = Modifier.size(30.dp)) {
                        Icon(imageVector = Icons.Default.Close, contentDescription = "Cerrar")
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Selector: Modo Cámara vs Multi-Scan vs Modo Pistola
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    // Modo Cámara Individual
                    val isCam = selectedMode == "cam"
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(10.dp))
                            .background(if (isCam) MaterialTheme.colorScheme.primary.copy(alpha = 0.15f) else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f))
                            .border(
                                width = if (isCam) 2.dp else 1.dp,
                                color = if (isCam) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline.copy(alpha = 0.3f),
                                shape = RoundedCornerShape(10.dp)
                            )
                            .clickable {
                                selectedMode = "cam"
                                if (!hasCameraPermission) cameraPermissionLauncher.launch(Manifest.permission.CAMERA)
                            }
                            .padding(8.dp)
                            .testTag("mode_cam_btn")
                    ) {
                        Column {
                            Text(text = "📷 Cámara", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = if (isCam) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface)
                            Text(text = "1 código", fontSize = 8.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }

                    // Modo Multi-Scan (Ráfaga continua)
                    val isMulti = selectedMode == "multi"
                    Box(
                        modifier = Modifier
                            .weight(1.2f)
                            .clip(RoundedCornerShape(10.dp))
                            .background(if (isMulti) MaterialTheme.colorScheme.secondary.copy(alpha = 0.18f) else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f))
                            .border(
                                width = if (isMulti) 2.dp else 1.dp,
                                color = if (isMulti) MaterialTheme.colorScheme.secondary else MaterialTheme.colorScheme.outline.copy(alpha = 0.3f),
                                shape = RoundedCornerShape(10.dp)
                            )
                            .clickable {
                                selectedMode = "multi"
                                if (!hasCameraPermission) cameraPermissionLauncher.launch(Manifest.permission.CAMERA)
                            }
                            .padding(8.dp)
                            .testTag("mode_multi_btn")
                    ) {
                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(text = "⚡ Ráfaga", fontSize = 11.sp, fontWeight = FontWeight.ExtraBold, color = if (isMulti) MaterialTheme.colorScheme.secondary else MaterialTheme.colorScheme.onSurface)
                                Spacer(modifier = Modifier.width(3.dp))
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(4.dp))
                                        .background(MaterialTheme.colorScheme.secondary.copy(alpha = 0.2f))
                                        .padding(horizontal = 4.dp, vertical = 1.dp)
                                ) {
                                    Text(text = "Multi", fontSize = 7.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.secondary)
                                }
                            }
                            Text(text = "Continuo", fontSize = 8.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }

                    // Modo Pistola
                    val isGun = selectedMode == "gun"
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(10.dp))
                            .background(if (isGun) MaterialTheme.colorScheme.primary.copy(alpha = 0.15f) else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f))
                            .border(
                                width = if (isGun) 2.dp else 1.dp,
                                color = if (isGun) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline.copy(alpha = 0.3f),
                                shape = RoundedCornerShape(10.dp)
                            )
                            .clickable { selectedMode = "gun" }
                            .padding(8.dp)
                            .testTag("mode_gun_btn")
                    ) {
                        Column {
                            Text(text = "🔫 Pistola", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = if (isGun) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface)
                            Text(text = "USB / BT", fontSize = 8.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Active Mode Body
                when (selectedMode) {
                    "cam" -> {
                        if (hasCameraPermission) {
                            Text(
                                text = "Apunta al código para capturarlo:",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = MaterialTheme.colorScheme.primary
                            )
                            Spacer(modifier = Modifier.height(6.dp))

                            CameraScannerView(
                                continuousScan = false,
                                onBarcodeDetected = { detectedCode ->
                                    onCodeScanned(detectedCode)
                                    onDismiss()
                                }
                            )
                        } else {
                            CameraPermissionRequiredBox { cameraPermissionLauncher.launch(Manifest.permission.CAMERA) }
                        }
                    }

                    "multi" -> {
                        // MULTI-SCAN (RÁFAGA) INTERFACE
                        if (hasCameraPermission) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "⚡ Escaneo continuo activo:",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.secondary
                                )

                                Text(
                                    text = "${multiScanItems.size} productos (${multiScanItems.sumOf { it.quantity }} uds)",
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.primary
                                )
                            }

                            Spacer(modifier = Modifier.height(6.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                                OutlinedButton(onClick = {
                                    quickScanMode = !quickScanMode
                                    burstPrefs.edit().putBoolean("quick_mode", quickScanMode).apply()
                                    lastFeedback = if (quickScanMode) "Modo rápido: cada lectura suma 1 unidad" else "Modo confirmar: pregunta cantidad por lectura"
                                }, modifier = Modifier.weight(1f)) {
                                    Text(if (quickScanMode) "⚡ Rápido: +1" else "✋ Confirmar cantidad", fontSize = 10.sp)
                                }
                                OutlinedButton(onClick = { undoLastOperation() }, enabled = lastUndo != null, modifier = Modifier.weight(0.75f)) {
                                    Text("↶ Deshacer", fontSize = 10.sp)
                                }
                            }

                            // Pause camera while asking the quantity, preventing repeated
                            // frame detections from silently increasing the inventory count.
                            if (pendingScanCode == null) {
                                CameraScannerView(
                                    continuousScan = true,
                                    onBarcodeDetected = { detectedCode ->
                                        handleMultiScanBarcode(detectedCode)
                                    }
                                )
                            } else {
                                Surface(
                                    shape = RoundedCornerShape(12.dp),
                                    color = MaterialTheme.colorScheme.secondaryContainer,
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                        Text("Confirmar cantidad", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSecondaryContainer)
                                        Text(
                                            text = "Código: ${pendingScanCode.orEmpty()}",
                                            fontSize = 12.sp,
                                            color = MaterialTheme.colorScheme.onSecondaryContainer
                                        )
                                        OutlinedTextField(
                                            value = pendingName,
                                            onValueChange = { pendingName = it },
                                            label = { Text("Nombre del producto") },
                                            singleLine = true,
                                            modifier = Modifier.fillMaxWidth().testTag("burst_product_name_input")
                                        )
                                        val matchingProducts = existingProducts.filter { pendingName.isNotBlank() && it.name.contains(pendingName, ignoreCase = true) }.take(4)
                                        matchingProducts.forEach { product ->
                                            OutlinedButton(
                                                onClick = {
                                                    pendingName = product.name
                                                    pendingScanCode = product.barcode?.takeIf { it.isNotBlank() } ?: product.plu?.takeIf { it.isNotBlank() } ?: pendingScanCode
                                                    lastFeedback = "Producto existente seleccionado: ${product.name}"
                                                },
                                                modifier = Modifier.fillMaxWidth()
                                            ) { Text("Usar existente: ${product.name}", fontSize = 10.sp) }
                                        }
                                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                            Text("Vence: ${DateUtils.formatDateEs(pendingExpiryDate)}", fontSize = 11.sp, modifier = Modifier.weight(1f))
                                            OutlinedButton(onClick = {
                                                val cal = Calendar.getInstance()
                                                runCatching { val parts = pendingExpiryDate.split("-"); cal.set(parts[0].toInt(), parts[1].toInt()-1, parts[2].toInt()) }
                                                DatePickerDialog(context, { _, y, m, d -> pendingExpiryDate = String.format(Locale.US, "%04d-%02d-%02d", y, m+1, d) }, cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH)).show()
                                            }) { Text("Cambiar fecha") }
                                        }
                                        OutlinedTextField(
                                            value = pendingQuantity,
                                            onValueChange = { value -> pendingQuantity = value.filter { it.isDigit() }.take(6) },
                                            label = { Text("Unidades que vas a registrar") },
                                            singleLine = true,
                                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                            modifier = Modifier.fillMaxWidth().testTag("burst_quantity_input")
                                        )
                                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                                            OutlinedButton(
                                                onClick = { pendingScanCode = null; pendingQuantity = "1" },
                                                modifier = Modifier.weight(1f)
                                            ) { Text("Cancelar") }
                                            Button(
                                                onClick = { confirmMultiScanQuantity() },
                                                enabled = (pendingQuantity.toIntOrNull() ?: 0) > 0,
                                                modifier = Modifier.weight(1f)
                                            ) { Text("Agregar cantidad") }
                                        }
                                    }
                                }
                            }

                            // Feedback banner for last item scanned
                            if (lastScannedName != null) {
                                Spacer(modifier = Modifier.height(6.dp))
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(MaterialTheme.colorScheme.secondary.copy(alpha = 0.15f))
                                        .padding(horizontal = 10.dp, vertical = 6.dp)
                                ) {
                                    Text(
                                        text = lastFeedback,
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.SemiBold,
                                        color = MaterialTheme.colorScheme.secondary
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(10.dp))

                            // Batch expiration date picker
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "Vencimiento para el lote:",
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )

                                OutlinedButton(
                                    onClick = {
                                        val cal = Calendar.getInstance()
                                        DatePickerDialog(
                                            context,
                                            { _, year, month, day ->
                                                batchExpiryDate = String.format(Locale.US, "%04d-%02d-%02d", year, month + 1, day)
                                            },
                                            cal.get(Calendar.YEAR),
                                            cal.get(Calendar.MONTH),
                                            cal.get(Calendar.DAY_OF_MONTH)
                                        ).show()
                                    },
                                    modifier = Modifier.height(30.dp),
                                    shape = RoundedCornerShape(6.dp)
                                ) {
                                    Icon(imageVector = Icons.Default.CalendarMonth, contentDescription = null, modifier = Modifier.size(12.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(DateUtils.formatDateEs(batchExpiryDate), fontSize = 10.sp)
                                }
                            }

                            // Quick date shortcuts for batch
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp),
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                listOf(7 to "+7d", 15 to "+15d", 30 to "+30d", 60 to "+60d").forEach { (days, label) ->
                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(6.dp))
                                            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                                            .clickable {
                                                val cal = Calendar.getInstance().apply { add(Calendar.DAY_OF_YEAR, days) }
                                                batchExpiryDate = String.format(Locale.US, "%04d-%02d-%02d", cal.get(Calendar.YEAR), cal.get(Calendar.MONTH) + 1, cal.get(Calendar.DAY_OF_MONTH))
                                            }
                                            .padding(horizontal = 7.dp, vertical = 3.dp)
                                    ) {
                                        Text(text = label, fontSize = 8.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(8.dp))

                            // List of items scanned in this session
                            if (multiScanItems.isNotEmpty()) {
                                Text(
                                    text = "Lote escaneado en esta sesión:",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Spacer(modifier = Modifier.height(4.dp))

                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .heightIn(max = 160.dp)
                                        .clip(RoundedCornerShape(10.dp))
                                        .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f))
                                        .border(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.3f), RoundedCornerShape(10.dp))
                                        .padding(6.dp)
                                ) {
                                    LazyColumn(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                        items(multiScanItems) { item ->
                                            Row(
                                                modifier = Modifier
                                                    .fillMaxWidth()
                                                    .clip(RoundedCornerShape(6.dp))
                                                    .background(MaterialTheme.colorScheme.surface)
                                                    .padding(6.dp),
                                                horizontalArrangement = Arrangement.SpaceBetween,
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                Column(modifier = Modifier.weight(1f)) {
                                                    OutlinedTextField(
                                                        value = item.name,
                                                        onValueChange = { value ->
                                                            val idx = multiScanItems.indexOf(item)
                                                            if (idx >= 0) multiScanItems[idx] = item.copy(name = value)
                                                        },
                                                        label = { Text("Nombre", fontSize = 9.sp) },
                                                        singleLine = true,
                                                        textStyle = MaterialTheme.typography.bodySmall,
                                                        modifier = Modifier.fillMaxWidth().heightIn(min = 42.dp)
                                                    )
                                                    Text(text = item.barcode, fontSize = 9.sp, fontFamily = FontFamily.Monospace, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                                    Text(text = "Vence: ${DateUtils.formatDateEs(item.expiryDate ?: batchExpiryDate)}", fontSize = 9.sp, color = MaterialTheme.colorScheme.primary, modifier = Modifier.clickable {
                                                        val currentDate = item.expiryDate ?: batchExpiryDate
                                                        val cal = Calendar.getInstance()
                                                        runCatching { val parts = currentDate.split("-"); cal.set(parts[0].toInt(), parts[1].toInt()-1, parts[2].toInt()) }
                                                        DatePickerDialog(context, { _, y, m, d ->
                                                            val newDate = String.format(Locale.US, "%04d-%02d-%02d", y, m+1, d)
                                                            val idx = multiScanItems.indexOf(item)
                                                            if (idx >= 0) multiScanItems[idx] = item.copy(expiryDate = newDate)
                                                        }, cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH)).show()
                                                    })
                                                }

                                                // Quantity stepper
                                                Row(verticalAlignment = Alignment.CenterVertically) {
                                                    IconButton(
                                                        onClick = {
                                                            val idx = multiScanItems.indexOf(item)
                                                            if (idx >= 0) {
                                                                if (item.quantity > 1) {
                                                                    multiScanItems[idx] = item.copy(quantity = item.quantity - 1)
                                                                } else {
                                                                    multiScanItems.removeAt(idx)
                                                                }
                                                            }
                                                        },
                                                        modifier = Modifier.size(24.dp)
                                                    ) {
                                                        Icon(imageVector = Icons.Default.Remove, contentDescription = null, modifier = Modifier.size(14.dp))
                                                    }

                                                    Text(text = com.example.util.QuantityFormatter.format(item.quantity), fontSize = 11.sp, fontWeight = FontWeight.ExtraBold, modifier = Modifier.padding(horizontal = 4.dp))

                                                    IconButton(
                                                        onClick = {
                                                            val idx = multiScanItems.indexOf(item)
                                                            if (idx >= 0) {
                                                                multiScanItems[idx] = item.copy(quantity = item.quantity + 1)
                                                            }
                                                        },
                                                        modifier = Modifier.size(24.dp)
                                                    ) {
                                                        Icon(imageVector = Icons.Default.Add, contentDescription = null, modifier = Modifier.size(14.dp))
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }

                                Spacer(modifier = Modifier.height(10.dp))

                                // Save Batch Button
                                Button(
                                    onClick = {
                                        onMultiScanFinished(multiScanItems.toList(), batchExpiryDate)
                                        multiScanItems.clear()
                                        burstPrefs.edit().remove("items").apply()
                                        onDismiss()
                                    },
                                    modifier = Modifier.fillMaxWidth(),
                                    shape = RoundedCornerShape(10.dp),
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = MaterialTheme.colorScheme.secondary,
                                        contentColor = Color.Black
                                    )
                                ) {
                                    Icon(imageVector = Icons.Default.Check, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = "✓ Guardar lote (${multiScanItems.sumOf { it.quantity }} unidades)",
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        } else {
                            CameraPermissionRequiredBox { cameraPermissionLauncher.launch(Manifest.permission.CAMERA) }
                        }
                    }

                    "gun" -> {
                        // Gun / Hardware scanner input field
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f))
                                .border(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.4f), RoundedCornerShape(12.dp))
                                .padding(12.dp)
                        ) {
                            Column {
                                Text(
                                    text = "Modo Pistola USB / Bluetooth:",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.primary
                                )
                                Text(
                                    text = "Dispara el lector físico hacia el producto o escribe el código.",
                                    fontSize = 10.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )

                                Spacer(modifier = Modifier.height(8.dp))

                                OutlinedTextField(
                                    value = manualCode,
                                    onValueChange = { manualCode = it },
                                    label = { Text("Código de barras / PLU", fontSize = 11.sp) },
                                    placeholder = { Text("Ingresa o escanea código", fontSize = 11.sp) },
                                    singleLine = true,
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .testTag("scanner_manual_code_input")
                                )

                                Spacer(modifier = Modifier.height(8.dp))

                                Button(
                                    onClick = {
                                        if (manualCode.isNotBlank()) {
                                            onCodeScanned(manualCode.trim())
                                            onDismiss()
                                        }
                                    },
                                    modifier = Modifier.fillMaxWidth(),
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Text("Aplicar código al producto", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                OutlinedButton(
                    onClick = onDismiss,
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Text("Cerrar", fontSize = 12.sp)
                }
            }
        }
    }
}

@Composable
private fun CameraPermissionRequiredBox(onRequestPermission: () -> Unit) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f))
            .border(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.4f), RoundedCornerShape(12.dp))
            .padding(16.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(text = "📷", fontSize = 32.sp)
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = "Se requiere permiso de cámara",
                fontWeight = FontWeight.Bold,
                fontSize = 13.sp
            )
            Text(
                text = "Para activar el escáner visual, permite el acceso a la cámara.",
                fontSize = 10.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                lineHeight = 14.sp
            )
            Spacer(modifier = Modifier.height(10.dp))
            Button(
                onClick = onRequestPermission,
                shape = RoundedCornerShape(8.dp)
            ) {
                Icon(imageVector = Icons.Default.CameraAlt, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.size(6.dp))
                Text("Activar cámara ahora", fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}
