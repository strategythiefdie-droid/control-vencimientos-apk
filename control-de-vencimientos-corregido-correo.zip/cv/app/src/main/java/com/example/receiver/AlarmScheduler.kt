package com.example.receiver

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build

import java.util.Calendar

object AlarmScheduler {
    const val ACTION_CHECK_EXPIRY = "com.example.CHECK_EXPIRY_ALARM"
    private const val ALARM_REQ_CODE = 9001

    /**
     * Programa la verificación de vencimientos en segundo plano mediante AlarmManager.
     * Se sincroniza con los turnos de supermercado (08:00 AM y 14:00 PM) para alertar
     * de manera confiable con la aplicación cerrada.
     */
    fun scheduleDailyAlarms(context: Context) {
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as? AlarmManager ?: return
        val intent = Intent(context, ExpiryAlarmReceiver::class.java).apply {
            action = ACTION_CHECK_EXPIRY
        }

        val pendingIntent = PendingIntent.getBroadcast(
            context,
            ALARM_REQ_CODE,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val triggerAtMs = getNextAlarmTimeMillis()

        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                alarmManager.setAndAllowWhileIdle(
                    AlarmManager.RTC_WAKEUP,
                    triggerAtMs,
                    pendingIntent
                )
            } else {
                alarmManager.setInexactRepeating(
                    AlarmManager.RTC_WAKEUP,
                    triggerAtMs,
                    4 * 60 * 60 * 1000L,
                    pendingIntent
                )
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun getNextAlarmTimeMillis(): Long {
        val now = Calendar.getInstance()
        val morningTarget = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, 8)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }
        val afternoonTarget = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, 14)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }

        return when {
            now.before(morningTarget) -> morningTarget.timeInMillis
            now.before(afternoonTarget) -> afternoonTarget.timeInMillis
            else -> {
                // Siguiente día a las 8:00 AM
                morningTarget.apply { add(Calendar.DAY_OF_YEAR, 1) }.timeInMillis
            }
        }
    }
}
