package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Primary brand tones (Slate & Azure)
val BrandBlueDark = Color(0xFF70C8FF)
val BrandBlueLight = Color(0xFF173149)
val BrandBlueSoftDark = Color(0xFF162536)
val BrandBlueSoftLight = Color(0xFFEDF7FF)

// Status & Accent colors
val StatusSoonDark = Color(0xFF67DFA0)
val StatusSoonLight = Color(0xFF1C7D52)
val StatusSoonBgDark = Color(0xFF0E271B)
val StatusSoonBgLight = Color(0xFFEAF9F1)

val StatusOkDark = Color(0xFF4ADE80)
val StatusOkLight = Color(0xFF15803D)
val EmeraldAccent = Color(0xFF34D399)

val StatusExpiredDark = Color(0xFFFF718D)
val StatusExpiredLight = Color(0xFFB4235A)
val StatusExpiredBgDark = Color(0xFF33141E)
val StatusExpiredBgLight = Color(0xFFFFF0F5)

val StatusMacroDark = Color(0xFFFFB148)
val StatusMacroLight = Color(0xFFB5701B)
val StatusMacroBgDark = Color(0xFF2E200C)
val StatusMacroBgLight = Color(0xFFFFF8EC)

// Base Backgrounds and Surfaces
val DarkBg = Color(0xFF080B12)
val DarkSurface = Color(0xFF111722)
val DarkSurfaceVariant = Color(0xFF1A2333)
val DarkBorder = Color(0xFF263346)
val DarkTextPrimary = Color(0xFFF4F8FF)
val DarkTextSecondary = Color(0xFF9AA8BA)

val LightBg = Color(0xFFEEF3F8)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceVariant = Color(0xFFE4ECF4)
val LightBorder = Color(0xFFD6E0EC)
val LightTextPrimary = Color(0xFF172033)
val LightTextSecondary = Color(0xFF64758A)
