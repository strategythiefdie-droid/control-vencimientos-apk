package com.example.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.profile.InventoryProfile
import kotlinx.coroutines.launch

@Composable
fun ProfileSelectionScreen(onSelect: suspend (InventoryProfile, String?) -> String?) {
    var code by remember { mutableStateOf("") }
    var working by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf<String?>(null) }
    val scope = rememberCoroutineScope()
    Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
        Column(
            modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 22.dp, vertical = 30.dp),
            verticalArrangement = Arrangement.Center
        ) {
            Text("Control de Vencimientos", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
            Text("Selecciona el inventario. Cada perfil guarda sus productos y registros por separado.", style = MaterialTheme.typography.bodyLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(Modifier.height(18.dp))
            OutlinedTextField(value = code, onValueChange = { code = it.uppercase().filter { c -> c.isLetterOrDigit() }.take(36) },
                modifier = Modifier.fillMaxWidth(), label = { Text("Código de vinculación (ACT 1–ACT 4)") },
                supportingText = { Text("El código lo genera el administrador, vence en 10 minutos y se usa una sola vez. TUSK y el usuario de prueba no lo necesitan.") }, singleLine = true)
            Spacer(Modifier.height(12.dp))
            InventoryProfile.entries.forEach { profile ->
                Card(
                    modifier = Modifier.fillMaxWidth().padding(bottom = 10.dp),
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    Row(modifier = Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(profile.title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                            Text(
                                when {
                                    profile == InventoryProfile.TUSK -> "Inventario existente"
                                    profile.isLocalTest -> "Sandbox vacío · solo local · no envía correos reales"
                                    else -> "Requiere código de administrador · uso de una sola vez"
                                },
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Button(enabled = !working, onClick = {
                            scope.launch {
                                working = true
                                message = null
                                message = try { onSelect(profile, if (profile.requiresAdminCode) code else null) }
                                catch (e: Exception) { e.message ?: "No se pudo seleccionar el inventario." }
                                finally { working = false }
                            }
                        }) { Text(if (working) "Validando…" else if (profile.isLocalTest) "Probar app" else "Entrar") }
                    }
                }
            }
            if (message != null) {
                Spacer(Modifier.height(8.dp))
                Text(message!!, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodyMedium)
            }
            Spacer(Modifier.height(8.dp))
            Text("El usuario de prueba empieza vacío y usa una base de datos independiente. Puedes registrar datos ficticios y probar las funciones sin mezclarlos con TUSK ni subirlos a la nube.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}
