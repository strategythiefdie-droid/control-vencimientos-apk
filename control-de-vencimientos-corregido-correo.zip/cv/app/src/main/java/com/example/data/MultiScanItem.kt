package com.example.data

data class MultiScanItem(
    val barcode: String,
    val plu: String? = null,
    val name: String,
    var quantity: Double = 1.0,
    val expiryDate: String? = null
) {
    constructor(barcode: String, plu: String? = null, name: String, quantity: Int) :
            this(barcode, plu, name, quantity.toDouble())
}
