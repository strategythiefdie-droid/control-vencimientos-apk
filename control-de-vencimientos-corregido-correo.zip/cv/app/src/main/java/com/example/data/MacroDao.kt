package com.example.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface MacroDao {
    @Query("SELECT * FROM macro_records WHERE areaId = :areaId ORDER BY updatedAt DESC")
    fun getMacroRecordsByArea(areaId: String): Flow<List<MacroRecordEntity>>

    @Query("SELECT * FROM macro_records ORDER BY updatedAt DESC")
    fun getAllMacroRecords(): Flow<List<MacroRecordEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMacroRecord(record: MacroRecordEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMacroRecords(records: List<MacroRecordEntity>)

    @Query("DELETE FROM macro_records WHERE id = :id")
    suspend fun deleteById(id: String)

    @Query("DELETE FROM macro_records WHERE areaId = :areaId")
    suspend fun deleteByArea(areaId: String)

    @Query("DELETE FROM macro_records")
    suspend fun clearAll()
}
