package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.util.UUID

@Entity(tableName = "products")
data class ProductEntity(
    @PrimaryKey
    val id: String = UUID.randomUUID().toString(),
    val areaId: String,
    val name: String,
    val barcode: String? = null,
    val plu: String? = null,
    val unitCost: Double? = null,
    val createdAt: Long = System.currentTimeMillis()
)
