package com.example.data

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey
import java.util.UUID

@Entity(tableName = "products")
data class ProductEntity(
    @PrimaryKey
    val id: String = UUID.randomUUID().toString(),
    val areaId: String,
    val name: String,
    val barcode: String? = null,
    val plu: String? = null,
    val unitCost: Double? = null,
    /** Physical storage location, e.g. aisle, shelf, rack or box. */
    @ColumnInfo(defaultValue = "''")
    val location: String = "",
    /** Last local/cloud change to the physical location (epoch milliseconds). */
    @ColumnInfo(defaultValue = "0")
    val locationUpdatedAt: Long = 0L,
    /** Products marked for return must never be included in Macro. */
    @ColumnInfo(defaultValue = "0")
    val hasReturn: Boolean = false,
    /** Last local/cloud change of the return flag (epoch milliseconds). */
    @ColumnInfo(defaultValue = "0")
    val returnUpdatedAt: Long = 0L,
    val createdAt: Long = System.currentTimeMillis()
)
