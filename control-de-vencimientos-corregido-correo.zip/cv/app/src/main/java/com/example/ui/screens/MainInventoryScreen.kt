package com.example.ui.screens

import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Assessment
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Discount
import androidx.compose.material.icons.filled.Inventory2
import androidx.compose.material.icons.filled.LocalShipping
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.example.ui.InventoryViewModel
import com.example.data.CloudInventoryUser
import com.example.data.CloudInventoryProduct
import com.example.profile.InventoryProfile
import com.example.ui.components.AdminAuthDialog
import com.example.ui.components.AlertBanner
import com.example.ui.components.BackupModal
import com.example.ui.components.CediArrivalModal
import com.example.ui.components.DeviceAuthorizationPanel
import com.example.ui.components.InventoryListSection
import com.example.ui.components.MacroControlSection
import com.example.ui.components.MacroImportModal
import com.example.ui.components.ProductFormCard
import com.example.ui.components.PassageAndRelationsSection
import com.example.ui.components.QuickActionsPanel
import com.example.ui.components.ReportModal
import com.example.ui.components.ScannerModal
import com.example.ui.components.StatsCardsSection
import com.example.ui.components.TopBarComponent
import com.example.ui.theme.EmeraldAccent
import com.example.ui.theme.StatusMacroDark
import com.example.ui.theme.StatusSoonDark
import com.example.worker.AutoExpiryEmailWorker
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun MainInventoryScreen(
    viewModel: InventoryViewModel,
    onChangeInventory: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val activeInventoryProfile = remember { InventoryProfile.selected(context) ?: InventoryProfile.TUSK }
    val snackbarHostState = remember { SnackbarHostState() }

    val currentArea by viewModel.currentArea.collectAsState()
    val isSimpleMode by viewModel.isSimpleMode.collectAsState()
    val isDarkTheme by viewModel.isDarkTheme.collectAsState()
    val searchQuery by viewModel.searchQuery.collectAsState()
    val filterStatus by viewModel.filterStatus.collectAsState()
    val areaProducts by viewModel.areaProducts.collectAsState()
    val allProducts by viewModel.allProducts.collectAsState()
    val productRelations by viewModel.productRelations.collectAsState()
    val aisleEntries by viewModel.aisleEntries.collectAsState()
    val macroRecords by viewModel.macroRecords.collectAsState()
    val isAdminUnlocked by viewModel.isAdminUnlocked.collectAsState()
    val selectedBatchIds by viewModel.selectedBatchIds.collectAsState()
    val existingProductMatch by viewModel.existingProductMatch.collectAsState()
    val cloudUsers by viewModel.cloudUsers.collectAsState()
    val selectedCloudUser by viewModel.selectedCloudUser.collectAsState()
    val cloudProducts by viewModel.cloudProducts.collectAsState()
    val cloudAdminMessage by viewModel.cloudAdminMessage.collectAsState()
    val cloudAdminLoading by viewModel.cloudAdminLoading.collectAsState()
    val cloudAdminSession by viewModel.cloudAdminSession.collectAsState()
    val deviceInvite by viewModel.deviceInvite.collectAsState()
    val deviceBindings by viewModel.deviceBindings.collectAsState()
    val adminAuthLoading by viewModel.adminAuthLoading.collectAsState()
    val adminAuthError by viewModel.adminAuthError.collectAsState()
    val syncStatus by viewModel.syncStatus.collectAsState()

    // Form states
    val editingBatchId by viewModel.editingBatchId.collectAsState()
    val barcode by viewModel.barcodeInput.collectAsState()
    val plu by viewModel.pluInput.collectAsState()
    val name by viewModel.nameInput.collectAsState()
    val location by viewModel.locationInput.collectAsState()
    val quantity by viewModel.quantityInput.collectAsState()
    val unitCost by viewModel.unitCostInput.collectAsState()
    val expiryDate by viewModel.expiryDateInput.collectAsState()
    val formError by viewModel.formError.collectAsState()

    // Navegación por secciones / pestañas
    var currentSection by remember { mutableStateOf("inventory") } // inventory, aisle, cedi, macro, operations
    var pendingRestrictedSection by remember { mutableStateOf<String?>(null) }
    var isFormExpanded by remember { mutableStateOf(false) }
    var showTutorial by remember {
        mutableStateOf(!context.getSharedPreferences("app_preferences", android.content.Context.MODE_PRIVATE).getBoolean("tutorial_seen", false))
    }
    var autoEmailLastCheck by remember { mutableStateOf(0L) }
    var autoEmailMessage by remember { mutableStateOf("Aún no se ha registrado una revisión automática en este dispositivo.") }
    var autoEmailSent by remember { mutableStateOf(false) }
    fun refreshAutoEmailStatus() {
        if (activeInventoryProfile.isLocalTest) {
            autoEmailLastCheck = 0L
            autoEmailMessage = "Usuario de prueba: los correos automáticos reales están desactivados."
            autoEmailSent = false
            return
        }
        val prefs = context.getSharedPreferences(AutoExpiryEmailWorker.PREFS, android.content.Context.MODE_PRIVATE)
        autoEmailLastCheck = prefs.getLong(AutoExpiryEmailWorker.KEY_LAST_CHECK, 0L)
        autoEmailMessage = prefs.getString(AutoExpiryEmailWorker.KEY_LAST_MESSAGE, "Aún no se ha registrado una revisión automática en este dispositivo.") ?: "Sin estado disponible"
        autoEmailSent = prefs.getBoolean(AutoExpiryEmailWorker.KEY_LAST_SENT, false)
    }
    fun closeTutorial() {
        showTutorial = false
        context.getSharedPreferences("app_preferences", android.content.Context.MODE_PRIVATE).edit().putBoolean("tutorial_seen", true).apply()
    }
    LaunchedEffect(Unit) { refreshAutoEmailStatus() }
    LaunchedEffect(currentArea) {
        if (currentArea == com.example.data.Area.ADMIN) currentSection = "inventory"
    }
    LaunchedEffect(currentSection) {
        if (currentSection == "operations") refreshAutoEmailStatus()
        if ((currentSection == "cedi" || currentSection == "macro") && !isAdminUnlocked) {
            pendingRestrictedSection = currentSection
            currentSection = "inventory"
            viewModel.showAdminAuthDialog.value = true
        }
    }
    LaunchedEffect(isAdminUnlocked) {
        if (isAdminUnlocked && pendingRestrictedSection != null) {
            currentSection = pendingRestrictedSection!!
            pendingRestrictedSection = null
        } else if (!isAdminUnlocked && (currentSection == "cedi" || currentSection == "macro")) {
            currentSection = "inventory"
        }
    }
    fun requestRestrictedSection(section: String) {
        if (isAdminUnlocked) {
            currentSection = section
        } else {
            pendingRestrictedSection = section
            viewModel.showAdminAuthDialog.value = true
        }
    }

    // Si entra en modo edición, expandir el formulario automáticamente y cambiar a inventario
    LaunchedEffect(editingBatchId) {
        if (editingBatchId != null) {
            currentSection = "inventory"
            isFormExpanded = true
        }
    }

    // Modals
    val showScanner by viewModel.showScannerModal.collectAsState()
    val showCedi by viewModel.showCediModal.collectAsState()
    val showMacroImport by viewModel.showMacroImportModal.collectAsState()
    val showBackup by viewModel.showBackupModal.collectAsState()
    val showReport by viewModel.showReportModal.collectAsState()
    val showAdminAuth by viewModel.showAdminAuthDialog.collectAsState()

    // Notification Permission Launcher
    val notificationPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        if (isGranted) {
            viewModel.trigger30DayNotificationCheck(context)
        } else {
            Toast.makeText(context, "Permiso de notificaciones denegado", Toast.LENGTH_SHORT).show()
        }
    }

    fun requestNotificationAndTrigger() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            val hasPermission = ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED
            if (hasPermission) {
                viewModel.trigger30DayNotificationCheck(context)
            } else {
                notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
        } else {
            viewModel.trigger30DayNotificationCheck(context)
        }
    }

    // Toast message handling
    val toastMessage by viewModel.toastMessage.collectAsState()
    LaunchedEffect(toastMessage) {
        toastMessage?.let {
            Toast.makeText(context, it, Toast.LENGTH_SHORT).show()
            viewModel.clearToast()
        }
    }

    val soonProducts = remember(areaProducts) {
        areaProducts.filter { it.hasSoonBatch }
    }

    Scaffold(
        snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
        topBar = {
            TopBarComponent(
                currentArea = currentArea,
                inventoryProfileTitle = if (activeInventoryProfile.isLocalTest) "PRUEBA" else activeInventoryProfile.title,
                isSimpleMode = isSimpleMode,
                isDarkTheme = isDarkTheme,
                isAdminUnlocked = isAdminUnlocked,
                syncStatus = syncStatus,
                onSyncNow = { viewModel.syncInventoryNow() },
                onChangeInventory = onChangeInventory,
                onAreaSelect = { viewModel.requestAreaChange(it) },
                onLockAdmin = { viewModel.lockAdmin() },
                onToggleSimpleMode = { viewModel.toggleSimpleMode(); if (!isSimpleMode) { currentSection = "inventory"; isFormExpanded = false } },
                onToggleTheme = { viewModel.toggleTheme() },
                onOpenScanner = { viewModel.showScannerModal.value = true },
                onSendAlert = { viewModel.sendManualAlertWebhook() },
                onTriggerNotificationSound = { requestNotificationAndTrigger() },
                onOpenMacro = { requestRestrictedSection("macro"); if (isAdminUnlocked) viewModel.showMacroImportModal.value = true },
                onOpenReport = { viewModel.showReportModal.value = true },
                onOpenBackup = { viewModel.showBackupModal.value = true },
                onOpenCediArrival = { if (isAdminUnlocked) viewModel.showCediModal.value = true else { pendingRestrictedSection = "cedi"; viewModel.showAdminAuthDialog.value = true } }
            )
        },
        bottomBar = {
            NavigationBar(
                containerColor = MaterialTheme.colorScheme.surface,
                tonalElevation = 6.dp,
                modifier = Modifier.testTag("bottom_nav_bar")
            ) {
                NavigationBarItem(
                    selected = currentSection == "inventory",
                    onClick = { currentSection = "inventory" },
                    icon = {
                        Icon(
                            imageVector = Icons.Default.Inventory2,
                            contentDescription = "Inventario",
                            modifier = Modifier.size(20.dp)
                        )
                    },
                    label = {
                        Text(
                            text = "Inventario",
                            fontSize = 10.sp,
                            fontWeight = if (currentSection == "inventory") FontWeight.Bold else FontWeight.Medium
                        )
                    },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = MaterialTheme.colorScheme.primary,
                        selectedTextColor = MaterialTheme.colorScheme.primary
                    )
                )

                NavigationBarItem(
                    selected = currentSection == "aisle",
                    onClick = { currentSection = "aisle" },
                    icon = { Icon(Icons.Default.Inventory2, contentDescription = "Mi pasillo", modifier = Modifier.size(20.dp)) },
                    label = { Text("Pasillo", fontSize = 10.sp, fontWeight = if (currentSection == "aisle") FontWeight.Bold else FontWeight.Medium) },
                    colors = NavigationBarItemDefaults.colors(selectedIconColor = MaterialTheme.colorScheme.primary, selectedTextColor = MaterialTheme.colorScheme.primary)
                )

                if (!isSimpleMode) NavigationBarItem(
                    selected = currentSection == "cedi",
                    onClick = { requestRestrictedSection("cedi") },
                    icon = {
                        Icon(
                            imageVector = Icons.Default.LocalShipping,
                            contentDescription = "Llegada CEDI",
                            modifier = Modifier.size(20.dp)
                        )
                    },
                    label = {
                        Text(
                            text = "CEDI",
                            fontSize = 10.sp,
                            fontWeight = if (currentSection == "cedi") FontWeight.Bold else FontWeight.Medium
                        )
                    },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = MaterialTheme.colorScheme.primary,
                        selectedTextColor = MaterialTheme.colorScheme.primary
                    )
                )

                if (!isSimpleMode) NavigationBarItem(
                    selected = currentSection == "macro",
                    onClick = { requestRestrictedSection("macro") },
                    icon = {
                        Icon(
                            imageVector = Icons.Default.Discount,
                            contentDescription = "Control Macro",
                            modifier = Modifier.size(20.dp)
                        )
                    },
                    label = {
                        Text(
                            text = "Macro",
                            fontSize = 10.sp,
                            fontWeight = if (currentSection == "macro") FontWeight.Bold else FontWeight.Medium
                        )
                    },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = StatusMacroDark,
                        selectedTextColor = StatusMacroDark
                    )
                )

                NavigationBarItem(
                    selected = currentSection == "operations",
                    onClick = { currentSection = "operations" },
                    icon = {
                        Icon(
                            imageVector = Icons.Default.Tune,
                            contentDescription = "Operaciones",
                            modifier = Modifier.size(20.dp)
                        )
                    },
                    label = {
                        Text(
                            text = "Acciones",
                            fontSize = 10.sp,
                            fontWeight = if (currentSection == "operations") FontWeight.Bold else FontWeight.Medium
                        )
                    },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = MaterialTheme.colorScheme.primary,
                        selectedTextColor = MaterialTheme.colorScheme.primary
                    )
                )
            }
        },
        floatingActionButton = {
            if (currentSection == "inventory" && !isFormExpanded && editingBatchId == null) {
                ExtendedFloatingActionButton(
                    onClick = { isFormExpanded = true },
                    icon = { Icon(Icons.Default.Add, contentDescription = null) },
                    text = { Text("Registrar Lote", fontWeight = FontWeight.Bold, fontSize = 12.sp) },
                    containerColor = MaterialTheme.colorScheme.primary,
                    contentColor = MaterialTheme.colorScheme.onPrimary,
                    modifier = Modifier.testTag("fab_add_batch")
                )
            }
        },
        modifier = modifier.fillMaxSize()
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MaterialTheme.colorScheme.background)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 12.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            if (currentArea == com.example.data.Area.ADMIN && isAdminUnlocked && currentSection == "inventory") {
                DeviceAuthorizationPanel(
                    canManage = cloudAdminSession != null,
                    invite = deviceInvite,
                    bindings = deviceBindings,
                    loading = cloudAdminLoading,
                    message = cloudAdminMessage,
                    onGenerate = { workspaceId -> viewModel.generateDeviceInvite(workspaceId) },
                    onCopyCode = { code ->
                        val clipboard = context.getSystemService(ClipboardManager::class.java)
                        clipboard?.setPrimaryClip(ClipData.newPlainText("Código de vinculación", code))
                        Toast.makeText(context, "Código copiado", Toast.LENGTH_SHORT).show()
                    },
                    onShareCode = { invite ->
                        val shareText = "Código de vinculación para ${invite.workspaceName}: ${invite.code}\nCaduca en 10 minutos y solo puede usarse una vez. En Control de Vencimientos, selecciona ${invite.workspaceName} e introduce este código."
                        val shareIntent = Intent(Intent.ACTION_SEND).apply {
                            type = "text/plain"
                            putExtra(Intent.EXTRA_TEXT, shareText)
                        }
                        context.startActivity(Intent.createChooser(shareIntent, "Compartir código de vinculación"))
                    },
                    onRefreshBindings = { viewModel.refreshDeviceBindings() },
                    onRevoke = { binding -> viewModel.revokeDeviceBinding(binding) }
                )
                if (cloudAdminSession != null) {
                    CloudAdminInventoryPanel(
                        users = cloudUsers,
                        selectedUser = selectedCloudUser,
                        products = cloudProducts,
                        message = null,
                        loading = cloudAdminLoading,
                        sessionName = cloudAdminSession?.displayName,
                        onRefresh = { viewModel.refreshCloudUsers() },
                        onSelectUser = { viewModel.selectCloudUser(it) }
                    )
                }
            }
            when (currentSection) {
                "inventory" -> {
                    // SECCIÓN 1: INVENTARIO (Limpio y enfocado)
                    if (isSimpleMode) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedButton(onClick = { viewModel.showScannerModal.value = true }, modifier = Modifier.weight(1f)) { Text("▣ Escanear") }
                            Button(onClick = { isFormExpanded = true }, modifier = Modifier.weight(1f)) { Text("+ Registrar") }
                        }
                    }
                    // Urgent Alert Banner
                    AlertBanner(soonProducts = soonProducts)

                    // Formulario de Lote (se despliega cuando se necesita registrar o editar)
                    AnimatedVisibility(
                        visible = isFormExpanded || editingBatchId != null,
                        enter = fadeIn(),
                        exit = fadeOut()
                    ) {
                        Column {
                            ProductFormCard(
                                isEditing = editingBatchId != null,
                                barcode = barcode,
                                plu = plu,
                                name = name,
                                location = location,
                                quantity = quantity,
                                unitCost = unitCost,
                                expiryDate = expiryDate,
                                errorMessage = formError,
                                existingProduct = existingProductMatch,
                                isFruitArea = currentArea == com.example.data.Area.FRUVER,
                                onBarcodeChange = { viewModel.onBarcodeChanged(it) },
                                onPluChange = { viewModel.onPluChanged(it) },
                                onNameChange = { viewModel.onNameChanged(it) },
                                onLocationChange = { viewModel.locationInput.value = it },
                                onQuantityChange = { viewModel.quantityInput.value = it },
                                onUnitCostChange = { viewModel.unitCostInput.value = it },
                                onExpiryDateChange = { viewModel.expiryDateInput.value = it },
                                onOpenScanner = { viewModel.showScannerModal.value = true },
                                onSave = {
                                    viewModel.saveProduct()
                                    if (formError == null) isFormExpanded = false
                                },
                                onCancel = {
                                    viewModel.resetForm()
                                    isFormExpanded = false
                                }
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                        }
                    }

                    // Listado principal de productos y lotes (con buscador y filtros integrados)
                    InventoryListSection(
                        products = areaProducts,
                        searchQuery = searchQuery,
                        selectedFilter = filterStatus,
                        selectedBatchIds = selectedBatchIds,
                        onSetProductsReturnStatus = { ids, hasReturn -> viewModel.setProductsReturnStatus(ids, hasReturn) },
                        onSearchChange = { viewModel.setSearchQuery(it) },
                        onFilterChange = { viewModel.setFilterStatus(it) },
                        onToggleSelectBatch = { viewModel.toggleBatchSelection(it) },
                        onSelectAllBatches = { viewModel.selectAllBatches(it) },
                        onSelectAllExpiredBatches = { viewModel.selectAllExpiredBatches() },
                        onClearSelection = { viewModel.clearSelection() },
                        onDeleteSelectedBatches = { viewModel.deleteSelectedBatches() },
                        onDeleteExpiredBatchesDirectly = { viewModel.deleteExpiredBatchesDirectly() },
                        onEditBatch = { prod, batch ->
                            isFormExpanded = true
                            viewModel.startEditBatch(prod, batch)
                        },
                        onDeleteBatch = { viewModel.deleteBatch(it) },
                        onAddBatchToProduct = {
                            isFormExpanded = true
                            viewModel.startAddBatch(it)
                        },
                        onDeleteProduct = { viewModel.deleteProduct(it) },
                        onMoveProduct = { productId, targetArea -> viewModel.moveProductToArea(productId, targetArea) },
                        onOpenReport = { viewModel.showReportModal.value = true }
                    )
                }

                "aisle" -> {
                    PassageAndRelationsSection(
                        products = allProducts,
                        aisleEntries = aisleEntries,
                        onAddAisle = { productId, batchId, quantity -> viewModel.addProductToAisle(productId, batchId, quantity) },
                        onUpdateAisle = { id, quantity, status -> viewModel.updateAisleEntry(id, quantity, status) },
                        onRemoveAisle = { viewModel.removeAisleEntry(it) },
                        onUpdateProductLocation = { productId, location -> viewModel.updateProductLocation(productId, location) }
                    )
                }

                "cedi" -> {
                    // SECCIÓN 2: LLEGADA CEDI (Dedicado y organizado)
                    CediArrivalHubCard(
                        areaName = currentArea.displayName,
                        totalCatalogItems = areaProducts.size,
                        onOpenArrivalModal = { viewModel.showCediModal.value = true }
                    )
                }

                "macro" -> {
                    // SECCIÓN 3: CONTROL DE MACRO
                    MacroControlSection(
                        products = areaProducts,
                        macroRecords = macroRecords,
                        onOpenImport = { viewModel.showMacroImportModal.value = true },
                        onRenew = { viewModel.renewMacroRecord(it) },
                        onDiscountChange = { id, percent -> viewModel.updateMacroDiscount(id, percent) },
                        onDelete = { viewModel.deleteMacroRecord(it) }
                    )
                }

                "operations" -> {
                    // Herramientas frecuentes y diagnóstico del correo
                    if (isSimpleMode) {
                        SimpleHeaderBanner()
                        Button(onClick = { viewModel.showScannerModal.value = true }, modifier = Modifier.fillMaxWidth()) { Text("Escanear producto") }
                        Button(onClick = { viewModel.sendManualAlertWebhook() }, modifier = Modifier.fillMaxWidth()) { Text("Enviar alerta por correo ahora") }
                        OutlinedButton(onClick = { viewModel.showReportModal.value = true }, modifier = Modifier.fillMaxWidth()) { Text("Generar reporte") }
                        
                    } else {
                        QuickActionsPanel(
                            onSendAlert = { viewModel.sendManualAlertWebhook() },
                            onOpenScanner = { viewModel.showScannerModal.value = true },
                            onTriggerNotificationSound = { requestNotificationAndTrigger() },
                            onOpenMacro = { requestRestrictedSection("macro"); if (isAdminUnlocked) viewModel.showMacroImportModal.value = true },
                            onOpenReport = { viewModel.showReportModal.value = true },
                            onOpenBackup = { viewModel.showBackupModal.value = true },
                            onOpenCediArrival = { if (isAdminUnlocked) viewModel.showCediModal.value = true else { pendingRestrictedSection = "cedi"; viewModel.showAdminAuthDialog.value = true } }
                        )
                        
                    }
                    AutoEmailStatusCard(
                        lastCheck = autoEmailLastCheck,
                        sent = autoEmailSent,
                        message = autoEmailMessage,
                        onRefresh = { refreshAutoEmailStatus() },
                        onSendManual = { viewModel.sendManualAlertWebhook() }
                    )
                }
            }

            Spacer(modifier = Modifier.height(24.dp))
        }
    }

    if (showTutorial) {
        var tutorialStep by remember { mutableStateOf(0) }
        val tutorialSteps = listOf(
            Triple("1 de 6 · Inventario", "Aquí consultarás los productos registrados, sus cantidades y fechas de vencimiento.", "inventory"),
            Triple("2 de 6 · Registrar producto", "Abre el formulario para introducir nombre, código de barras o PLU, cantidad y vencimiento.", "inventory"),
            Triple("3 de 6 · Escáner", "Usa la cámara para leer códigos de barras. También podrás cambiar al reconocimiento de texto para detectar nombres impresos.", "inventory"),
            Triple("4 de 6 · Alertas", "Revisa los productos próximos a vencer y las notificaciones disponibles.", "inventory"),
            Triple("5 de 6 · Llegada CEDI", "La sección CEDI está disponible únicamente para el administrador.", "operations"),
            Triple("6 de 6 · Herramientas avanzadas", "En modo completo encontrarás Macro, reportes, copias y operaciones. El modo simple mantiene a mano las tareas diarias.", "operations")
        )
        AlertDialog(
            onDismissRequest = { closeTutorial() },
            title = { Text(tutorialSteps[tutorialStep].first, fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                        tutorialSteps.indices.forEach { index ->
                            Box(Modifier.weight(1f).height(5.dp).clip(RoundedCornerShape(5.dp)).background(if (index <= tutorialStep) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant))
                        }
                    }
                    Text(tutorialSteps[tutorialStep].second)
                    Text("Puedes avanzar paso a paso o saltar la guía. Solo aparecerá automáticamente la primera vez.", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    if (tutorialStep < tutorialSteps.lastIndex) {
                        tutorialStep++
                        currentSection = tutorialSteps[tutorialStep].third
                    } else closeTutorial()
                }) { Text(if (tutorialStep == tutorialSteps.lastIndex) "Terminar" else "Siguiente →") }
            },
            dismissButton = {
                Row {
                    if (tutorialStep > 0) TextButton(onClick = { tutorialStep--; currentSection = tutorialSteps[tutorialStep].third }) { Text("← Atrás") }
                    TextButton(onClick = { closeTutorial() }) { Text("Saltar guía") }
                }
            }
        )
    }

    // Modal Overlays
    if (showAdminAuth) {
        AdminAuthDialog(
            isLoading = adminAuthLoading,
            externalError = adminAuthError,
            onSuccess = { password ->
                viewModel.signInAndUnlockAdmin(password)
            },
            onDismiss = {
                pendingRestrictedSection = null
                viewModel.cancelAdminAuth()
            }
        )
    }

    if (showScanner) {
        ScannerModal(
            initialMode = "cam",
            existingProducts = areaProducts,
            onCodeScanned = { scannedCode ->
                viewModel.onBarcodeChanged(scannedCode)
            },
            onMultiScanFinished = { batchItems, expiryDate ->
                viewModel.addMultiScannedBatch(batchItems, expiryDate)
            },
            onDismiss = { viewModel.showScannerModal.value = false }
        )
    }

    if (showMacroImport) {
        MacroImportModal(
            availableProducts = areaProducts.filterNot { it.hasReturn },
            onAddProductsToMacro = { prods, start, end ->
                viewModel.addProductsToMacro(prods, start, end)
            },
            onImportText = { text ->
                viewModel.importMacroPastedText(text)
            },
            onDismiss = { viewModel.showMacroImportModal.value = false }
        )
    }

    if (showBackup) {
        BackupModal(
            onExport = { viewModel.getExportJson() },
            onImport = { json -> viewModel.importBackup(json) },
            onDismiss = { viewModel.showBackupModal.value = false }
        )
    }

    if (showReport) {
        ReportModal(
            products = areaProducts,
            area = currentArea,
            onDismiss = { viewModel.showReportModal.value = false }
        )
    }

    if (showCedi) {
        CediArrivalModal(
            areaName = currentArea.displayName,
            existingProducts = areaProducts,
            onParseText = { text -> viewModel.parseCediText(text) },
            onApplyArrival = { items, expiryDate ->
                viewModel.applyCediArrival(items, expiryDate)
            },
            onDismiss = { viewModel.showCediModal.value = false }
        )
    }
}

@Composable
private fun CediArrivalHubCard(
    areaName: String,
    totalCatalogItems: Int,
    onOpenArrivalModal: () -> Unit
) {
    val shape = RoundedCornerShape(14.dp)
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(shape)
            .background(MaterialTheme.colorScheme.surface)
            .border(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.2f), shape)
            .padding(14.dp)
            .testTag("cedi_hub_card"),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.12f)),
                    contentAlignment = Alignment.Center
                ) {
                    Text(text = "🚚", fontSize = 18.sp)
                }
                Spacer(modifier = Modifier.width(10.dp))
                Column {
                    Text(
                        text = "RECEPCIÓN CEDI",
                        fontSize = 9.sp,
                        letterSpacing = 1.2.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Text(
                        text = "Llegada de Mercancía",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }
            }

            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .background(MaterialTheme.colorScheme.primaryContainer)
                    .padding(horizontal = 8.dp, vertical = 4.dp)
            ) {
                Text(
                    text = areaName,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onPrimaryContainer
                )
            }
        }

        // Quick feature grid
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            CediFeatureChip("📁 Archivo CSV/TXT", Modifier.weight(1f))
            CediFeatureChip("📷 Escaneo Cámara", Modifier.weight(1f))
        }
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            CediFeatureChip("📋 Catálogo Rápido", Modifier.weight(1f))
            CediFeatureChip("📝 Pegar Planilla", Modifier.weight(1f))
        }

        // Primary action button
        Button(
            onClick = onOpenArrivalModal,
            shape = RoundedCornerShape(10.dp),
            modifier = Modifier
                .fillMaxWidth()
                .height(44.dp)
                .testTag("open_cedi_arrival_btn"),
            colors = ButtonDefaults.buttonColors(
                containerColor = MaterialTheme.colorScheme.primary
            )
        ) {
            Text(text = "🚚 Iniciar Recepción de Mercancía CEDI", fontSize = 12.sp, fontWeight = FontWeight.Bold)
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                text = "Catálogo para cruce automático:",
                fontSize = 10.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Text(
                text = "$totalCatalogItems productos",
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )
        }
    }
}

@Composable
private fun CediFeatureChip(text: String, modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(8.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
            .padding(horizontal = 8.dp, vertical = 6.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(text = text, fontSize = 10.sp, fontWeight = FontWeight.Medium, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun HeroOperationCard() {
    val shape = RoundedCornerShape(14.dp)
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(shape)
            .background(MaterialTheme.colorScheme.surface)
            .border(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.2f), shape)
            .padding(12.dp)
            .testTag("hero_operation_card")
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(32.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(EmeraldAccent.copy(alpha = 0.15f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Shield,
                        contentDescription = null,
                        tint = EmeraldAccent,
                        modifier = Modifier.size(18.dp)
                    )
                }

                Column {
                    Text(
                        text = "Control Operativo de Calidad",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }
            }

        }
    }
}

@Composable
private fun AutoEmailStatusCard(
    lastCheck: Long,
    sent: Boolean,
    message: String,
    onRefresh: () -> Unit,
    onSendManual: () -> Unit
) {
    val timeText = if (lastCheck > 0L) SimpleDateFormat("dd/MM/yyyy HH:mm", Locale("es", "CO")).format(Date(lastCheck)) else "Sin revisión registrada"
    Column(
        modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f)).padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        Text("ESTADO DE CORREO AUTOMÁTICO", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
        Text("Última revisión: $timeText", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
        Text(if (sent) "✓ El servidor confirmó un envío" else "Estado: revisión / sin confirmación de envío", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface)
        Text(message, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text("La revisión automática se programa una vez al día y depende de la conexión, Android y la respuesta del servidor. Esta fecha muestra el último intento registrado, no garantiza por sí sola la entrega en la bandeja de entrada.", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
            OutlinedButton(onClick = onRefresh, modifier = Modifier.weight(1f)) { Text("Actualizar estado") }
            Button(onClick = onSendManual, modifier = Modifier.weight(1f)) { Text("Enviar manual") }
        }
    }
}

@Composable
private fun SimpleHeaderBanner() {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
            .padding(horizontal = 12.dp, vertical = 8.dp)
    ) {
        Text(
            text = "⚡ Modo Simple Activo: Vista optimizada para agilidad en piso de ventas.",
            fontSize = 11.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}


@Composable
private fun CloudAdminInventoryPanel(
    users: List<CloudInventoryUser>,
    selectedUser: CloudInventoryUser?,
    products: List<CloudInventoryProduct>,
    message: String?,
    loading: Boolean,
    sessionName: String?,
    onRefresh: () -> Unit,
    onSelectUser: (CloudInventoryUser) -> Unit
) {
    Column(
        modifier = Modifier.fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.55f))
            .border(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.25f), RoundedCornerShape(16.dp))
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Text("INVENTARIOS DE OTROS DISPOSITIVOS", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = MaterialTheme.colorScheme.primary)
        Text("Sesión: ${sessionName ?: "Administrador"}. Los datos se consultan desde Supabase.", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedButton(onClick = onRefresh, enabled = !loading) { Text(if (loading) "Consultando…" else "Actualizar cuentas") }
            Text("${users.size} cuentas", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        if (!message.isNullOrBlank()) Text(message, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        if (users.isEmpty() && !loading) Text("No se encontraron cuentas. Comprueba los perfiles y los permisos RLS de Supabase.", fontSize = 12.sp)
        users.forEach { user ->
            val selected = selectedUser?.id == user.id
            Surface(
                modifier = Modifier.fillMaxWidth().clickable { onSelectUser(user) },
                shape = RoundedCornerShape(10.dp),
                color = if (selected) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surface,
                border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.18f))
            ) {
                Row(Modifier.padding(horizontal = 10.dp, vertical = 9.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(user.name, fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
                        Text(if (user.role.equals("admin", true)) "Administrador" else "Usuario", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    Text(if (selected) "Seleccionado" else "Ver inventario", fontSize = 10.sp, color = MaterialTheme.colorScheme.primary)
                }
            }
        }
        if (selectedUser != null) {
            Spacer(Modifier.height(4.dp))
            Text("Inventario de ${selectedUser.name}", fontWeight = FontWeight.Bold, fontSize = 13.sp)
            Text("${products.size} registros en la nube", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            if (products.isEmpty() && !loading) Text("Este inventario está vacío o no hay registros visibles para esta cuenta.", fontSize = 12.sp)
            products.forEach { p ->
                Column(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(8.dp)).background(MaterialTheme.colorScheme.surface).padding(9.dp),
                    verticalArrangement = Arrangement.spacedBy(3.dp)
                ) {
                    Text(p.name, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                    if (p.location.isNotBlank()) Text("Lugar: ${p.location}", fontSize = 10.sp, color = MaterialTheme.colorScheme.primary)
                    if (p.hasReturn) Text("Tiene devolución · Excluido de Macro", fontSize = 10.sp, color = MaterialTheme.colorScheme.secondary)
                    Text("PLU/EAN: ${p.plu ?: p.barcode ?: "—"}   ·   Cantidad: ${p.quantity}", fontSize = 10.sp)
                    Text("Vencimiento: ${p.expiryDate ?: "Sin fecha"}", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
    }
}
