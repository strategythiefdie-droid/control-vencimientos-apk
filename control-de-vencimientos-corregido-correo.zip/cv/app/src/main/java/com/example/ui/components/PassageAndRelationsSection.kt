package com.example.ui.components

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.AssistChip
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.AisleEntryEntity
import com.example.data.ProductWithBatches
import com.example.util.DateUtils
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun PassageAndRelationsSection(
    products: List<ProductWithBatches>,
    aisleEntries: List<AisleEntryEntity>,
    onAddAisle: (String, String?, Double) -> Unit,
    onUpdateAisle: (String, Double?, String?) -> Unit,
    onRemoveAisle: (String) -> Unit
) {
    var statusFilter by remember { mutableStateOf("TODOS") }
    var query by remember { mutableStateOf("") }
    var pickerQuery by remember { mutableStateOf("") }
    var showProductPicker by remember { mutableStateOf(false) }
    var aisleProduct by remember { mutableStateOf<ProductWithBatches?>(null) }
    var aisleBatchId by remember { mutableStateOf<String?>(null) }
    var aisleQty by remember { mutableStateOf("0") }
    var editingAisle by remember { mutableStateOf<AisleEntryEntity?>(null) }
    var newAisleQty by remember { mutableStateOf("") }
    val dateFormatter = remember { SimpleDateFormat("HH:mm · dd/MM/yyyy", Locale.getDefault()) }

    Column(verticalArrangement = Arrangement.spacedBy(14.dp), modifier = Modifier.fillMaxWidth()) {
        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text("Mi pasillo", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
            Text("Controla lo que hay físicamente en el pasillo, sin alterar las existencias generales ni los lotes del inventario.", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        OutlinedTextField(
            value = query, onValueChange = { query = it }, modifier = Modifier.fillMaxWidth(),
            label = { Text("Buscar producto") }, placeholder = { Text("Nombre, código de barras o PLU") },
            singleLine = true, shape = RoundedCornerShape(16.dp)
        )
        val total = aisleEntries.size
        val needsRestock = aisleEntries.count { it.status == "REPOSICION" }
        val empty = aisleEntries.count { it.status == "AGOTADO" || it.quantity <= 0.0 }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
            SummaryTile("En seguimiento", total.toString(), Modifier.weight(1f))
            SummaryTile("Reposición", needsRestock.toString(), Modifier.weight(1f))
            SummaryTile("Agotados", empty.toString(), Modifier.weight(1f))
        }
        Button(
            onClick = { pickerQuery = ""; showProductPicker = true }, modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(14.dp)
        ) { Text("＋   Agregar producto del inventario") }
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth()) {
            listOf("TODOS" to "Todos", "EN_PASILLO" to "En pasillo", "REPOSICION" to "Reponer", "AGOTADO" to "Agotados").forEach { (status, label) ->
                FilterChip(selected = statusFilter == status, onClick = { statusFilter = status }, label = { Text(label) })
            }
        }
        val filtered = aisleEntries.filter { entry ->
            val p = products.firstOrNull { it.id == entry.productId }
            p != null && (query.isBlank() || listOf(p.name, p.barcode.orEmpty(), p.plu.orEmpty()).any { it.contains(query, true) }) &&
                (statusFilter == "TODOS" || entry.status == statusFilter || (statusFilter == "AGOTADO" && entry.quantity <= 0.0))
        }.sortedWith(compareBy<AisleEntryEntity> { if (it.status == "REPOSICION" || it.status == "AGOTADO" || it.quantity <= 0.0) 0 else 1 }.thenBy { it.updatedAt })

        if (filtered.isEmpty()) {
            Surface(color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.55f), shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(22.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(if (query.isBlank() && statusFilter == "TODOS") "Tu pasillo está vacío" else "No encontramos productos", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                    Text(if (query.isBlank() && statusFilter == "TODOS") "Agrega productos del inventario para empezar a llevar el control del pasillo." else "Prueba otra búsqueda o cambia el filtro.", color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodyMedium)
                }
            }
        }
        filtered.forEach { entry ->
            val product = products.firstOrNull { it.id == entry.productId } ?: return@forEach
            val batch = product.batches.firstOrNull { it.id == entry.batchId }
            val days = batch?.let { DateUtils.daysLeft(it.expiryDate) }
            val isEmpty = entry.quantity <= 0.0 || entry.status == "AGOTADO"
            val needs = entry.status == "REPOSICION"
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
            ) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text(product.name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                            Text(listOfNotNull(product.barcode?.takeIf { it.isNotBlank() }?.let { "Código $it" }, product.plu?.takeIf { it.isNotBlank() }?.let { "PLU $it" }).joinToString("  ·  ").ifBlank { "Sin código ni PLU" }, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        AssistChip(onClick = { }, label = { Text(when { isEmpty -> "Agotado"; needs -> "Reponer"; else -> "En pasillo" }) })
                    }
                    Divider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.55f))
                    Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                        Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                            Text("Cantidad en pasillo", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text(formatQuantity(entry.quantity), style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            OutlinedButton(onClick = { if (entry.quantity > 0) onUpdateAisle(entry.id, (entry.quantity - 1).coerceAtLeast(0.0), if (entry.quantity <= 1) "AGOTADO" else "EN_PASILLO") }, enabled = entry.quantity > 0, shape = RoundedCornerShape(12.dp), modifier = Modifier.size(48.dp)) { Text("−", style = MaterialTheme.typography.titleLarge) }
                            Button(onClick = { onUpdateAisle(entry.id, entry.quantity + 1, "EN_PASILLO") }, shape = RoundedCornerShape(12.dp), modifier = Modifier.size(48.dp)) { Text("+", style = MaterialTheme.typography.titleLarge) }
                        }
                    }
                    if (batch != null) {
                        Surface(color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f), shape = RoundedCornerShape(12.dp), modifier = Modifier.fillMaxWidth()) {
                            Column(Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                                Text("Lote: ${batch.batchNumber ?: "Sin número"}", style = MaterialTheme.typography.bodySmall)
                                Text("Vencimiento: ${batch.expiryDate}${when { days != null && days < 0 -> " · VENCIDO"; days != null && days <= 20 -> " · Próximo a vencer"; else -> "" }}", style = MaterialTheme.typography.bodySmall, color = if (days != null && days <= 20) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    }
                    Text("Actualizado ${dateFormatter.format(Date(entry.updatedAt))}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth()) {
                        OutlinedButton(onClick = { editingAisle = entry; newAisleQty = formatQuantity(entry.quantity) }, modifier = Modifier.weight(1f), shape = RoundedCornerShape(12.dp)) { Text("Editar cantidad") }
                        OutlinedButton(onClick = { onUpdateAisle(entry.id, null, "REPOSICION") }, modifier = Modifier.weight(1f), shape = RoundedCornerShape(12.dp)) { Text("Pedir reposición") }
                    }
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                        TextButton(onClick = { onUpdateAisle(entry.id, 0.0, "AGOTADO") }) { Text("Marcar agotado") }
                        TextButton(onClick = { onRemoveAisle(entry.id) }) { Text("Retirar del pasillo") }
                    }
                }
            }
        }
    }

    if (showProductPicker) AlertDialog(
        onDismissRequest = { showProductPicker = false },
        title = { Text("Agregar producto", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Selecciona un producto que ya exista en el inventario.", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                OutlinedTextField(value = pickerQuery, onValueChange = { pickerQuery = it }, modifier = Modifier.fillMaxWidth(), label = { Text("Buscar producto") }, singleLine = true, shape = RoundedCornerShape(14.dp))
                val matches = products.filter { p -> pickerQuery.isBlank() || listOf(p.name, p.barcode.orEmpty(), p.plu.orEmpty()).any { it.contains(pickerQuery, true) } }.take(150)
                if (matches.isEmpty()) Text("No hay coincidencias.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                LazyColumn(modifier = Modifier.fillMaxWidth().heightIn(max = 340.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    items(matches, key = { it.id }) { p ->
                        Surface(onClick = { aisleProduct = p; aisleBatchId = p.batches.firstOrNull()?.id; aisleQty = "0"; showProductPicker = false }, color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f), shape = RoundedCornerShape(12.dp), modifier = Modifier.fillMaxWidth()) {
                            Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                                Text(p.name, style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.Medium)
                                Text(listOfNotNull(p.barcode?.takeIf { it.isNotBlank() }?.let { "Código $it" }, p.plu?.takeIf { it.isNotBlank() }?.let { "PLU $it" }).joinToString(" · ").ifBlank { "Sin identificadores" }, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Text("Lotes: ${p.batches.size}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = { showProductPicker = false }) { Text("Cerrar") } }
    )

    aisleProduct?.let { p -> AlertDialog(
        onDismissRequest = { aisleProduct = null },
        title = { Text("Configurar producto", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text(p.name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                Text("Define la cantidad que hay físicamente en el pasillo. No cambia el inventario general.", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                if (p.batches.isNotEmpty()) {
                    Text("Lote y vencimiento", style = MaterialTheme.typography.labelLarge)
                    LazyColumn(modifier = Modifier.fillMaxWidth().heightIn(max = 180.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        items(p.batches, key = { it.id }) { b ->
                            FilterChip(selected = aisleBatchId == b.id, onClick = { aisleBatchId = b.id }, label = { Text("${b.expiryDate} · stock ${formatQuantity(b.quantity)}") }, modifier = Modifier.fillMaxWidth())
                        }
                    }
                } else {
                    Text("Este producto no tiene lotes registrados. La cantidad será independiente.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                OutlinedTextField(value = aisleQty, onValueChange = { aisleQty = it }, modifier = Modifier.fillMaxWidth(), label = { Text("Cantidad en pasillo") }, singleLine = true, shape = RoundedCornerShape(14.dp))
            }
        },
        confirmButton = { Button(onClick = { val q = aisleQty.replace(',', '.').toDoubleOrNull(); if (q != null && q >= 0) { onAddAisle(p.id, aisleBatchId, q); aisleProduct = null } }, enabled = aisleQty.replace(',', '.').toDoubleOrNull()?.let { it >= 0 } == true, shape = RoundedCornerShape(12.dp)) { Text("Guardar en Mi pasillo") } },
        dismissButton = { TextButton(onClick = { aisleProduct = null }) { Text("Cancelar") } }
    ) }

    editingAisle?.let { entry -> AlertDialog(
        onDismissRequest = { editingAisle = null },
        title = { Text("Editar cantidad", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold) },
        text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) { Text("La cantidad solo afecta a Mi pasillo.", color = MaterialTheme.colorScheme.onSurfaceVariant); OutlinedTextField(value = newAisleQty, onValueChange = { newAisleQty = it }, modifier = Modifier.fillMaxWidth(), label = { Text("Cantidad nueva") }, singleLine = true, shape = RoundedCornerShape(14.dp)) } },
        confirmButton = { Button(onClick = { val q = newAisleQty.replace(',', '.').toDoubleOrNull(); if (q != null && q >= 0) { onUpdateAisle(entry.id, q, if (q == 0.0) "AGOTADO" else "EN_PASILLO"); editingAisle = null } }, enabled = newAisleQty.replace(',', '.').toDoubleOrNull()?.let { it >= 0 } == true, shape = RoundedCornerShape(12.dp)) { Text("Guardar cambios") } },
        dismissButton = { TextButton(onClick = { editingAisle = null }) { Text("Cancelar") } }
    ) }
}

@Composable
private fun SummaryTile(label: String, value: String, modifier: Modifier = Modifier) {
    Card(modifier = modifier, shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.55f))) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
            Text(label, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text(value, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        }
    }
}

private fun formatQuantity(value: Double): String = if (value % 1.0 == 0.0) value.toLong().toString() else value.toString()
