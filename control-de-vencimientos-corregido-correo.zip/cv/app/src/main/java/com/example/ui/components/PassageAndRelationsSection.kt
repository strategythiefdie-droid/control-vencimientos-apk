package com.example.ui.components

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Place
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.Divider
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.AisleEntryEntity
import com.example.data.ProductWithBatches
import com.example.util.DateUtils
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private const val TAB_LOCATOR = "LOCALIZADOR"
private const val TAB_AISLE_STOCK = "CONTROL_PASILLO"

/**
 * Mi Pasillo has two independent tools:
 * 1) a locator for every product in the active inventory;
 * 2) the previous floor-stock counter, preserved without changing its data.
 * Product location is stored in the existing products.location field so Room and Supabase
 * migrations are not required for this improvement.
 */
@Composable
fun PassageAndRelationsSection(
    products: List<ProductWithBatches>,
    aisleEntries: List<AisleEntryEntity>,
    onAddAisle: (String, String?, Double) -> Unit,
    onUpdateAisle: (String, Double?, String?) -> Unit,
    onRemoveAisle: (String) -> Unit,
    onUpdateProductLocation: (String, String) -> Unit
) {
    var activeTab by remember { mutableStateOf(TAB_LOCATOR) }

    Column(verticalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxWidth()) {
        Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
            Text("Mi pasillo", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
            Text(
                "Encuentra productos por su ubicación y prepara listas de recolección.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
            FilterChip(
                selected = activeTab == TAB_LOCATOR,
                onClick = { activeTab = TAB_LOCATOR },
                label = { Text("Localizador") }
            )
            FilterChip(
                selected = activeTab == TAB_AISLE_STOCK,
                onClick = { activeTab = TAB_AISLE_STOCK },
                label = { Text("Control del pasillo") }
            )
        }

        if (activeTab == TAB_LOCATOR) {
            ProductLocatorSection(products = products, onUpdateProductLocation = onUpdateProductLocation)
        } else {
            AisleStockSection(
                products = products,
                aisleEntries = aisleEntries,
                onAddAisle = onAddAisle,
                onUpdateAisle = onUpdateAisle,
                onRemoveAisle = onRemoveAisle
            )
        }
    }
}

@Composable
private fun ProductLocatorSection(
    products: List<ProductWithBatches>,
    onUpdateProductLocation: (String, String) -> Unit
) {
    var query by remember { mutableStateOf("") }
    var locationFilter by remember { mutableStateOf("TODOS") }
    var selectedProductIds by remember { mutableStateOf<Set<String>>(emptySet()) }
    var showPickupList by remember { mutableStateOf(false) }
    var editingLocationFor by remember { mutableStateOf<ProductWithBatches?>(null) }

    val filteredProducts = products.filter { product ->
        val matchesQuery = query.isBlank() || listOf(
            product.name,
            product.barcode.orEmpty(),
            product.plu.orEmpty(),
            product.location
        ).any { it.contains(query.trim(), ignoreCase = true) }
        val matchesLocation = when (locationFilter) {
            "UBICADOS" -> product.location.isNotBlank()
            "SIN_UBICACION" -> product.location.isBlank()
            else -> true
        }
        matchesQuery && matchesLocation
    }.sortedWith(
        compareBy<ProductWithBatches> { it.location.isBlank() }
            .thenBy { locationSortKey(it.location) }
            .thenBy { it.name.lowercase(Locale.getDefault()) }
    )

    val locatedCount = products.count { it.location.isNotBlank() }
    val unlocatedCount = products.size - locatedCount
    val validSelectedProductIds = selectedProductIds.intersect(products.map { it.id }.toSet())

    Row(horizontalArrangement = Arrangement.spacedBy(7.dp), modifier = Modifier.fillMaxWidth()) {
        SummaryTile("Productos", products.size.toString(), Modifier.weight(1f))
        SummaryTile("Ubicados", locatedCount.toString(), Modifier.weight(1f))
        SummaryTile("Sin lugar", unlocatedCount.toString(), Modifier.weight(1f))
    }

    OutlinedTextField(
        value = query,
        onValueChange = { query = it },
        modifier = Modifier.fillMaxWidth(),
        label = { Text("Buscar producto") },
        placeholder = { Text("Nombre, PLU, código o ubicación") },
        singleLine = true,
        shape = RoundedCornerShape(14.dp)
    )

    Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth()) {
        listOf("TODOS" to "Todos", "UBICADOS" to "Con lugar", "SIN_UBICACION" to "Sin lugar").forEach { (value, label) ->
            FilterChip(
                selected = locationFilter == value,
                onClick = { locationFilter = value },
                label = { Text(label) }
            )
        }
    }

    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text("${filteredProducts.size} resultado(s)", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            TextButton(
                onClick = { selectedProductIds = selectedProductIds + filteredProducts.map { it.id } },
                enabled = filteredProducts.isNotEmpty()
            ) { Text("Seleccionar visibles") }
            TextButton(onClick = { selectedProductIds = emptySet() }, enabled = selectedProductIds.isNotEmpty()) { Text("Limpiar") }
        }
    }

    if (validSelectedProductIds.isNotEmpty()) {
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.65f))
        ) {
            Row(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 9.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                    Text("${validSelectedProductIds.size} producto(s) seleccionados", style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.SemiBold)
                    Text("Ordenados por pasillo, estante, nivel y caja", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                Button(onClick = { showPickupList = true }, shape = RoundedCornerShape(11.dp)) {
                    Text("Lista de recolección")
                }
            }
        }
    }

    if (filteredProducts.isEmpty()) {
        Surface(
            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                Text("No encontramos productos", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                Text("Prueba otra búsqueda o cambia el filtro de ubicación.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    } else {
        filteredProducts.forEach { product ->
            val parts = parseLocation(product.location)
            val selected = product.id in selectedProductIds
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(15.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 9.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(7.dp)
                ) {
                    Checkbox(
                        checked = selected,
                        onCheckedChange = { checked ->
                            selectedProductIds = if (checked) selectedProductIds + product.id else selectedProductIds - product.id
                        }
                    )
                    Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                        Text(product.name, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                        Text(
                            listOfNotNull(
                                product.plu?.takeIf { it.isNotBlank() }?.let { "PLU $it" },
                                product.barcode?.takeIf { it.isNotBlank() }?.let { "Código $it" }
                            ).joinToString(" · ").ifBlank { "Sin identificadores" },
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            androidx.compose.material3.Icon(
                                Icons.Default.Place,
                                contentDescription = "Ubicación",
                                tint = if (product.location.isBlank()) MaterialTheme.colorScheme.onSurfaceVariant else MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(14.dp)
                            )
                            Text(
                                locationDisplay(parts, product.location),
                                style = MaterialTheme.typography.labelMedium,
                                color = if (product.location.isBlank()) MaterialTheme.colorScheme.onSurfaceVariant else MaterialTheme.colorScheme.primary
                            )
                        }
                        Text(
                            "Existencias: ${formatQuantity(product.totalQuantity)} · ${product.batches.size} lote(s)",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    TextButton(onClick = { editingLocationFor = product }) { Text("Editar") }
                }
            }
        }
    }

    editingLocationFor?.let { product ->
        LocationEditorDialog(
            product = product,
            onDismiss = { editingLocationFor = null },
            onSave = { location ->
                onUpdateProductLocation(product.id, location)
                editingLocationFor = null
            }
        )
    }

    if (showPickupList) {
        val selectedProducts = products.filter { it.id in validSelectedProductIds }
            .sortedWith(
                compareBy<ProductWithBatches> { it.location.isBlank() }
                    .thenBy { locationSortKey(it.location) }
                    .thenBy { it.name.lowercase(Locale.getDefault()) }
            )
        PickupListDialog(
            products = selectedProducts,
            onDismiss = { showPickupList = false }
        )
    }
}

@Composable
private fun LocationEditorDialog(
    product: ProductWithBatches,
    onDismiss: () -> Unit,
    onSave: (String) -> Unit
) {
    val initial = remember(product.id, product.location) { parseLocation(product.location) }
    var aisle by remember(product.id, product.location) { mutableStateOf(initial.aisle) }
    var shelf by remember(product.id, product.location) { mutableStateOf(initial.shelf) }
    var level by remember(product.id, product.location) { mutableStateOf(initial.level) }
    var box by remember(product.id, product.location) { mutableStateOf(initial.box) }
    var reference by remember(product.id, product.location) { mutableStateOf(initial.reference) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Ubicación del producto", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(product.name, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                Text(
                    "Completa solo los niveles que utilices. La ubicación se guarda con el producto y se sincroniza con el inventario.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                OutlinedTextField(value = aisle, onValueChange = { aisle = it }, modifier = Modifier.fillMaxWidth(), label = { Text("Pasillo") }, placeholder = { Text("Ej. 2") }, singleLine = true, shape = RoundedCornerShape(12.dp))
                OutlinedTextField(value = shelf, onValueChange = { shelf = it }, modifier = Modifier.fillMaxWidth(), label = { Text("Estante") }, placeholder = { Text("Ej. B") }, singleLine = true, shape = RoundedCornerShape(12.dp))
                OutlinedTextField(value = level, onValueChange = { level = it }, modifier = Modifier.fillMaxWidth(), label = { Text("Nivel") }, placeholder = { Text("Ej. 3") }, singleLine = true, shape = RoundedCornerShape(12.dp))
                OutlinedTextField(value = box, onValueChange = { box = it }, modifier = Modifier.fillMaxWidth(), label = { Text("Caja") }, placeholder = { Text("Ej. 04") }, singleLine = true, shape = RoundedCornerShape(12.dp))
                OutlinedTextField(value = reference, onValueChange = { reference = it }, modifier = Modifier.fillMaxWidth(), label = { Text("Otra referencia (opcional)") }, placeholder = { Text("Ej. Bodega lateral") }, singleLine = true, shape = RoundedCornerShape(12.dp))
            }
        },
        confirmButton = {
            Button(
                onClick = { onSave(buildLocation(aisle, shelf, level, box, reference)) },
                shape = RoundedCornerShape(12.dp)
            ) { Text("Guardar ubicación") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } }
    )
}

@Composable
private fun PickupListDialog(
    products: List<ProductWithBatches>,
    onDismiss: () -> Unit
) {
    var collectedIds by remember(products.map { it.id }) { mutableStateOf<Set<String>>(emptySet()) }
    val groups = products.groupBy { parseLocation(it.location).aisle.ifBlank { "Sin pasillo asignado" } }
    val collectedCount = collectedIds.intersect(products.map { it.id }.toSet()).size

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Lista de recolección", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    "$collectedCount de ${products.size} productos recogidos",
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.primary
                )
                Text(
                    "Recorrido sugerido: pasillo → estante → nivel → caja. Los productos sin ubicación aparecen al final.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                LazyColumn(
                    modifier = Modifier.fillMaxWidth().heightIn(max = 420.dp),
                    verticalArrangement = Arrangement.spacedBy(5.dp)
                ) {
                    groups.forEach { (aisleName, aisleProducts) ->
                        item(key = "heading_$aisleName") {
                            Text(
                                if (aisleName == "Sin pasillo asignado") aisleName else "Pasillo $aisleName",
                                modifier = Modifier.fillMaxWidth().padding(top = 7.dp, bottom = 2.dp),
                                style = MaterialTheme.typography.labelLarge,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                        items(aisleProducts, key = { it.id }) { product ->
                            val isCollected = product.id in collectedIds
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Checkbox(
                                    checked = isCollected,
                                    onCheckedChange = { checked ->
                                        collectedIds = if (checked) collectedIds + product.id else collectedIds - product.id
                                    }
                                )
                                Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                                    Text(
                                        product.name,
                                        style = MaterialTheme.typography.bodyMedium,
                                        fontWeight = FontWeight.SemiBold,
                                        color = if (isCollected) MaterialTheme.colorScheme.onSurfaceVariant else MaterialTheme.colorScheme.onSurface
                                    )
                                    Text(
                                        locationDisplay(parseLocation(product.location), product.location),
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                    Text("Existencias: ${formatQuantity(product.totalQuantity)}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                            }
                            Divider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.35f))
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) { Text("Finalizar") }
        },
        dismissButton = {
            TextButton(onClick = { collectedIds = emptySet() }, enabled = collectedIds.isNotEmpty()) { Text("Reiniciar") }
        }
    )
}

@Composable
private fun AisleStockSection(
    products: List<ProductWithBatches>,
    aisleEntries: List<AisleEntryEntity>,
    onAddAisle: (String, String?, Double) -> Unit,
    onUpdateAisle: (String, Double?, String?) -> Unit,
    onRemoveAisle: (String) -> Unit
) {
    var statusFilter by remember { mutableStateOf("TODOS") }
    var query by remember { mutableStateOf("") }
    var pickerQuery by remember { mutableStateOf("") }
    var showProductPicker by remember { mutableStateOf(false) }
    var aisleProduct by remember { mutableStateOf<ProductWithBatches?>(null) }
    var aisleBatchId by remember { mutableStateOf<String?>(null) }
    var aisleQty by remember { mutableStateOf("0") }
    var editingAisle by remember { mutableStateOf<AisleEntryEntity?>(null) }
    var newAisleQty by remember { mutableStateOf("") }
    val dateFormatter = remember { SimpleDateFormat("HH:mm · dd/MM/yyyy", Locale.getDefault()) }

    val total = aisleEntries.size
    val needsRestock = aisleEntries.count { it.status == "REPOSICION" }
    val empty = aisleEntries.count { it.status == "AGOTADO" || it.quantity <= 0.0 }
    Row(horizontalArrangement = Arrangement.spacedBy(7.dp), modifier = Modifier.fillMaxWidth()) {
        SummaryTile("En seguimiento", total.toString(), Modifier.weight(1f))
        SummaryTile("Reposición", needsRestock.toString(), Modifier.weight(1f))
        SummaryTile("Agotados", empty.toString(), Modifier.weight(1f))
    }

    OutlinedTextField(
        value = query,
        onValueChange = { query = it },
        modifier = Modifier.fillMaxWidth(),
        label = { Text("Buscar en el control del pasillo") },
        placeholder = { Text("Nombre, código, PLU o lugar") },
        singleLine = true,
        shape = RoundedCornerShape(14.dp)
    )
    Button(onClick = { pickerQuery = ""; showProductPicker = true }, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(13.dp)) {
        Text("＋   Agregar producto al control")
    }
    Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth()) {
        listOf("TODOS" to "Todos", "EN_PASILLO" to "En pasillo", "REPOSICION" to "Reponer", "AGOTADO" to "Agotados").forEach { (status, label) ->
            FilterChip(selected = statusFilter == status, onClick = { statusFilter = status }, label = { Text(label) })
        }
    }

    val filtered = aisleEntries.filter { entry ->
        val product = products.firstOrNull { it.id == entry.productId }
        product != null &&
            (query.isBlank() || listOf(product.name, product.barcode.orEmpty(), product.plu.orEmpty(), product.location).any { it.contains(query, true) }) &&
            (statusFilter == "TODOS" || entry.status == statusFilter || (statusFilter == "AGOTADO" && entry.quantity <= 0.0))
    }.sortedWith(
        compareBy<AisleEntryEntity> { if (it.status == "REPOSICION" || it.status == "AGOTADO" || it.quantity <= 0.0) 0 else 1 }
            .thenBy { it.updatedAt }
    )

    if (filtered.isEmpty()) {
        Surface(color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f), shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                Text(if (query.isBlank() && statusFilter == "TODOS") "Aún no llevas productos en este control" else "No encontramos productos", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                Text(
                    if (query.isBlank() && statusFilter == "TODOS") "Agrega productos para controlar la cantidad que hay físicamente en el pasillo. Este conteo no modifica el inventario general."
                    else "Prueba otra búsqueda o cambia el filtro.",
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    style = MaterialTheme.typography.bodySmall
                )
            }
        }
    }

    filtered.forEach { entry ->
        val product = products.firstOrNull { it.id == entry.productId } ?: return@forEach
        val batch = product.batches.firstOrNull { it.id == entry.batchId }
        val days = batch?.let { DateUtils.daysLeft(it.expiryDate) }
        val isEmpty = entry.quantity <= 0.0 || entry.status == "AGOTADO"
        val needs = entry.status == "REPOSICION"
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(15.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
        ) {
            Column(Modifier.padding(11.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                        Text(product.name, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                        Text(product.location.ifBlank { "Lugar sin registrar" }, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                    }
                    AssistChip(onClick = { }, label = { Text(when { isEmpty -> "Agotado"; needs -> "Reponer"; else -> "En pasillo" }) })
                }
                Divider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.45f))
                Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Column(verticalArrangement = Arrangement.spacedBy(1.dp)) {
                        Text("Cantidad en pasillo", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text(formatQuantity(entry.quantity), style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                        OutlinedButton(
                            onClick = { if (entry.quantity > 0) onUpdateAisle(entry.id, (entry.quantity - 1).coerceAtLeast(0.0), if (entry.quantity <= 1) "AGOTADO" else "EN_PASILLO") },
                            enabled = entry.quantity > 0,
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.size(44.dp)
                        ) { Text("−", style = MaterialTheme.typography.titleLarge) }
                        Button(onClick = { onUpdateAisle(entry.id, entry.quantity + 1, "EN_PASILLO") }, shape = RoundedCornerShape(10.dp), modifier = Modifier.size(44.dp)) { Text("+", style = MaterialTheme.typography.titleLarge) }
                    }
                }
                if (batch != null) {
                    Surface(color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f), shape = RoundedCornerShape(10.dp), modifier = Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(9.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                            Text("Lote: ${batch.batchNumber ?: "Sin número"}", style = MaterialTheme.typography.bodySmall)
                            Text(
                                "Vencimiento: ${batch.expiryDate}${when { days != null && days < 0 -> " · VENCIDO"; days != null && days <= 20 -> " · Próximo a vencer"; else -> "" }}",
                                style = MaterialTheme.typography.bodySmall,
                                color = if (days != null && days <= 20) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
                Text("Actualizado ${dateFormatter.format(Date(entry.updatedAt))}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Row(horizontalArrangement = Arrangement.spacedBy(5.dp), modifier = Modifier.fillMaxWidth()) {
                    OutlinedButton(onClick = { editingAisle = entry; newAisleQty = formatQuantity(entry.quantity) }, modifier = Modifier.weight(1f), shape = RoundedCornerShape(10.dp)) { Text("Editar cantidad") }
                    OutlinedButton(onClick = { onUpdateAisle(entry.id, null, "REPOSICION") }, modifier = Modifier.weight(1f), shape = RoundedCornerShape(10.dp)) { Text("Pedir reposición") }
                }
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                    TextButton(onClick = { onUpdateAisle(entry.id, 0.0, "AGOTADO") }) { Text("Marcar agotado") }
                    TextButton(onClick = { onRemoveAisle(entry.id) }) { Text("Retirar") }
                }
            }
        }
    }

    if (showProductPicker) AlertDialog(
        onDismissRequest = { showProductPicker = false },
        title = { Text("Agregar producto", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(9.dp)) {
                Text("Selecciona un producto existente en el inventario.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                OutlinedTextField(value = pickerQuery, onValueChange = { pickerQuery = it }, modifier = Modifier.fillMaxWidth(), label = { Text("Buscar producto") }, singleLine = true, shape = RoundedCornerShape(12.dp))
                val matches = products.filter { product -> pickerQuery.isBlank() || listOf(product.name, product.barcode.orEmpty(), product.plu.orEmpty(), product.location).any { it.contains(pickerQuery, true) } }.take(150)
                if (matches.isEmpty()) Text("No hay coincidencias.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                LazyColumn(modifier = Modifier.fillMaxWidth().heightIn(max = 340.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                    items(matches, key = { it.id }) { product ->
                        Surface(
                            onClick = { aisleProduct = product; aisleBatchId = product.batches.firstOrNull()?.id; aisleQty = "0"; showProductPicker = false },
                            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f),
                            shape = RoundedCornerShape(11.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                                Text(product.name, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold)
                                Text(product.location.ifBlank { "Lugar sin registrar" }, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                                Text("${product.batches.size} lote(s)", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = { showProductPicker = false }) { Text("Cerrar") } }
    )

    aisleProduct?.let { product -> AlertDialog(
        onDismissRequest = { aisleProduct = null },
        title = { Text("Configurar producto", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(product.name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                Text("Define la cantidad que hay físicamente en el pasillo. No cambia el inventario general.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                if (product.batches.isNotEmpty()) {
                    Text("Lote y vencimiento", style = MaterialTheme.typography.labelLarge)
                    LazyColumn(modifier = Modifier.fillMaxWidth().heightIn(max = 175.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                        items(product.sortedBatches, key = { it.id }) { batch ->
                            FilterChip(selected = aisleBatchId == batch.id, onClick = { aisleBatchId = batch.id }, label = { Text("${batch.expiryDate} · stock ${formatQuantity(batch.quantity)}") }, modifier = Modifier.fillMaxWidth())
                        }
                    }
                } else {
                    Text("Este producto no tiene lotes. La cantidad será independiente.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                OutlinedTextField(value = aisleQty, onValueChange = { aisleQty = it }, modifier = Modifier.fillMaxWidth(), label = { Text("Cantidad en pasillo") }, singleLine = true, shape = RoundedCornerShape(12.dp))
            }
        },
        confirmButton = {
            Button(
                onClick = { val quantity = aisleQty.replace(',', '.').toDoubleOrNull(); if (quantity != null && quantity >= 0) { onAddAisle(product.id, aisleBatchId, quantity); aisleProduct = null } },
                enabled = aisleQty.replace(',', '.').toDoubleOrNull()?.let { it >= 0 } == true,
                shape = RoundedCornerShape(12.dp)
            ) { Text("Guardar") }
        },
        dismissButton = { TextButton(onClick = { aisleProduct = null }) { Text("Cancelar") } }
    ) }

    editingAisle?.let { entry -> AlertDialog(
        onDismissRequest = { editingAisle = null },
        title = { Text("Editar cantidad", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("La cantidad solo afecta a Mi pasillo.", color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
                OutlinedTextField(value = newAisleQty, onValueChange = { newAisleQty = it }, modifier = Modifier.fillMaxWidth(), label = { Text("Cantidad nueva") }, singleLine = true, shape = RoundedCornerShape(12.dp))
            }
        },
        confirmButton = {
            Button(
                onClick = { val quantity = newAisleQty.replace(',', '.').toDoubleOrNull(); if (quantity != null && quantity >= 0) { onUpdateAisle(entry.id, quantity, if (quantity == 0.0) "AGOTADO" else "EN_PASILLO"); editingAisle = null } },
                enabled = newAisleQty.replace(',', '.').toDoubleOrNull()?.let { it >= 0 } == true,
                shape = RoundedCornerShape(12.dp)
            ) { Text("Guardar cambios") }
        },
        dismissButton = { TextButton(onClick = { editingAisle = null }) { Text("Cancelar") } }
    ) }
}

private data class LocationParts(
    val aisle: String = "",
    val shelf: String = "",
    val level: String = "",
    val box: String = "",
    val reference: String = ""
)

private fun parseLocation(raw: String): LocationParts {
    if (raw.isBlank()) return LocationParts()
    var aisle = ""
    var shelf = ""
    var level = ""
    var box = ""
    val references = mutableListOf<String>()
    val recognized = Regex("(?i)^(pasillo|estante|nivel|caja|referencia)\\s*:?\\s*(.*)$")
    raw.split(Regex("\\s*[·|;]\\s*")).forEach { rawPart ->
        val part = rawPart.trim()
        val match = recognized.matchEntire(part)
        if (match == null) {
            if (part.isNotBlank()) references += part
        } else {
            val value = match.groupValues[2].trim()
            when (match.groupValues[1].lowercase(Locale.ROOT)) {
                "pasillo" -> aisle = value
                "estante" -> shelf = value
                "nivel" -> level = value
                "caja" -> box = value
                "referencia" -> if (value.isNotBlank()) references += value
            }
        }
    }
    // Keep legacy free-text locations visible and editable rather than discarding them.
    if (aisle.isBlank() && shelf.isBlank() && level.isBlank() && box.isBlank() && references.isEmpty()) {
        return LocationParts(reference = raw.trim())
    }
    return LocationParts(aisle, shelf, level, box, references.joinToString(" · "))
}

private fun buildLocation(aisle: String, shelf: String, level: String, box: String, reference: String): String {
    return buildList {
        aisle.trim().takeIf { it.isNotBlank() }?.let { add("Pasillo: $it") }
        shelf.trim().takeIf { it.isNotBlank() }?.let { add("Estante: $it") }
        level.trim().takeIf { it.isNotBlank() }?.let { add("Nivel: $it") }
        box.trim().takeIf { it.isNotBlank() }?.let { add("Caja: $it") }
        reference.trim().takeIf { it.isNotBlank() }?.let { add("Referencia: $it") }
    }.joinToString(" · ")
}

private fun locationDisplay(parts: LocationParts, raw: String): String {
    val values = buildList {
        parts.aisle.takeIf { it.isNotBlank() }?.let { add("Pasillo $it") }
        parts.shelf.takeIf { it.isNotBlank() }?.let { add("Estante $it") }
        parts.level.takeIf { it.isNotBlank() }?.let { add("Nivel $it") }
        parts.box.takeIf { it.isNotBlank() }?.let { add("Caja $it") }
        parts.reference.takeIf { it.isNotBlank() }?.let { add(it) }
    }
    return values.joinToString(" · ").ifBlank { raw.ifBlank { "Ubicación sin registrar" } }
}

private fun locationSortKey(raw: String): String {
    val parts = parseLocation(raw)
    return listOf(parts.aisle, parts.shelf, parts.level, parts.box, parts.reference)
        .joinToString("|") { value ->
            if (value.isBlank()) "~" else value.lowercase(Locale.ROOT).replace(Regex("\\d+")) { match -> match.value.padStart(10, '0') }
        }
}

@Composable
private fun SummaryTile(label: String, value: String, modifier: Modifier = Modifier) {
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.55f))
    ) {
        Column(Modifier.padding(horizontal = 10.dp, vertical = 9.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
            Text(label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text(value, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        }
    }
}

private fun formatQuantity(value: Double): String = if (value % 1.0 == 0.0) value.toLong().toString() else value.toString()
