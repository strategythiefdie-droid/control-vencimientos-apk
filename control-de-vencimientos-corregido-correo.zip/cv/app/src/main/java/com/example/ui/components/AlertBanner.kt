package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.ProductWithBatches
import com.example.ui.theme.StatusSoonDark
import com.example.util.DateUtils

@Composable
fun AlertBanner(
    soonProducts: List<ProductWithBatches>,
    modifier: Modifier = Modifier
) {
    val urgentBatches = soonProducts.flatMap { p ->
        p.batches.filter { DateUtils.daysLeft(it.expiryDate) in 0..30 }.map { b -> Triple(p.name, b, p.areaId) }
    }

    if (urgentBatches.isEmpty()) return

    val shape = RoundedCornerShape(16.dp)
    val accent = StatusSoonDark

    Box(
        modifier = modifier
            .fillMaxWidth()
            .clip(shape)
            .background(accent.copy(alpha = 0.1f))
            .padding(14.dp)
    ) {
        Column {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(6.dp)
                        .clip(CircleShape)
                        .background(accent)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "Próximos a vencer (${urgentBatches.size} lote(s) en ${soonProducts.size} producto(s))",
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp,
                    color = accent,
                    letterSpacing = 0.2.sp
                )
            }

            Spacer(modifier = Modifier.height(6.dp))

            val displayList = urgentBatches.sortedBy { DateUtils.daysLeft(it.second.expiryDate) }.take(3)
            displayList.forEach { (prodName, batch, areaId) ->
                val days = DateUtils.daysLeft(batch.expiryDate)
                val unit = com.example.util.QuantityFormatter.unitForArea(areaId)
                val formattedQty = "${com.example.util.QuantityFormatter.format(batch.quantity)} $unit"
                val text = if (days == 0L) {
                    "• $prodName [${batch.batchNumber ?: "lote"}] — ¡Vence hoy! ($formattedQty)"
                } else {
                    "• $prodName [${batch.batchNumber ?: "lote"}] — vence en $days días ($formattedQty)"
                }
                Text(
                    text = text,
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurface,
                    lineHeight = 16.sp
                )
            }
        }
    }
}
