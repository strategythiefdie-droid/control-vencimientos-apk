package com.example.util

import android.content.Context
import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import com.example.data.ProductWithBatches

/** Prioridad refrigerados: alerta una sola vez por lote y fecha de vencimiento. */
object SpecialExpiryAlert {
    private const val PREFS = "special_expiry_alerts_v1"
    private const val DAYS_BEFORE = 8L

    private val keywords = listOf(
        "carne", "res", "cerdo", "pollo", "pechuga", "muslo", "ala de pollo",
        "pescado", "salmon", "salmón", "tilapia", "merluza", "mojarra", "camaron", "camarón",
        "mariscos", "atun", "atún", "jamon", "jamón", "salchicha", "chorizo", "mortadela",
        "embutido", "leche", "queso", "yogur", "yogurt", "kumis", "crema de leche",
        "mantequilla", "suero costeño", "lacteo", "lácteo"
    )

    fun isRefrigeratedPriority(areaId: String, productName: String): Boolean {
        if (areaId.equals("lacteos", ignoreCase = true)) return true
        val normalized = productName.lowercase()
        return keywords.any { normalized.contains(it) }
    }

    fun checkAndNotify(context: Context, products: List<ProductWithBatches>) {
        // No marcar lotes como notificados si Android todavía no permite mostrar avisos.
        if (!NotificationManagerCompat.from(context).areNotificationsEnabled()) return
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) return

        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val due = products.asSequence()
            .filter { isRefrigeratedPriority(it.areaId, it.name) }
            .flatMap { product ->
                product.batches.asSequence()
                    .filter { DateUtils.daysLeft(it.expiryDate) == DAYS_BEFORE }
                    .map { batch -> Triple(product, batch, "${product.id}|${batch.id}|${batch.expiryDate}") }
            }
            .filter { (_, _, key) -> !prefs.getBoolean("sent:$key", false) }
            .sortedByDescending { (product, batch, _) ->
                // Prioriza lotes con más unidades/peso; no depende de las fechas de Macro.
                batch.quantity
            }
            .toList()

        if (due.isEmpty()) return

        val body = buildString {
            appendLine("Revisa estos productos refrigerados: ")
            due.take(8).forEach { (product, batch, _) ->
                val quantity = if (QuantityFormatter.isFruitArea(product.areaId)) {
                    "${QuantityFormatter.format(batch.quantity)} kg"
                } else {
                    "${QuantityFormatter.format(batch.quantity)} uds"
                }
                val batchLabel = batch.batchNumber?.takeIf { it.isNotBlank() }?.let { " · Lote $it" } ?: ""
                appendLine("• ${product.name}$batchLabel: vence en 8 días · $quantity")
            }
            if (due.size > 8) appendLine("… y ${due.size - 8} lote(s) prioritario(s) más.")
            append("Revisa las cantidades y aplica las medidas correspondientes.")
        }

        // Los dos verificadores (Worker y AlarmManager) comparten estas marcas persistentes.
        // Guardarlas antes de publicar evita duplicados si ambos se ejecutan casi a la vez.
        val editor = prefs.edit()
        due.forEach { (_, _, key) -> editor.putBoolean("sent:$key", true) }
        editor.apply()

        NotificationHelper.sendSpecialExpiryNotification(
            context = context,
            title = "¡Atención! Productos refrigerados próximos a vencer",
            body = body
        )
    }
}
