package com.example

import com.example.data.BatchEntity
import com.example.data.ProductEntity
import com.example.data.ProductWithBatches
import com.example.util.DateUtils
import com.example.util.ExpiryStatus
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

class ExampleUnitTest {
  private fun dateOffset(days: Int): String {
    val cal = Calendar.getInstance().apply { add(Calendar.DAY_OF_YEAR, days) }
    val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.US)
    return sdf.format(cal.time)
  }

  @Test
  fun testDateParsing() {
    val iso = DateUtils.parseAnyDateToIso("08/10/2026")
    assertEquals("2026-10-08", iso)

    val isoDash = DateUtils.parseAnyDateToIso("2026-10-08")
    assertEquals("2026-10-08", isoDash)
  }

  @Test
  fun testRenewDateCalculation() {
    val renew = DateUtils.calculateRenewDate("2026-10-10", 2)
    assertEquals("2026-10-08", renew)
  }

  @Test
  fun testExpiryStatusRules() {
    assertEquals(ExpiryStatus.EXPIRED, DateUtils.getExpiryStatus(-1))
    assertEquals(ExpiryStatus.TODAY, DateUtils.getExpiryStatus(0))
    assertEquals(ExpiryStatus.SOON, DateUtils.getExpiryStatus(5))
    assertEquals(ExpiryStatus.SOON, DateUtils.getExpiryStatus(20))
    assertEquals(ExpiryStatus.OK, DateUtils.getExpiryStatus(25))
  }

  @Test
  fun testProductWithMultipleBatchesDifferentDates() {
    // User scenario: A product with same PLU and Barcode has 2 batches:
    // Batch 1: < 30 days (alert)
    // Batch 2: > 50 days (ok)
    val productId = "prod-leche-1"
    val product = ProductEntity(
      id = productId,
      areaId = "lacteos",
      name = "Leche Entera Alquería 900ml",
      barcode = "7702111005234",
      plu = "22891"
    )

    val batch1 = BatchEntity(
      id = "batch-1",
      productId = productId,
      batchNumber = "Lote 1",
      quantity = 14,
      expiryDate = dateOffset(22) // < 30 days
    )

    val batch2 = BatchEntity(
      id = "batch-2",
      productId = productId,
      batchNumber = "Lote 2",
      quantity = 20,
      expiryDate = dateOffset(55) // > 50 days
    )

    val productWithBatches = ProductWithBatches(
      product = product,
      batches = listOf(batch1, batch2)
    )

    // Verify properties
    assertEquals(34.0, productWithBatches.totalQuantity, 0.001)
    assertEquals(2, productWithBatches.batches.size)
    assertEquals("7702111005234", productWithBatches.barcode)
    assertEquals("22891", productWithBatches.plu)

    // Batch 1 is < 30 days
    val days1 = DateUtils.daysLeft(batch1.expiryDate)
    assertTrue("Batch 1 should be <= 30 days", days1 in 0..30)

    // Batch 2 is > 50 days
    val days2 = DateUtils.daysLeft(batch2.expiryDate)
    assertTrue("Batch 2 should be > 50 days", days2 > 50)

    // Earliest expiry date is batch 1
    assertEquals(batch1.expiryDate, productWithBatches.earliestExpiryDate)
    assertTrue(productWithBatches.hasSoonBatch)
    assertFalse(productWithBatches.hasExpiredBatch)
  }

  @Test
  fun testBatchExpiredSelection() {
    val b1 = BatchEntity(id = "1", productId = "p1", quantity = 5, expiryDate = dateOffset(-5)) // Expired
    val b2 = BatchEntity(id = "2", productId = "p1", quantity = 10, expiryDate = dateOffset(40)) // Not expired
    val b3 = BatchEntity(id = "3", productId = "p2", quantity = 2, expiryDate = dateOffset(-1)) // Expired

    val batches = listOf(b1, b2, b3)
    val expiredIds = batches.filter { DateUtils.daysLeft(it.expiryDate) < 0 }.map { it.id }.toSet()

    assertEquals(2, expiredIds.size)
    assertTrue(expiredIds.contains("1"))
    assertTrue(expiredIds.contains("3"))
    assertFalse(expiredIds.contains("2"))
  }

  @Test
  fun testSearchFilterByNameAndSku() {
    val p1 = ProductWithBatches(
      product = ProductEntity(id = "1", areaId = "lacteos", name = "Yogur Alpina Fresa", barcode = "7702001004123", plu = "43534"),
      batches = listOf(BatchEntity(productId = "1", quantity = 10, expiryDate = dateOffset(5)))
    )
    val p2 = ProductWithBatches(
      product = ProductEntity(id = "2", areaId = "lacteos", name = "Leche Entera Alquería", barcode = "7702111005234", plu = "22891"),
      batches = listOf(BatchEntity(productId = "2", quantity = 15, expiryDate = dateOffset(12)))
    )

    val list = listOf(p1, p2)

    // Filter by name
    val byName = list.filter {
      val q = "alpina".lowercase()
      it.name.lowercase().contains(q) || it.barcode?.contains(q) == true || it.plu?.contains(q) == true
    }
    assertEquals(1, byName.size)
    assertEquals("1", byName[0].id)

    // Filter by SKU / barcode
    val bySku = list.filter {
      val q = "7702111".lowercase()
      it.name.lowercase().contains(q) || it.barcode?.contains(q) == true || it.plu?.contains(q) == true
    }
    assertEquals(1, bySku.size)
    assertEquals("2", bySku[0].id)
  }

  @Test
  fun testMultiScanAggregation() {
    val items = mutableListOf<com.example.data.MultiScanItem>()
    val barcode1 = "7702001004123"

    // First scan of barcode1
    items.add(com.example.data.MultiScanItem(barcode = barcode1, name = "Yogur Alpina Fresa", quantity = 1))

    // Second scan of same barcode
    val idx = items.indexOfFirst { it.barcode == barcode1 }
    assertTrue(idx >= 0)
    items[idx] = items[idx].copy(quantity = items[idx].quantity + 1)

    // Third scan of different barcode
    val barcode2 = "7702111005234"
    items.add(com.example.data.MultiScanItem(barcode = barcode2, name = "Leche Alquería", quantity = 1))

    assertEquals(2, items.size)
    assertEquals(2.0, items[0].quantity, 0.001)
    assertEquals(1.0, items[1].quantity, 0.001)
    assertEquals(3.0, items.sumOf { it.quantity }, 0.001)
  }

  @Test
  fun testDecimalWeightForFruits() {
    val b1 = BatchEntity(id = "fruit-1", productId = "apple-1", quantity = 0.252, expiryDate = "2026-10-25")
    val b2 = BatchEntity(id = "fruit-2", productId = "apple-1", quantity = 1.500, expiryDate = "2026-10-30")
    val product = ProductEntity(id = "apple-1", areaId = "fruver", name = "Manzana Roja", plu = "4133")

    val pWithBatches = ProductWithBatches(product = product, batches = listOf(b1, b2))
    assertEquals(1.752, pWithBatches.totalQuantity, 0.0001)
    assertEquals("1.752", com.example.util.QuantityFormatter.format(pWithBatches.totalQuantity))
    assertEquals("0.252", com.example.util.QuantityFormatter.format(b1.quantity))
    assertEquals("1.5", com.example.util.QuantityFormatter.format(b2.quantity))
  }

  @Test
  fun testMacroTwoDayDelayAndRenewRule() {
    // When uploaded on Wednesday, discount starts 2 days later on Friday
    val uploadDate = "2026-10-14" // Wednesday
    val expectedStart = "2026-10-16" // Friday (+2 days)
    val calculatedStart = DateUtils.addDaysToIso(uploadDate, 2)
    assertEquals(expectedStart, calculatedStart)

    // Discount ends on Friday 2026-10-23
    val endDate = "2026-10-23"
    // Re-upload must happen 2 days before endDate -> 2026-10-21 (Wednesday)
    val renewDate = DateUtils.calculateRenewDate(endDate, 2)
    assertEquals("2026-10-21", renewDate)
  }

  @Test
  fun testExpiryWorkerPeriodicTag() {
    assertEquals("periodic_expiry_check_worker", com.example.worker.ExpiryNotificationWorker.PERIODIC_WORK_TAG)
  }
}
