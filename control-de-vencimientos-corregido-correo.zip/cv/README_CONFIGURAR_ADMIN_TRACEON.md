# Acceso local a TUSK y acceso administrativo

## Contraseña local de TUSK

En esta versión, la entrada al inventario TUSK solicita `TRACEON`.

- La constante está definida en `app/src/main/java/com/example/profile/LocalTuskAccess.kt`.
- La comprobación se realiza localmente en Android.
- Se solicita al elegir TUSK y al abrir la app en un nuevo inicio en frío cuando TUSK quedó como perfil activo.
- No se envía la contraseña a Supabase, no se crea una sesión ni se necesita una migración SQL para esta comprobación.
- No cambies esta constante si deseas conservar `TRACEON` como contraseña permanente de TUSK.

**Límite de seguridad:** una contraseña incluida en el código de una APK puede extraerse mediante ingeniería inversa. Este control sirve como bloqueo local de la interfaz, no como protección de datos frente a un atacante con acceso a la APK o a las API. La protección remota depende de Supabase Auth y RLS.

## Acceso administrativo

El acceso a CEDI y Macro conserva el mecanismo administrativo que ya tenía este proyecto. La contraseña de TUSK no modifica ni sustituye ese flujo. Consulta `README_SUPABASE_APPS1.md` y la implementación de `SupabaseAdminRepository.kt` para la configuración vigente.

## Otros perfiles

- ACT 1–ACT 4 mantienen sus códigos temporales de vinculación de un solo uso y su autorización mediante `admin-gateway`.
- TESTER continúa siendo local, separado y sin sincronización ni correos reales.

## Cambios de esta actualización

Esta entrega solo añade la contraseña local de TUSK y actualiza la documentación y el número de versión Android. No requiere ejecutar SQL, modificar tablas, cambiar políticas RLS ni volver a desplegar `admin-gateway`.
