# Configurar el modo administrador con solo la contraseña TRACEON

Esta app utiliza una Edge Function llamada `admin-gateway`. La contraseña se comprueba en el servidor de Supabase, no dentro del APK. Tras validar la contraseña, el servidor emite un token firmado de 15 minutos. La función usa la clave privilegiada solo en el servidor; nunca copies una `service_role`/secret key a la app ni a GitHub.

## A. Configurar los secretos del servidor

1. Abre https://supabase.com/dashboard e ingresa al proyecto **apps1** (ref. `hhncacdqvmxsilkpzniy`).
2. En el menú del proyecto entra en **Edge Functions** y luego en **Secrets** (en algunas versiones aparece como **Edge Function Secrets**).
3. Añade estos dos secretos exactamente con estos nombres:
   - `ADMIN_PASSWORD` → `TRACEON`
   - `ADMIN_SESSION_SECRET` → una cadena aleatoria larga y privada, de al menos 32 caracteres. No uses `TRACEON` para este segundo secreto. Puedes generar una desde un gestor de contraseñas.
4. Guarda los secretos. No pongas estos valores en SQL Editor, `local.properties`, el código Kotlin ni en un repositorio público.
5. `SUPABASE_URL` y `SUPABASE_SERVICE_ROLE_KEY` suelen estar disponibles como variables de entorno del proyecto para Edge Functions. Si la función devuelve `Admin gateway is not configured correctly`, verifica que la función tenga acceso a la clave privilegiada del servidor. Nunca la pegues aquí ni la incluyas en el APK.

## B. Publicar `admin-gateway`

La carpeta `supabase/functions/admin-gateway/index.ts` de este proyecto contiene el código que valida `ADMIN_PASSWORD`.

**Si usas Supabase Dashboard:**

1. En **Edge Functions**, abre `admin-gateway` si ya existe. Si no existe, crea una función con ese nombre.
2. Sustituye el código por el contenido completo de `supabase/functions/admin-gateway/index.ts` de este ZIP.
3. Pulsa **Deploy updates** / **Deploy function**.
4. En la configuración de la función, desactiva **Verify JWT** para `admin-gateway`. Esta función valida su propio acceso mediante la contraseña y el token temporal. La publishable key sigue viajando en el encabezado `apikey`; no es la contraseña administrativa.

**Si usas Supabase CLI** desde la carpeta del proyecto:

```bash
supabase login
supabase link --project-ref hhncacdqvmxsilkpzniy
supabase functions deploy admin-gateway --no-verify-jwt
```

El archivo `supabase/config.toml` de este proyecto también declara `verify_jwt = false` para esa función.

## C. Probar el acceso

1. Instala una APK que contenga esta versión del código.
2. Abre la app normalmente: debe entrar como **TUSK**, sin pedir usuario.
3. Entra en el acceso de administrador desde la zona administrativa e introduce únicamente `TRACEON`.
4. Si falla, abre **Edge Functions → admin-gateway → Logs** y revisa el error. No compartas claves ni secretos en capturas.

Errores frecuentes:

- **404 / Function not found:** no se ha publicado `admin-gateway` o el nombre no coincide.
- **401 / Invalid JWT:** activa la configuración `verify_jwt = false` para esta función y vuelve a desplegarla; revisa que la APK llame a `/functions/v1/admin-gateway`.
- **500 / Admin gateway is not configured correctly:** falta `ADMIN_PASSWORD`, falta `ADMIN_SESSION_SECRET` o la función no ve las variables privilegiadas necesarias.
- **Contraseña incorrecta:** confirma que el secreto se llame `ADMIN_PASSWORD` y que su valor sea exactamente `TRACEON`, sin espacios al inicio o al final.

## Seguridad importante

`TRACEON` es una contraseña compartida y relativamente sencilla. Quien la conozca puede intentar acceder al modo administrador. Para reducir riesgos, no publiques el APK con acceso abierto, limita quién puede instalarlo y cambia la contraseña si se divulga. La sesión que genera esta función caduca en 15 minutos. La clave privilegiada de Supabase nunca debe salir del entorno del servidor.
