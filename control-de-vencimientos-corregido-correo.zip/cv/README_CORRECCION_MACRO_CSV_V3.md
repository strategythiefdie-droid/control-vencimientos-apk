# Corrección de importación Macro CSV (v3)

Cambios realizados sobre la versión de proyecto recibida:

- La importación sigue las columnas por nombre de encabezado; no toma valores por posición fija.
- `PLU` se almacena en `ProductEntity.plu`, nunca en `barcode`.
- `Descripcion` se guarda como nombre limpio del producto.
- `Fecha_Vencimiento` y `Cantidad_Vencer` se guardan en el lote físico.
- `DesdeCuando`, `HastaCuando` y `PorcentajeDescue` se guardan exclusivamente en el registro Macro.
- Al reimportar, se actualizan registros/lotes existentes en vez de saltarlos solo por ser duplicados.
- Se intenta reparar registros contaminados por una importación anterior: si el PLU quedó en barcode, se mueve a PLU; si el nombre quedó con datos de toda la fila, se reemplaza con `Descripcion` del CSV.
- Se corrigió un error de estado: el mensaje de éxito se enviaba en el campo `errorMessage`, por lo que la app mostraba una falsa alerta de error y no cerraba correctamente el modal.
- `Estado Solic...` y `Detalle Estado` se ignoran.

CSV de comprobación usado: 14 filas, encabezados `PLU,Descripcion,Fecha_Vencimiento,Cantidad_Vencer,DesdeCuando,HastaCuando,PorcentajeDescue`. Primera fila esperada: PLU `3713157`, nombre `Jamon De Cerdo`, vencimiento `2026-10-13`, cantidad `8`, inicio Macro `2026-10-09`, fin Macro `2026-10-13`, descuento `20`.

No se pudo compilar ni ejecutar el APK en este entorno. El reconocimiento OCR de una foto sigue siendo texto extraído sin asignación fiable de celdas; para importar las columnas, usar el CSV. Abrir el proyecto en Android Studio y sincronizar Gradle para validar compilación.
