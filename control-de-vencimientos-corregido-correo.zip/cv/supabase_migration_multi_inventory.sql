-- Control de Vencimientos: perfiles de inventario y dispositivos autorizados.
-- Ejecutar en Supabase SQL Editor. No borra productos existentes.
create extension if not exists pgcrypto;

-- Compatibility repair: an earlier draft may have created this catalog with
-- `workspace_id`. The application/server expects `id`. Rename instead of dropping
-- the table so existing rows and its primary key are preserved.
do $$
begin
  if to_regclass('public.inventory_workspaces') is not null
     and exists (
       select 1 from information_schema.columns
       where table_schema = 'public' and table_name = 'inventory_workspaces'
         and column_name = 'workspace_id'
     )
     and not exists (
       select 1 from information_schema.columns
       where table_schema = 'public' and table_name = 'inventory_workspaces'
         and column_name = 'id'
     ) then
    alter table public.inventory_workspaces rename column workspace_id to id;
  end if;
end $$;

create table if not exists public.inventory_workspaces (
  id text primary key,
  display_name text not null,
  is_active boolean not null default true,
  created_at timestamptz not null default now()
);

insert into public.inventory_workspaces(id, display_name) values
 ('TUSK','TUSK'),('TUSK_ACT_1','TUSK ACT 1'),('TUSK_ACT_2','TUSK ACT 2'),
 ('TUSK_ACT_3','TUSK ACT 3'),('TUSK_ACT_4','TUSK ACT 4')
on conflict (id) do nothing;

create table if not exists public.inventory_device_invites (
  id uuid primary key default gen_random_uuid(),
  code_hash text not null unique,
  workspace_id text not null references public.inventory_workspaces(id),
  expires_at timestamptz not null,
  created_at timestamptz not null default now(),
  used_at timestamptz,
  used_by_device_hash text
);

create table if not exists public.inventory_device_bindings (
  device_hash text primary key,
  workspace_id text not null references public.inventory_workspaces(id),
  label text not null default '',
  created_at timestamptz not null default now(),
  last_seen_at timestamptz not null default now(),
  revoked_at timestamptz
);

-- Hashed long-lived device credential. The raw token is returned only once at binding time.
alter table public.inventory_device_bindings add column if not exists token_hash text;

alter table public.inventory_workspaces enable row level security;
alter table public.inventory_device_invites enable row level security;
alter table public.inventory_device_bindings enable row level security;
-- No direct client access. The admin-gateway uses the service role after validating admin session.
drop policy if exists "deny client access workspaces" on public.inventory_workspaces;
drop policy if exists "deny client access invites" on public.inventory_device_invites;
drop policy if exists "deny client access bindings" on public.inventory_device_bindings;
create policy "deny client access workspaces" on public.inventory_workspaces for all to anon, authenticated using (false) with check (false);
create policy "deny client access invites" on public.inventory_device_invites for all to anon, authenticated using (false) with check (false);
create policy "deny client access bindings" on public.inventory_device_bindings for all to anon, authenticated using (false) with check (false);

-- Add workspace isolation to cloud inventory tables while preserving old TUSK data.
-- Secondary profiles are owned by an authorized device/workspace, not by a Supabase Auth user.
-- Their rows are written only by admin-gateway (service role); user_id-based client RLS keeps
-- these NULL-owner rows inaccessible to ordinary authenticated clients. Existing TUSK rows retain
-- their user_id and legacy synchronization behavior.
alter table public.products alter column user_id drop not null;
alter table public.inventory_batches alter column user_id drop not null;

alter table public.products add column if not exists workspace_id text;
update public.products set workspace_id='TUSK' where workspace_id is null;
alter table public.products alter column workspace_id set default 'TUSK';
alter table public.products alter column workspace_id set not null;
create index if not exists products_workspace_id_idx on public.products(workspace_id);

alter table public.inventory_batches add column if not exists workspace_id text;
update public.inventory_batches b set workspace_id=coalesce(p.workspace_id,'TUSK') from public.products p where b.product_id=p.id and b.workspace_id is null;
update public.inventory_batches set workspace_id='TUSK' where workspace_id is null;
alter table public.inventory_batches alter column workspace_id set default 'TUSK';
alter table public.inventory_batches alter column workspace_id set not null;
create index if not exists inventory_batches_workspace_id_idx on public.inventory_batches(workspace_id);

alter table public.macro_records add column if not exists workspace_id text;
update public.macro_records set workspace_id='TUSK' where workspace_id is null;
alter table public.macro_records alter column workspace_id set default 'TUSK';
alter table public.macro_records alter column workspace_id set not null;
create index if not exists macro_records_workspace_id_idx on public.macro_records(workspace_id);

-- NOTE: existing row-level policies still scope authenticated users by user_id.
-- All cross-workspace/device invite operations must go through admin-gateway.


-- Consumo atómico del código: evita que dos dispositivos usen el mismo código simultáneamente.
create or replace function public.consume_inventory_device_invite(p_code_hash text, p_device_hash text)
returns table(invite_id uuid, workspace_id text)
language plpgsql
security definer
set search_path = public
as $$
begin
  return query
  update public.inventory_device_invites i
     set used_at = now(), used_by_device_hash = p_device_hash
   where i.code_hash = p_code_hash
     and i.used_at is null
     and i.expires_at > now()
  returning i.id, i.workspace_id;
end;
$$;
revoke all on function public.consume_inventory_device_invite(text, text) from public, anon, authenticated;
grant execute on function public.consume_inventory_device_invite(text, text) to service_role;


-- Defensa adicional en la base de datos: incluso si dos peticiones compiten, una fila
-- existente no puede cambiar de inventario y un lote no puede apuntar a un producto ajeno.
create or replace function public.enforce_inventory_product_workspace()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  if not exists (select 1 from public.inventory_workspaces w where w.id = new.workspace_id) then
    raise exception 'workspace_id no válido';
  end if;
  if tg_op = 'UPDATE' and old.workspace_id is distinct from new.workspace_id then
    raise exception 'No se permite mover un producto entre inventarios';
  end if;
  return new;
end;
$$;

drop trigger if exists products_workspace_guard on public.products;
create trigger products_workspace_guard
before insert or update of workspace_id on public.products
for each row execute function public.enforce_inventory_product_workspace();

create or replace function public.enforce_inventory_batch_workspace()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
declare
  parent_workspace text;
begin
  if tg_op = 'UPDATE' and old.workspace_id is distinct from new.workspace_id then
    raise exception 'No se permite mover un lote entre inventarios';
  end if;
  select p.workspace_id into parent_workspace
    from public.products p where p.id = new.product_id;
  if parent_workspace is null or parent_workspace is distinct from new.workspace_id then
    raise exception 'El lote y su producto deben pertenecer al mismo inventario';
  end if;
  return new;
end;
$$;

drop trigger if exists inventory_batches_workspace_guard on public.inventory_batches;
create trigger inventory_batches_workspace_guard
before insert or update of workspace_id, product_id on public.inventory_batches
for each row execute function public.enforce_inventory_batch_workspace();

revoke all on function public.enforce_inventory_product_workspace() from public, anon, authenticated;
revoke all on function public.enforce_inventory_batch_workspace() from public, anon, authenticated;

-- Ubicación física opcional de cada producto.
alter table public.products add column if not exists location text not null default '';
alter table public.products add column if not exists location_updated_at bigint not null default 0;
alter table public.products add column if not exists has_return boolean not null default false;
alter table public.products add column if not exists return_updated_at bigint not null default 0;
