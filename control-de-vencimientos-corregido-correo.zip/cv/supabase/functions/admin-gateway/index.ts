// Password-only administrator gateway. Secrets belong only in Supabase Function secrets.
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, apikey, content-type, x-client-info",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};
const encoder = new TextEncoder();
const SESSION_TTL_SECONDS = 15 * 60;

const json = (body: unknown, status = 200) => new Response(JSON.stringify(body), {
  status, headers: { ...corsHeaders, "Content-Type": "application/json" },
});
function toBase64Url(bytes: Uint8Array): string {
  let binary = "";
  for (const b of bytes) binary += String.fromCharCode(b);
  return btoa(binary).replace(/=/g, "").replace(/\+/g, "-").replace(/\//g, "_");
}
function fromBase64Url(value: string): Uint8Array {
  const base64 = value.replace(/-/g, "+").replace(/_/g, "/");
  const padded = base64 + "=".repeat((4 - base64.length % 4) % 4);
  return Uint8Array.from(atob(padded), (c) => c.charCodeAt(0));
}
function constantTimeEqual(a: string, b: string): boolean {
  const aa = encoder.encode(a);
  const bb = encoder.encode(b);
  let diff = aa.length ^ bb.length;
  const n = Math.max(aa.length, bb.length);
  for (let i = 0; i < n; i++) diff |= (aa[i % Math.max(aa.length, 1)] ?? 0) ^ (bb[i % Math.max(bb.length, 1)] ?? 0);
  return diff === 0;
}
async function sign(data: string, secret: string): Promise<Uint8Array> {
  const key = await crypto.subtle.importKey("raw", encoder.encode(secret), { name: "HMAC", hash: "SHA-256" }, false, ["sign"]);
  return new Uint8Array(await crypto.subtle.sign("HMAC", key, encoder.encode(data)));
}
async function issueSession(secret: string): Promise<string> {
  const payload = toBase64Url(encoder.encode(JSON.stringify({ sub: "admin", exp: Math.floor(Date.now() / 1000) + SESSION_TTL_SECONDS })));
  const signature = toBase64Url(await sign(payload, secret));
  return `${payload}.${signature}`;
}
async function validSession(token: string, secret: string): Promise<boolean> {
  try {
    const parts = token.split(".");
    if (parts.length !== 2 || parts.some((part) => !part || part.length > 2048)) return false;
    const expected = toBase64Url(await sign(parts[0], secret));
    if (!constantTimeEqual(parts[1], expected)) return false;
    const payload = JSON.parse(new TextDecoder().decode(fromBase64Url(parts[0])));
    return payload.sub === "admin" && Number.isInteger(payload.exp) && payload.exp > Math.floor(Date.now() / 1000);
  } catch { return false; }
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });
  if (req.method !== "POST") return json({ error: "Method not allowed" }, 405);

  const expected = Deno.env.get("ADMIN_PASSWORD");
  const url = Deno.env.get("SUPABASE_URL");
  // Supabase currently exposes the legacy service-role env name in many projects.
  // Keep this server-only; never send this key to the Android app.
  const serviceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
  const sessionSecret = Deno.env.get("ADMIN_SESSION_SECRET");

  // Log presence/length only. Never log any secret values.
  console.log("admin-gateway config check", {
    hasAdminPassword: !!expected,
    hasSupabaseUrl: !!url,
    hasServiceRoleKey: !!serviceKey,
    hasSessionSecret: !!sessionSecret,
    sessionSecretLengthOk: !!sessionSecret && sessionSecret.length >= 32,
  });

  let body: { password?: string; sessionToken?: string; action?: string; userId?: string; workspaceId?: string; deviceId?: string; deviceToken?: string; label?: string; code?: string; mode?: string; products?: unknown[]; batches?: unknown[]; deleteProducts?: string[]; deleteBatches?: string[] };
  try { body = await req.json(); } catch { return json({ error: "Invalid JSON" }, 400); }

  // Password login only needs the password and signing secret. Missing database
  // credentials must not mask login as a generic 500; database actions check below.
  if (!expected || !sessionSecret || sessionSecret.length < 32) {
    const missing = [!expected ? "ADMIN_PASSWORD" : null, (!sessionSecret || sessionSecret.length < 32) ? "ADMIN_SESSION_SECRET (mínimo 32 caracteres)" : null].filter(Boolean);
    return json({ error: "Falta configuración del acceso administrativo.", missing }, 500);
  }

  if (body.action === "login") {
    const supplied = typeof body.password === "string" ? body.password : "";
    if (!supplied || supplied.length > 256 || !constantTimeEqual(supplied, expected)) {
      return json({ error: "Contraseña de administrador incorrecta." }, 401);
    }
    return json({ ok: true, sessionToken: await issueSession(sessionSecret), expiresIn: SESSION_TTL_SECONDS, displayName: "Administrador" });
  }

  // Device authorization is a machine-to-server check, not an administrator action.
  // It accepts only the raw device ID + one-time-issued device token; database stores hashes.
  if (body.action === "authorize-device") {
    if (!url || !serviceKey) return json({ error: "Servicio de autorización no configurado." }, 500);
    const deviceId = typeof body.deviceId === "string" ? body.deviceId.trim() : "";
    const deviceToken = typeof body.deviceToken === "string" ? body.deviceToken.trim() : "";
    const workspaceId = typeof body.workspaceId === "string" ? body.workspaceId.trim() : "";
    if (deviceId.length < 16 || deviceId.length > 256 || !/^[a-f0-9]{64}$/i.test(deviceToken) || !/^[A-Z0-9_]{2,40}$/.test(workspaceId)) {
      return json({ authorized: false, error: "Credenciales del dispositivo inválidas." }, 400);
    }
    const sha256 = async (value: string) => Array.from(new Uint8Array(await crypto.subtle.digest("SHA-256", encoder.encode(value))), b => b.toString(16).padStart(2, "0")).join("");
    const deviceHash = await sha256(deviceId);
    const tokenHash = await sha256(deviceToken);
    const deviceClient = createClient(url, serviceKey, { auth: { persistSession: false, autoRefreshToken: false } });
    const { data: binding, error: bindingError } = await deviceClient.from("inventory_device_bindings")
      .select("workspace_id,token_hash,revoked_at")
      .eq("device_hash", deviceHash).maybeSingle();
    if (bindingError) return json({ authorized: false, error: "No se pudo comprobar la autorización." }, 500);
    if (!binding || binding.revoked_at || binding.workspace_id !== workspaceId || !binding.token_hash || !constantTimeEqual(binding.token_hash, tokenHash)) {
      return json({ authorized: false, error: "Dispositivo no autorizado o acceso revocado." }, 401);
    }
    const { data: workspace, error: workspaceError } = await deviceClient.from("inventory_workspaces")
      .select("id").eq("id", workspaceId).eq("is_active", true).maybeSingle();
    if (workspaceError || !workspace) return json({ authorized: false, error: "Inventario desactivado o no disponible." }, 403);
    const { error: touchError } = await deviceClient.from("inventory_device_bindings")
      .update({ last_seen_at: new Date().toISOString() }).eq("device_hash", deviceHash).is("revoked_at", null);
    if (touchError) return json({ authorized: false, error: "No se pudo actualizar la actividad del dispositivo." }, 500);
    return json({ authorized: true, workspaceId });
  }

  // Device-scoped inventory endpoint. The service-role key never leaves this function.
  // Every request revalidates the device token and forces workspace_id server-side.
  if (body.action === "sync-inventory") {
    if (!url || !serviceKey) return json({ error: "Servicio de sincronización no configurado." }, 500);
    const deviceId = typeof body.deviceId === "string" ? body.deviceId.trim() : "";
    const deviceToken = typeof body.deviceToken === "string" ? body.deviceToken.trim() : "";
    const workspaceId = typeof body.workspaceId === "string" ? body.workspaceId.trim() : "";
    const mode = typeof body.mode === "string" ? body.mode : "";
    if (deviceId.length < 16 || deviceId.length > 256 || !/^[a-f0-9]{64}$/i.test(deviceToken) || !/^TUSK_ACT_[1-4]$/.test(workspaceId) || !["pull", "push", "delete"].includes(mode)) {
      return json({ error: "Solicitud de sincronización inválida." }, 400);
    }
    const sha256 = async (value: string) => Array.from(new Uint8Array(await crypto.subtle.digest("SHA-256", encoder.encode(value))), b => b.toString(16).padStart(2, "0")).join("");
    const deviceHash = await sha256(deviceId);
    const tokenHash = await sha256(deviceToken);
    const db = createClient(url, serviceKey, { auth: { persistSession: false, autoRefreshToken: false } });
    const { data: binding, error: bindingError } = await db.from("inventory_device_bindings")
      .select("workspace_id,token_hash,revoked_at").eq("device_hash", deviceHash).maybeSingle();
    if (bindingError) return json({ error: "No se pudo validar el dispositivo." }, 500);
    if (!binding || binding.revoked_at || binding.workspace_id !== workspaceId || !binding.token_hash || !constantTimeEqual(binding.token_hash, tokenHash)) {
      return json({ error: "Dispositivo no autorizado o acceso revocado." }, 401);
    }
    const { data: activeWorkspace, error: activeError } = await db.from("inventory_workspaces")
      .select("id").eq("id", workspaceId).eq("is_active", true).maybeSingle();
    if (activeError || !activeWorkspace) return json({ error: "Inventario desactivado o no disponible." }, 403);
    const { error: touchError } = await db.from("inventory_device_bindings")
      .update({ last_seen_at: new Date().toISOString() }).eq("device_hash", deviceHash).is("revoked_at", null);
    if (touchError) return json({ error: "No se pudo actualizar la actividad del dispositivo." }, 500);

    if (mode === "pull") {
      const [{ data: products, error: pe }, { data: batches, error: be }] = await Promise.all([
        db.from("products").select("id,user_id,workspace_id,name,barcode,plu,area_id,unit_cost,created_at").eq("workspace_id", workspaceId),
        db.from("inventory_batches").select("id,user_id,workspace_id,product_id,batch_number,quantity,expiry_date,created_at").eq("workspace_id", workspaceId),
      ]);
      if (pe || be) return json({ error: "No se pudo leer el inventario autorizado." }, 500);
      return json({ ok: true, workspaceId, products: products ?? [], batches: batches ?? [] });
    }
    if (mode === "push") {
      const products = Array.isArray(body.products) ? body.products : [];
      const batches = Array.isArray(body.batches) ? body.batches : [];
      if (products.length > 500 || batches.length > 2000) return json({ error: "Lote de sincronización demasiado grande." }, 413);
      const validUuid = (v: unknown) => typeof v === "string" && /^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(v);
      for (const item of [...products, ...batches]) {
        if (!item || typeof item !== "object" || !validUuid((item as Record<string, unknown>).id)) return json({ error: "Registro con identificador inválido." }, 400);
        const suppliedWorkspace = (item as Record<string, unknown>).workspace_id;
        if (suppliedWorkspace !== undefined && suppliedWorkspace !== workspaceId) return json({ error: "El registro intenta cambiar de inventario." }, 403);
      }
      // Allow-list fields instead of spreading client objects: device clients must not be able
      // to alter ownership columns or write arbitrary columns through the service-role client.
      const productRows = products.map((value) => {
        const p = value as Record<string, unknown>;
        return {
          id: p.id,
          name: typeof p.name === "string" ? p.name.slice(0, 300) : "Producto",
          area_id: typeof p.area_id === "string" ? p.area_id.slice(0, 120) : "otros",
          category: typeof p.category === "string" ? p.category.slice(0, 120) : (typeof p.area_id === "string" ? p.area_id.slice(0, 120) : "otros"),
          barcode: typeof p.barcode === "string" ? p.barcode.slice(0, 100) : null,
          plu: typeof p.plu === "string" ? p.plu.slice(0, 100) : null,
          unit_cost: typeof p.unit_cost === "number" && Number.isFinite(p.unit_cost) ? p.unit_cost : null,
          quantity: typeof p.quantity === "number" && Number.isFinite(p.quantity) ? p.quantity : null,
          expiry_date: typeof p.expiry_date === "string" ? p.expiry_date.slice(0, 10) : null,
          created_at: typeof p.created_at === "string" ? p.created_at : new Date().toISOString(),
          workspace_id: workspaceId,
        };
      });
      const batchRows = batches.map((value) => {
        const b = value as Record<string, unknown>;
        return {
          id: b.id,
          product_id: b.product_id,
          batch_number: typeof b.batch_number === "string" ? b.batch_number.slice(0, 120) : null,
          quantity: typeof b.quantity === "number" && Number.isFinite(b.quantity) ? b.quantity : 0,
          expiry_date: typeof b.expiry_date === "string" ? b.expiry_date.slice(0, 10) : "",
          created_at: typeof b.created_at === "string" ? b.created_at : new Date().toISOString(),
          workspace_id: workspaceId,
        };
      });
      // Never allow an upsert conflict to move an existing row between workspaces.
      const productIds = productRows.map((p) => p.id as string);
      const batchIds = batchRows.map((b) => b.id as string);
      if (productIds.length) {
        const { data: existing, error } = await db.from("products").select("id,workspace_id").in("id", productIds);
        if (error) return json({ error: "No se pudo validar la pertenencia de los productos." }, 500);
        if ((existing ?? []).some((row) => row.workspace_id !== workspaceId)) return json({ error: "Uno o más productos ya pertenecen a otro inventario." }, 403);
      }
      if (batchIds.length) {
        const { data: existing, error } = await db.from("inventory_batches").select("id,workspace_id").in("id", batchIds);
        if (error) return json({ error: "No se pudo validar la pertenencia de los lotes." }, 500);
        if ((existing ?? []).some((row) => row.workspace_id !== workspaceId)) return json({ error: "Uno o más lotes ya pertenecen a otro inventario." }, 403);
      }
      if (productRows.length) {
        const { error } = await db.from("products").upsert(productRows, { onConflict: "id" });
        if (error) return json({ error: "No se pudieron guardar los productos." }, 500);
      }
      if (batchRows.length) {
        // Prevent a batch from referencing a product in another workspace.
        const productIds = [...new Set(batchRows.map((b) => b.product_id).filter((v): v is string => typeof v === "string"))];
        if (productIds.length) {
          const { data: validProducts, error } = await db.from("products").select("id").eq("workspace_id", workspaceId).in("id", productIds);
          if (error || (validProducts ?? []).length !== productIds.length) return json({ error: "Hay lotes que no pertenecen a productos de este inventario." }, 403);
        }
        const { error } = await db.from("inventory_batches").upsert(batchRows, { onConflict: "id" });
        if (error) return json({ error: "No se pudieron guardar los lotes." }, 500);
      }
      return json({ ok: true, workspaceId, products: productRows.length, batches: batchRows.length });
    }
    const productIds = Array.isArray(body.deleteProducts) ? body.deleteProducts : [];
    const batchIds = Array.isArray(body.deleteBatches) ? body.deleteBatches : [];
    if (productIds.length > 500 || batchIds.length > 2000 || [...productIds, ...batchIds].some((id) => typeof id !== "string" || !/^[0-9a-f-]{36}$/i.test(id))) {
      return json({ error: "Lista de eliminaciones inválida." }, 400);
    }
    if (batchIds.length) {
      const { error } = await db.from("inventory_batches").delete().eq("workspace_id", workspaceId).in("id", batchIds);
      if (error) return json({ error: "No se pudieron eliminar los lotes." }, 500);
    }
    if (productIds.length) {
      const { error } = await db.from("products").delete().eq("workspace_id", workspaceId).in("id", productIds);
      if (error) return json({ error: "No se pudieron eliminar los productos." }, 500);
    }
    return json({ ok: true, workspaceId, deletedProducts: productIds.length, deletedBatches: batchIds.length });
  }

  const sessionToken = typeof body.sessionToken === "string" ? body.sessionToken : "";
  if (!await validSession(sessionToken, sessionSecret)) {
    return json({ error: "La sesión administrativa expiró. Ingresa la contraseña nuevamente." }, 401);
  }

  if (!url || !serviceKey) {
    const missing = [!url ? "SUPABASE_URL" : null, !serviceKey ? "SUPABASE_SERVICE_ROLE_KEY" : null].filter(Boolean);
    return json({ error: "La sesión es válida, pero faltan credenciales del servidor para consultar datos.", missing }, 500);
  }

  const supabase = createClient(url, serviceKey, { auth: { persistSession: false, autoRefreshToken: false } });
  if (body.action === "workspaces") {
    const { data, error } = await supabase.from("inventory_workspaces")
      .select("id,display_name,is_active").eq("is_active", true).order("display_name", { ascending: true });
    if (error) return json({ error: "No se pudieron consultar los inventarios." }, 500);
    return json(data ?? []);
  }
  if (body.action === "create-device-invite") {
    const workspaceId = typeof body.workspaceId === "string" ? body.workspaceId : "";
    if (!workspaceId || !/^[A-Z0-9_]{2,40}$/.test(workspaceId)) return json({ error: "Inventario inválido." }, 400);
    const { data: workspace, error: workspaceError } = await supabase.from("inventory_workspaces")
      .select("id,display_name").eq("id", workspaceId).eq("is_active", true).maybeSingle();
    if (workspaceError || !workspace) return json({ error: "El inventario no existe o está desactivado." }, 404);
    const bytes = crypto.getRandomValues(new Uint8Array(18));
    const code = Array.from(bytes, b => b.toString(16).padStart(2, "0")).join("").toUpperCase();
    const codeHash = Array.from(new Uint8Array(await crypto.subtle.digest("SHA-256", encoder.encode(code))), b => b.toString(16).padStart(2, "0")).join("");
    const expiresAt = new Date(Date.now() + 10 * 60 * 1000).toISOString();
    const { error } = await supabase.from("inventory_device_invites").insert({ code_hash: codeHash, workspace_id: workspaceId, expires_at: expiresAt });
    if (error) return json({ error: "No se pudo crear el código temporal. Ejecuta la migración multi-inventario." }, 500);
    return json({ ok: true, code, workspaceId, workspaceName: workspace.display_name, expiresAt, expiresInSeconds: 600 });
  }
  if (body.action === "device-bindings") {
    const { data, error } = await supabase.from("inventory_device_bindings")
      .select("device_hash,workspace_id,label,created_at,last_seen_at,revoked_at").order("created_at", { ascending: false });
    if (error) return json({ error: "No se pudieron consultar los dispositivos." }, 500);
    // Return the full hash to the authenticated admin UI: revoke-device needs the exact value.
    // The raw device identifier is never exposed; this is only its SHA-256 hash.
    return json(data ?? []);
  }
  if (body.action === "revoke-device") {
    const deviceHash = typeof body.deviceId === "string" ? body.deviceId : "";
    if (!/^[a-f0-9]{64}$/i.test(deviceHash)) return json({ error: "Identificador de dispositivo inválido." }, 400);
    const { error } = await supabase.from("inventory_device_bindings").update({ revoked_at: new Date().toISOString() }).eq("device_hash", deviceHash);
    if (error) return json({ error: "No se pudo revocar el dispositivo." }, 500);
    return json({ ok: true });
  }
  if (body.action === "bind-device") {
    const code = typeof body.code === "string" ? body.code.trim().toUpperCase() : "";
    const deviceId = typeof body.deviceId === "string" ? body.deviceId.trim() : "";
    const label = typeof body.label === "string" ? body.label.trim().slice(0, 80) : "";
    if (!/^[A-F0-9]{36}$/.test(code) || deviceId.length < 16 || deviceId.length > 256) return json({ error: "Código o identificador de dispositivo inválido." }, 400);
    const codeHash = Array.from(new Uint8Array(await crypto.subtle.digest("SHA-256", encoder.encode(code))), b => b.toString(16).padStart(2, "0")).join("");
    const deviceHash = Array.from(new Uint8Array(await crypto.subtle.digest("SHA-256", encoder.encode(deviceId))), b => b.toString(16).padStart(2, "0")).join("");
    const requestedWorkspace = typeof body.workspaceId === "string" ? body.workspaceId.trim() : "";
    if (!/^[A-Z0-9_]{2,40}$/.test(requestedWorkspace)) return json({ error: "Selecciona un inventario válido antes de vincular." }, 400);
    // Check the intended workspace before consuming the code, so a profile typo does not burn it.
    const { data: preview, error: previewError } = await supabase.from("inventory_device_invites")
      .select("workspace_id,expires_at,used_at").eq("code_hash", codeHash).maybeSingle();
    if (previewError) return json({ error: "No se pudo comprobar el código temporal." }, 500);
    if (!preview || preview.used_at || new Date(preview.expires_at).getTime() <= Date.now()) return json({ error: "El código no existe, ya fue usado o expiró." }, 401);
    if (preview.workspace_id !== requestedWorkspace) return json({ error: `Este código pertenece a ${preview.workspace_id}, no a ${requestedWorkspace}. No se consumió.` }, 409);
    // RPC atomically consumes a live invite; a concurrent second request receives no row.
    const { data: claimed, error: claimError } = await supabase.rpc("consume_inventory_device_invite", {
      p_code_hash: codeHash,
      p_device_hash: deviceHash,
    });
    const invite = Array.isArray(claimed) ? claimed[0] : null;
    if (claimError) return json({ error: "No se pudo validar el código. Verifica que la migración multi-inventario esté instalada." }, 500);
    if (!invite?.workspace_id) return json({ error: "El código no existe, ya fue usado o expiró." }, 401);
    if (invite.workspace_id !== requestedWorkspace) return json({ error: "El inventario del código no coincide con el perfil seleccionado." }, 409);
    const tokenBytes = crypto.getRandomValues(new Uint8Array(32));
    const deviceToken = Array.from(tokenBytes, b => b.toString(16).padStart(2, "0")).join("");
    const tokenHash = Array.from(new Uint8Array(await crypto.subtle.digest("SHA-256", encoder.encode(deviceToken))), b => b.toString(16).padStart(2, "0")).join("");
    const { error: bindError } = await supabase.from("inventory_device_bindings").upsert({ device_hash: deviceHash, token_hash: tokenHash, workspace_id: invite.workspace_id, label, last_seen_at: new Date().toISOString(), revoked_at: null });
    if (bindError) return json({ error: "El código se consumió, pero no se pudo guardar la vinculación. Genera otro código y vuelve a intentar." }, 500);
    // The raw token is returned once. Only its SHA-256 hash is persisted server-side.
    return json({ ok: true, workspaceId: invite.workspace_id, deviceToken });
  }
  if (body.action === "users") {
    const { data, error } = await supabase.from("profiles").select("id,full_name,role").order("full_name", { ascending: true });
    if (error) return json({ error: "No se pudieron consultar los usuarios." }, 500);
    return json(data ?? []);
  }
  if (body.action === "products") {
    const userId = typeof body.userId === "string" ? body.userId : "";
    if (!userId || userId.length > 100) return json({ error: "Usuario inválido." }, 400);
    const { data, error } = await supabase.from("products")
      .select("id,user_id,name,barcode,plu,quantity,expiry_date")
      .eq("user_id", userId).order("expiry_date", { ascending: true });
    if (error) return json({ error: "No se pudieron consultar los productos." }, 500);
    return json(data ?? []);
  }
  return json({ error: "Acción no permitida." }, 400);
});
