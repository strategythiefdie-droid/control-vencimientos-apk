# Implementación: productos padre-hijo y Mi pasillo

## Integración
- Base de datos Room incrementada de versión 5 a 6 con migración no destructiva `MIGRATION_5_6`.
- `product_relations` registra caja/unidad y equivalencia.
- `aisle_entries` conserva cantidad/estado por producto y, cuando se selecciona, por lote. Es independiente del total del inventario para evitar contabilizar dos veces el stock.
- La conversión descuenta de un lote y suma al lote destino dentro de una única transacción Room. Copia fecha de vencimiento y número de lote; no combina fechas distintas.
- Mi pasillo permite añadir productos existentes, ajustar cantidad, marcar agotado/reposición y retirar de la lista sin borrar el producto general.
- Se añadió workflow de GitHub Actions para compilar el APK debug y publicar el artefacto si la compilación termina correctamente.

## Limitaciones explícitas
- Las nuevas tablas `product_relations` y `aisle_entries` son locales en Room. La sincronización Supabase existente solo contempla productos, lotes y Macro; todavía no sincroniza estas dos tablas entre dispositivos.
- Mi pasillo registra un conteo físico independiente. No descuenta inventario general ni simula ventas/traslados.
- La interfaz y el código no han sido compilados ni ejecutados en dispositivo en este entorno porque el ZIP original no contiene `gradlew`/`gradle-wrapper.jar` y no hay instalación local de Gradle. El workflow `.github/workflows/android-build.yml` permite comprobar la compilación en GitHub Actions.

## Pruebas recomendadas tras compilar
1. Actualizar una instalación con base Room v5 y comprobar que conserva productos/lotes.
2. Crear relación caja/unidad y probar equivalencia válida e inválida.
3. Convertir desde un lote elegido; cancelar confirmación y verificar cantidades sin cambios.
4. Probar stock insuficiente y conversión inversa con cantidad que no sea múltiplo.
5. Confirmar que destino conserva la fecha y número de lote del origen.
6. Agregar, ajustar, agotar, retirar y volver a agregar un producto en Mi pasillo.
7. Cerrar y abrir app y comprobar persistencia.
8. Verificar que CEDI, Macro, TUSK, escáner, alertas y formularios existentes continúan funcionando.
