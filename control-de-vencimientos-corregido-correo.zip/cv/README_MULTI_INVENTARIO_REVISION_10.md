# Revisión 10 — códigos de vinculación y usuario de prueba

## Cambios de Android

- Se integró la interfaz de administración para generar códigos de vinculación para ACT 1–ACT 4.
- El código es de 36 caracteres hexadecimales, vence en 10 minutos y solo se puede consumir una vez.
- El administrador puede copiar o compartir el código mediante el menú de aplicaciones de Android.
- Se añadió la consulta de dispositivos vinculados y la revocación con confirmación.
- Se agregó el menú **Cambiar inventario / perfil**. El cambio no borra bases locales.
- Se agregó **Usuario de prueba**, con archivo Room independiente `control_vencimientos_test.db`; empieza vacío y funciona localmente.
- En Usuario de prueba no hay sincronización de Supabase ni envío real de correos manuales o automáticos.
- Se quitó el nombre del establecimiento y el número del almacén de la interfaz y de los encabezados de los informes; la aplicación muestra el nombre genérico Control de Vencimientos.

## SQL y servidor

1. En Supabase SQL Editor ejecuta `EJECUTAR_EN_SUPABASE_MULTIINVENTARIO.sql` (equivalente a `supabase_migration_multi_inventory.sql`). No ejecutes el SQL anterior que usaba `workspace_id` como columna del catálogo: el código real consulta `inventory_workspaces.id`.
2. Despliega `supabase/functions/admin-gateway/index.ts` como Edge Function `admin-gateway`.
3. Configura en los secrets de la Edge Function `ADMIN_PASSWORD`, `ADMIN_SESSION_SECRET` (mínimo 32 caracteres), `SUPABASE_URL` y `SUPABASE_SERVICE_ROLE_KEY`. La clave service role debe quedarse en el servidor, nunca en el APK.
4. Inicia sesión online en el área Administrador. Para generar el código, elige ACT 1–ACT 4 y pulsa **Generar código**. Después pulsa **Compartir** o **Copiar código**.
5. En el segundo dispositivo, selecciona exactamente el mismo perfil e introduce el código antes de que caduque.

## Usuario de prueba

No requiere SQL, registro de Auth ni código de administrador. Es una sandbox local: permite probar funciones con datos ficticios que introduzcas, pero esos datos permanecen en ese archivo de prueba y no se sincronizan a Supabase. No crea muestras automáticamente, por lo que abre inicialmente vacía.

## Verificación

Esta revisión se basa en el código fuente del ZIP proporcionado. No he podido compilarla contra Android SDK/Gradle ni desplegar la migración o Edge Function en tu proyecto Supabase desde este entorno. Antes de sustituir tu versión instalada, abre el proyecto en Android Studio, sincroniza Gradle y compila. No borres los datos de la aplicación instalada: la base legacy `control_vencimientos.db` se conserva.
