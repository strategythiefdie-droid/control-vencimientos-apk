# Corrección del envío manual de alertas

## Qué se corrigió

- Antes del envío manual o automático, Android sincroniza los productos y lotes del perfil activo con Supabase. Apps Script consulta Supabase, por lo que enviar una copia del inventario en el cuerpo HTTP no sustituye la sincronización.
- El botón manual mantiene `action: "sendAlert"` y `manual: true`, para que Apps Script identifique el origen `APP_MANUAL`.
- El trabajador automático usa `action: "sync"` y `manual: false`, para que el servidor lo identifique como `APP_SYNC`.
- La aplicación interpreta la respuesta real del servidor dentro de `counts`: `emails_accepted`, `email_failures`, `general_candidates`, `special_candidates`, `duplicates` y `events_sent`. También conserva compatibilidad con el formato antiguo `sent`/`count`.
- Si el HTTP es 200 pero el cuerpo no es JSON, se muestra que el envío no está confirmado; ya no se afirma que la solicitud se procesó correctamente.
- Se muestra un mensaje específico si Apps Script omite la solicitud por el cooldown de 60 segundos.
- Se retiró del trabajador automático la llamada al endpoint no compatible `sendEmergencyExpiry8Days`, que podía detener el chequeo normal de correo cuando detectaba un lote exactamente a 8 días. La alerta especial configurada en Apps Script sigue siendo responsabilidad del servidor y la notificación local Android continúa por separado.

## Qué debe hacer el usuario

1. Reemplazar en GitHub los archivos del proyecto por esta versión.
2. Esperar a que termine el workflow **Android build**.
3. Descargar el artefacto `Control-de-Vencimientos-debug` e instalar el APK generado.
4. Pulsar el botón manual y leer el mensaje: ahora distinguirá sincronización fallida, solicitud omitida, falta de lotes candidatos, alertas ya registradas, correos aceptados y errores de envío.

## Límites de esta actualización

- No modifica el Google Apps Script ni despliega una nueva versión de `Code.gs`.
- “Google aceptó el correo” significa que `MailApp` aceptó la solicitud; no constituye confirmación de entrega en la bandeja del destinatario.
- Si el servidor informa `duplicates` y cero `emails_accepted`, el lote ya tiene un evento registrado y no se reenvía automáticamente. No se borra el historial para forzar duplicados.
- El ZIP recibido no incluye `gradlew` ni `gradle-wrapper.jar`; por tanto, no fue posible compilar el APK en este entorno. El workflow de GitHub Actions usa Gradle instalado en el runner y puede realizar esa compilación.
