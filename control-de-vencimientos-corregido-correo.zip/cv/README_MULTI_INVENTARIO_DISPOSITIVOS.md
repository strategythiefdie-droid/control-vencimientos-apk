# Multiinventario y vinculación de dispositivos — fase de servidor

Esta carpeta añade la base de servidor para los perfiles `TUSK`, `TUSK ACT 1`, `TUSK ACT 2`, `TUSK ACT 3` y `TUSK ACT 4`, y las acciones administrativas de creación de códigos temporales.

## Importante: no instalar como actualización terminada todavía

Esta entrega **no termina la integración de Android**. La pantalla de selección al abrir, el almacenamiento local separado por perfil, el almacenamiento seguro del token de dispositivo, la validación del vínculo en cada sincronización y la interfaz para crear/revocar vínculos deben conectarse antes de usarlo con inventarios reales. La función de servidor se amplió, pero no se ha desplegado en tu proyecto ni se ha compilado/probado en un dispositivo. El `deviceToken` todavía no autoriza sincronizaciones; no se debe usar como control de acceso hasta completar la validación en cada petición.

## Qué incluye

- `supabase_migration_multi_inventory.sql`: crea el catálogo de inventarios, códigos temporales y vínculos de dispositivos; añade `workspace_id` a las tablas cloud conservando las filas antiguas bajo `TUSK`.
- `supabase/functions/admin-gateway/index.ts`: acciones administrativas `workspaces`, `create-device-invite`, `device-bindings`, `revoke-device` y `bind-device`, protegidas por la sesión administrativa existente. El consumo del código ahora usa una función SQL atómica para impedir que dos solicitudes simultáneas reclamen el mismo código.

## Aplicación segura

1. Haz copia de seguridad antes de ejecutar SQL.
2. Ejecuta la migración en Supabase SQL Editor.
3. Despliega la función `admin-gateway` desde este proyecto.
4. No distribuyas este ZIP como APK final hasta terminar la integración del cliente.

Los códigos temporales duran 10 minutos. No compartir `ADMIN_SESSION_SECRET` ni la clave service-role.
