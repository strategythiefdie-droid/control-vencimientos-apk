# Supabase apps1 — integración TUSK

## Funciones de esta versión

- El usuario operativo predeterminado es **TUSK**, sin contraseña.
- Los productos y lotes siguen guardándose en Room, por lo que se pueden consultar y editar sin internet.
- La aplicación intenta sincronizar productos y lotes al abrirse y después de cambios locales. También ofrece **Sincronizar inventario** en el menú superior.
- Las eliminaciones de productos y lotes se conservan como pendientes en el dispositivo hasta que se pueden enviar a Supabase.
- Código de barras y PLU son opcionales por separado: se permite guardar con uno, ambos o ninguno.
- CEDI y Macro requieren iniciar sesión con solo la contraseña; la app usa internamente la cuenta Gerencia670@grupo-exito.com; el servidor valida que `profiles.role = 'admin'`. Al cerrar el modo administrador se borra la sesión de la memoria de la app y se cierran los modales restringidos.
- La contraseña local compartida `TRACEON` fue retirada del flujo de acceso administrativo.

## Configuración obligatoria de Supabase

1. En **Authentication → Sign In / Providers** (el nombre puede variar), activa **Anonymous Sign-Ins**. Si está desactivado, el inventario seguirá funcionando localmente, pero la sincronización mostrará un error.
2. Ejecuta `supabase_migration_tusk_sync.sql` en **SQL Editor**. La migración añade `workspace_id = 'TUSK'` sin borrar filas y configura las políticas RLS para el inventario compartido.
3. El espacio TUSK es compartido intencionalmente entre instalaciones sin contraseña. Por eso los datos del inventario no son privados frente a otros clientes que puedan autenticarse en este mismo proyecto Supabase. Si necesitas que cada persona tenga un inventario privado, debe usarse una cuenta individual.

## Qué se sincroniza y qué falta

- **Productos y lotes:** sincronización automática y manual con Supabase.
- **Macro:** se mantiene local. La política de servidor solo permite su acceso a una cuenta Supabase con `profiles.role = 'admin'`. La contraseña local del APK no es una identidad de Supabase; para sincronizar Macro hace falta conectar una sesión real de administrador.
- **CEDI:** no tiene una tabla cloud independiente en esta integración. Los productos/lotes resultantes de las entradas CEDI se sincronizan como inventario normal.
- Si dos dispositivos editan el mismo producto a la vez, no existe todavía un resolvedor avanzado de conflictos; para IDs existentes se prioriza el registro local.

## Verificación y límites

No pude ejecutar una compilación Android aquí porque el ZIP no incluye el ejecutable/archivos completos del Gradle Wrapper y el entorno no tiene Android SDK configurado. Abre el proyecto en Android Studio, deja que Gradle se configure y compila antes de instalarlo. La conexión real debe probarse con Anonymous Sign-Ins activado y la migración ejecutada.

La clave incluida es una publishable key, no una `service_role` key. La protección de datos depende de RLS. La app ya no acepta una contraseña local compartida para habilitar administración. El acceso requiere Supabase Auth y el rol `admin`; la protección final sigue dependiendo de las políticas RLS.


### Acceso de administrador con solo contraseña
La pantalla de acceso solicita únicamente la contraseña. Internamente, Supabase Auth usa `Gerencia670@grupo-exito.com` como cuenta fija y sigue verificando `profiles.role = admin`. Si la cuenta de administrador de Supabase tiene otro correo, cambia `ADMIN_AUTH_EMAIL` en `SupabaseAdminRepository.kt` para que coincida. Esto oculta el campo de correo, pero no reemplaza la autenticación ni las políticas RLS del servidor.
