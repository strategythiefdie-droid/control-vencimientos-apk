# Supabase apps1 — integración TUSK

## Funciones de esta versión

- El acceso a la interfaz del inventario **TUSK** solicita `TRACEON`, una contraseña local codificada en la app. La validación ocurre en Android y no genera ni valida una sesión de Supabase.
- Los productos y lotes siguen guardándose en Room, por lo que se pueden consultar y editar sin internet.
- La aplicación inicializa el inventario local antes de iniciar la primera sincronización. Después sincroniza los cambios locales y ofrece **Sincronizar inventario** en el menú superior; las cancelaciones de tareas del ciclo de vida ya no se presentan como errores de conexión.
- Las eliminaciones de productos y lotes se conservan como pendientes en el dispositivo hasta que se pueden enviar a Supabase.
- Código de barras y PLU son opcionales por separado: se permite guardar con uno, ambos o ninguno.
- CEDI y Macro requieren iniciar sesión con solo la contraseña; la app usa internamente la cuenta Gerencia670@grupo-exito.com; el servidor valida que `profiles.role = 'admin'`. Al cerrar el modo administrador se borra la sesión de la memoria de la app y se cierran los modales restringidos.
- `TRACEON` se usa únicamente como contraseña local de entrada a TUSK en esta versión. La autenticación administrativa permanece separada y no se modifica.

## Configuración obligatoria de Supabase

1. En **Authentication → Sign In / Providers** (el nombre puede variar), activa **Anonymous Sign-Ins**. Si está desactivado, el inventario seguirá funcionando localmente, pero la sincronización mostrará un error.
2. Ejecuta `supabase_migration_tusk_sync.sql` en **SQL Editor**. La migración añade `workspace_id = 'TUSK'` sin borrar filas y configura las políticas RLS para el inventario compartido.
3. Ejecuta `supabase_migration_product_location.sql` en **SQL Editor** para añadir la columna `location` sin borrar productos. También se incorporó a los scripts de instalación para instalaciones nuevas.
4. Ejecuta `supabase_migration_product_returns.sql` en **SQL Editor**. Añade los campos `has_return` y `return_updated_at` sin eliminar productos ni lotes.
5. Para sincronizar Lugar y devolución en ACT 1–ACT 4 y ver la marca de devolución desde el panel de administrador, vuelve a desplegar la Edge Function `admin-gateway` con el archivo actualizado `supabase/functions/admin-gateway/index.ts`.
6. El espacio TUSK es compartido intencionalmente entre instalaciones. La contraseña `TRACEON` solo bloquea la interfaz local: no constituye autenticación remota ni limita por sí misma el acceso a `workspace_id = TUSK`. Las políticas RLS actuales permiten que clientes autenticados del proyecto accedan al espacio compartido según las políticas instaladas. Si necesitas privacidad real por dispositivo o persona, se requiere autorización en servidor y políticas RLS adicionales; esta entrega no las modifica.

## Qué se sincroniza y qué falta

- **Productos y lotes:** sincronización automática y manual con Supabase.
- **Lugar del producto:** se guarda en Room y también se sincroniza con Supabase; sirve para registrar caja, estante, pasillo o ubicación física.
- **Devolución:** se sincroniza entre dispositivos. Los productos marcados con devolución permanecen en Inventario y Mi pasillo, pero se excluyen del selector y de la importación CSV de Macro; al marcar un producto, sus registros existentes se retiran de Macro.
- **Macro:** se mantiene local. La política de servidor solo permite su acceso a una cuenta Supabase con `profiles.role = 'admin'`. La contraseña local del APK no es una identidad de Supabase; para sincronizar Macro hace falta conectar una sesión real de administrador.
- **CEDI:** no tiene una tabla cloud independiente en esta integración. Los productos/lotes resultantes de las entradas CEDI se sincronizan como inventario normal.
- Si dos dispositivos editan el mismo producto a la vez, no existe todavía un resolvedor avanzado de conflictos; para IDs existentes se prioriza el registro local.

## Verificación y límites

No pude ejecutar una compilación Android aquí porque el ZIP no incluye el ejecutable/archivos completos del Gradle Wrapper y el entorno no tiene Android SDK configurado. Abre el proyecto en Android Studio, deja que Gradle se configure y compila antes de instalarlo. La conexión real debe probarse con Anonymous Sign-Ins activado y la migración ejecutada.

La clave incluida es una publishable key, no una `service_role` key. La protección de datos depende de RLS. La app usa `TRACEON` como puerta local del inventario TUSK; no habilita administración ni reemplaza Supabase Auth. El acceso requiere Supabase Auth y el rol `admin`; la protección final sigue dependiendo de las políticas RLS.


### Acceso de administrador con solo contraseña
La pantalla de acceso solicita únicamente la contraseña. Internamente, Supabase Auth usa `Gerencia670@grupo-exito.com` como cuenta fija y sigue verificando `profiles.role = admin`. Si la cuenta de administrador de Supabase tiene otro correo, cambia `ADMIN_AUTH_EMAIL` en `SupabaseAdminRepository.kt` para que coincida. Esto oculta el campo de correo, pero no reemplaza la autenticación ni las políticas RLS del servidor.
