# Actualización de diagnóstico de admin-gateway

Esta versión agrega un registro seguro de presencia de variables y separa el inicio de sesión de las consultas a la base de datos. **No registra valores secretos.**

## Qué cambia

- `admin-gateway config check` registra solo `true`/`false` y si `ADMIN_SESSION_SECRET` alcanza 32 caracteres.
- El inicio de sesión con contraseña requiere `ADMIN_PASSWORD` y `ADMIN_SESSION_SECRET`; ya no falla solo porque falte la clave de base de datos.
- Las acciones `users` y `products` sí requieren `SUPABASE_URL` y `SUPABASE_SERVICE_ROLE_KEY`; si faltan, la respuesta indica los nombres que faltan, sin revelar sus valores.
- No cambia la entrada normal TUSK ni la regla de acceso administrativo a CEDI/Macro.

## Publicación

1. En Supabase abre **Edge Functions → admin-gateway**.
2. Reemplaza todo el contenido de `index.ts` por `supabase/functions/admin-gateway/index.ts` incluido en este ZIP.
3. Publica con **Deploy updates**. Mantén **Verify JWT desactivado** para esta función, como indica `supabase/config.toml`.
4. Prueba el inicio administrativo una vez y abre los logs. Busca `admin-gateway config check`.
5. Si una variable aparece `false`, corrige el secreto/entorno correspondiente en Supabase y vuelve a probar.

**No compartas** el valor de ninguna clave. Comparte únicamente los indicadores `true`/`false` o el texto de error sin valores secretos.

Este ZIP contiene el código actualizado, pero no es una APK compilada ni una prueba de ejecución real en Supabase.
