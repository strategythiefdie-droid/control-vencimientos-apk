MEJORAS: MODO RÁFAGA Y MODO SENCILLO

1. Modo ráfaga
- El mismo código detectado continuamente delante de la cámara se registra una sola vez.
- Para volver a contar ese código, debe salir del visor brevemente y volver a entrar.
- Se mantiene el conteo de unidades mediante el control manual +/−.
- Se envía feedback de vibración al detectar un código nuevo.

2. Modo sencillo por defecto
- En una instalación nueva, la aplicación abre en modo sencillo.
- La preferencia se guarda en app_preferences y se conserva al cerrar/reabrir la app.
- El usuario puede cambiar a vista completa desde el control existente; la elección queda guardada.

VALIDACIÓN
- El ZIP debe comprobarse con unzip -t.
- No se afirma compilación de Android: no se ejecutó Gradle/Android build en este entorno.
