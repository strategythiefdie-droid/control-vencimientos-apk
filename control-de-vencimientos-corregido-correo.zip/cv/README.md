<div align="center">
<img width="1200" height="475" alt="GHBanner" src="https://ai.google.dev/static/site-assets/images/share-ais-513315318.png" />
</div>

# Run and deploy your AI Studio app

This contains everything you need to run your app locally.

View your app in AI Studio: https://ai.studio/apps/36f774b1-4bc5-4b80-9105-e641f9c9a254

## Run Locally

**Prerequisites:**  [Android Studio](https://developer.android.com/studio)


1. Open Android Studio
2. Select **Open** and choose the directory containing this project
3. Allow Android Studio to fix any incompatibilities as it imports the project.
4. Create a file named `.env` in the project directory and set `GEMINI_API_KEY` in that file to your Gemini API key (see `.env.example` for an example)
5. Remove this line from the app's `build.gradle.kts` file: `signingConfig = signingConfigs.getByName("debugConfig")`
6. Run the app on an emulator or physical device
7. If you have already published your app in AI Studio, please [request upload key reset](https://support.google.com/googleplay/android-developer/answer/9842756#zippy=%2Crequest-an-upload-key-reset) in Google Play Console.

## Panel de inventarios en la nube (administrador)

La vista Administrador solicita únicamente la contraseña. La verifica una Supabase Edge Function y después usa un token firmado de corta duración (15 minutos) para consultar en modo de solo lectura las cuentas de `public.profiles` y los registros de `public.products`. No se solicita ni se utiliza un correo para este acceso, y no se usa `TRACEON` como autorización.

Importante: esta función muestra los inventarios que ya estén guardados en Supabase. Los productos creados únicamente en la base local Room de un dispositivo todavía no se sincronizan automáticamente con la nube; para que también aparezcan aquí, el flujo de usuario normal de Android debe autenticarse y sincronizar sus altas/cambios con `public.products`. No se debe interpretar una consulta vacía como prueba de que el inventario local de otro teléfono está vacío.

La consulta depende de las políticas RLS existentes: los usuarios deben poder leer su propio perfil/inventario y el rol `admin` debe tener permiso de lectura sobre los perfiles y productos supervisados. No se incluye ninguna `service_role` key en la app.


### Acceso TUSK / administrador

El uso normal aparece como TUSK y no pide contraseña. CEDI y Macro requieren iniciar sesión con solo la contraseña de administrador y el servidor debe confirmar `profiles.role = 'admin'`. Ya no se utiliza `TRACEON` como contraseña de administrador. Consulta `README_SUPABASE_APPS1.md` para los requisitos de configuración de Supabase.


## Mejora del modo ráfaga: confirmar cantidad

En el modo ráfaga, cada código detectado pausa temporalmente la cámara y muestra un campo para confirmar cuántas unidades se van a registrar. La cantidad inicial es 1; se puede editar antes de agregar. Si el producto ya aparece en la sesión, la cantidad confirmada se suma a la cantidad acumulada, sin crear una fila duplicada para el mismo código. La fecha de vencimiento seleccionada para la sesión se mantiene y se aplica al lote guardado.

## Mejoras adicionales del modo ráfaga

- Cada fila de conteo mantiene su propia fecha de vencimiento; el mismo producto puede registrarse en lotes distintos si vence en fechas diferentes.
- En la confirmación se puede corregir el nombre, la cantidad y la fecha. También se puede editar el nombre y la fecha desde la lista de la sesión.
- Los códigos nuevos pueden recibir un nombre manual y se muestran coincidencias de productos existentes para asociar la lectura a un producto ya registrado.
- El modo alternativo rápido suma una unidad por lectura; el modo de confirmación sigue siendo el predeterminado.
- Hay feedback háptico y sonoro al detectar/confirmar y una acción para deshacer la última suma.
- La sesión de conteo se guarda localmente y se restaura si se cierra la ventana o se interrumpe la app antes de guardar. Tras guardar correctamente, se limpia la sesión temporal.

## Protección de datos y límites de verificación

- La base Room ya no usa `fallbackToDestructiveMigration()`: una versión de esquema no contemplada no debe borrar automáticamente el inventario. Si una instalación antigua no tiene una migración compatible, la app puede requerir una migración explícita; haz una copia de seguridad antes de actualizar.
- El acceso administrativo de esta versión utiliza Supabase Auth con correo y contraseña y comprueba el rol `admin` en `public.profiles` antes de habilitar CEDI/Macro. La seguridad final depende de configurar correctamente RLS en Supabase; la validación visual de la app no sustituye las políticas del servidor.
- La revisión estática y la integridad del ZIP no equivalen a compilar ni probar la app en un teléfono. En este entorno no hay `gradle` instalado ni el archivo `gradle-wrapper.jar`, por lo que la compilación Android no se puede confirmar todavía.
- La copia de seguridad automática del sistema Android está desactivada para proteger los datos locales; usa la opción de copia/restauración manual de la app cuando necesites transferir o resguardar inventario.


## Mi Pasillo actualizado (versión 1.5)

Consulta `README_MI_PASILLO_LOCALIZADOR_v1.5.md` para configurar ubicaciones por pasillo, estante, nivel y caja, utilizar el localizador y preparar listas de recolección.
