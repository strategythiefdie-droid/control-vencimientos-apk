-- Migración para que el inventario normal pertenezca al espacio compartido TUSK.
-- Ejecutar en Supabase > SQL Editor. No elimina filas ni datos.

-- Un único espacio compartido permite que TUSK funcione sin contraseña en varios dispositivos.
alter table public.products add column if not exists workspace_id text not null default 'TUSK';
alter table public.products alter column expiry_date drop not null;
alter table public.inventory_batches add column if not exists workspace_id text not null default 'TUSK';
alter table public.macro_records add column if not exists workspace_id text not null default 'TUSK';

alter table public.products enable row level security;
alter table public.inventory_batches enable row level security;
alter table public.macro_records enable row level security;

-- Inventario normal: todos los clientes autenticados anónimamente de la app comparten TUSK.
-- Esto es deliberado para cumplir el acceso sin contraseña, pero significa que el inventario TUSK
-- no es privado frente a otros clientes que puedan autenticarse con el proyecto.
drop policy if exists "Users can read own products" on public.products;
drop policy if exists "Users can insert own products" on public.products;
drop policy if exists "Users can update own products" on public.products;
drop policy if exists "Users can delete own products" on public.products;
drop policy if exists "TUSK workspace read products" on public.products;
drop policy if exists "TUSK workspace insert products" on public.products;
drop policy if exists "TUSK workspace update products" on public.products;
drop policy if exists "TUSK workspace delete products" on public.products;
create policy "TUSK workspace read products" on public.products for select to authenticated using (workspace_id = 'TUSK');
create policy "TUSK workspace insert products" on public.products for insert to authenticated with check (workspace_id = 'TUSK');
create policy "TUSK workspace update products" on public.products for update to authenticated using (workspace_id = 'TUSK') with check (workspace_id = 'TUSK');
create policy "TUSK workspace delete products" on public.products for delete to authenticated using (workspace_id = 'TUSK');

-- Lotes: mismo espacio compartido que el catálogo.
drop policy if exists "Users can read own batches" on public.inventory_batches;
drop policy if exists "Users can insert own batches" on public.inventory_batches;
drop policy if exists "Users can update own batches" on public.inventory_batches;
drop policy if exists "Users can delete own batches" on public.inventory_batches;
drop policy if exists "TUSK workspace read batches" on public.inventory_batches;
drop policy if exists "TUSK workspace insert batches" on public.inventory_batches;
drop policy if exists "TUSK workspace update batches" on public.inventory_batches;
drop policy if exists "TUSK workspace delete batches" on public.inventory_batches;
create policy "TUSK workspace read batches" on public.inventory_batches for select to authenticated using (workspace_id = 'TUSK');
create policy "TUSK workspace insert batches" on public.inventory_batches for insert to authenticated with check (workspace_id = 'TUSK');
create policy "TUSK workspace update batches" on public.inventory_batches for update to authenticated using (workspace_id = 'TUSK') with check (workspace_id = 'TUSK');
create policy "TUSK workspace delete batches" on public.inventory_batches for delete to authenticated using (workspace_id = 'TUSK');

-- Macro sí queda protegido por rol de administrador de Supabase, no por la contraseña local del APK.
drop policy if exists "Users can read own macro records" on public.macro_records;
drop policy if exists "Users can insert own macro records" on public.macro_records;
drop policy if exists "Users can update own macro records" on public.macro_records;
drop policy if exists "Users can delete own macro records" on public.macro_records;
drop policy if exists "Admins can read macro records" on public.macro_records;
drop policy if exists "Admins can insert macro records" on public.macro_records;
drop policy if exists "Admins can update macro records" on public.macro_records;
drop policy if exists "Admins can delete macro records" on public.macro_records;
create policy "Admins can read macro records" on public.macro_records for select to authenticated using (exists (select 1 from public.profiles p where p.id = auth.uid() and lower(coalesce(p.role, 'user')) = 'admin'));
create policy "Admins can insert macro records" on public.macro_records for insert to authenticated with check (exists (select 1 from public.profiles p where p.id = auth.uid() and lower(coalesce(p.role, 'user')) = 'admin'));
create policy "Admins can update macro records" on public.macro_records for update to authenticated using (exists (select 1 from public.profiles p where p.id = auth.uid() and lower(coalesce(p.role, 'user')) = 'admin')) with check (exists (select 1 from public.profiles p where p.id = auth.uid() and lower(coalesce(p.role, 'user')) = 'admin'));
create policy "Admins can delete macro records" on public.macro_records for delete to authenticated using (exists (select 1 from public.profiles p where p.id = auth.uid() and lower(coalesce(p.role, 'user')) = 'admin'));

-- La contraseña local de administrador no se utiliza como credencial del servidor.
-- No se añade ninguna service_role key a la aplicación.
