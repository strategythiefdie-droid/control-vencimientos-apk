# Revisión 3 — autorización de dispositivos

Esta revisión añade el almacenamiento de un hash de token por dispositivo y una acción `authorize-device` en `supabase/functions/admin-gateway/index.ts`.

## Qué hace
- Al vincular un dispositivo, el servidor genera un token aleatorio de 256 bits. La respuesta lo entrega una sola vez y Supabase almacena solo SHA-256 del token.
- `authorize-device` recibe `deviceId`, `deviceToken` y `workspaceId`; verifica el hash del dispositivo, el token, el inventario activo y que el vínculo no esté revocado.
- Actualiza `last_seen_at` solo si la autorización sigue vigente.
- La migración añade `token_hash` sin borrar las vinculaciones existentes. Los vínculos antiguos quedan sin token y deben volver a vincularse para autorizarse.

## Despliegue seguro
1. Haz copia de seguridad de Supabase.
2. Revisa y ejecuta `supabase_migration_multi_inventory.sql` en un entorno de prueba primero.
3. Despliega la Edge Function `admin-gateway` y configura los secretos requeridos.
4. Prueba con un dispositivo de prueba: vincular, autorizar, revocar y confirmar que la autorización posterior devuelve 401.

## Limitación importante
Esta acción del servidor es una comprobación de autorización, **pero la sincronización Android todavía no la llama antes de cada operación ni envía las escrituras de todos los perfiles a través de un endpoint de sincronización protegido**. La app actual mantiene la sincronización cloud desactivada para perfiles distintos de TUSK. No habilites la sincronización multiinventario hasta completar esa integración; de lo contrario, una llamada directa a REST podría eludir esta comprobación.

No se ha compilado ni desplegado esta revisión desde este entorno.
