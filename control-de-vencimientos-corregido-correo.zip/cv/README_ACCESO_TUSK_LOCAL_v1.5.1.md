# Actualización 1.5.1 — Contraseña local para TUSK

## Comportamiento

- TUSK solicita la contraseña local fija `TRACEON` al seleccionarlo.
- Si TUSK ya era el inventario activo, la solicita nuevamente al abrir la aplicación en un nuevo inicio en frío.
- La contraseña se verifica con `LocalTuskAccess` dentro de Android; no se transmite ni se consulta en Supabase.
- Tras desbloquear TUSK, el perfil permanece activo durante esa sesión de la aplicación.
- ACT 1–ACT 4 conservan exactamente su flujo de códigos temporales de vinculación.
- TESTER conserva su funcionamiento local independiente.
- El administrador conserva el mecanismo de autenticación existente.

## No se modifica

- `SupabaseSyncRepository` y la autenticación anónima/sesión TUSK existente.
- `DeviceAuthorizationRepository` y la autorización de ACT.
- Edge Functions, tablas, columnas, RLS o migraciones SQL.
- Bases Room, sus nombres ni su esquema.
- Macro, CEDI, inventarios, lotes, ubicaciones, devoluciones o Mi Pasillo.

## Instalación

No requiere migración SQL ni despliegue de Edge Functions. Es una actualización de APK (versionName `1.5.1`, versionCode `7`).

## Limitación de seguridad

`TRACEON` está codificado en la APK y puede recuperarse mediante ingeniería inversa. Esta contraseña es una puerta local de interfaz, no una medida de autorización fuerte para el backend. La seguridad de los datos remotos continúa dependiendo de Supabase Auth y RLS.
