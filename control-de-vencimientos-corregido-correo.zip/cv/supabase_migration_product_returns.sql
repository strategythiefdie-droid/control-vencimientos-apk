-- Migración aditiva para marcar productos con devolución y excluirlos de Macro.
-- Ejecutar en Supabase > SQL Editor. No elimina ni reemplaza datos existentes.

alter table public.products
  add column if not exists has_return boolean not null default false;

alter table public.products
  add column if not exists return_updated_at bigint not null default 0;
