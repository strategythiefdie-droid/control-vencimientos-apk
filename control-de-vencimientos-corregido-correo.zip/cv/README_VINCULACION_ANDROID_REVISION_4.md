# Revisión 4 — vinculación Android y comprobación de autorización

## Qué incorpora

- La pantalla inicial permite introducir el código de vinculación al elegir TUSK ACT 1–ACT 4.
- Android reclama el código mediante `admin-gateway` y guarda la credencial devuelta cifrada con AES-GCM usando una clave de Android Keystore.
- Antes de cualquier intento de sincronización de un perfil secundario, Android consulta `authorize-device`. Si el servidor revoca el dispositivo, cambia el inventario asociado o no puede validar la credencial, la sincronización se detiene.
- El endpoint verifica que el código corresponda al perfil elegido antes de consumirlo, para evitar gastar códigos por un error de selección.
- TUSK mantiene su flujo de sincronización anterior y el archivo de base de datos local existente.

## Preparación requerida en Supabase

1. Ejecutar primero en un entorno de pruebas `supabase_migration_multi_inventory.sql` y revisar que las tablas, políticas RLS y la función RPC estén creadas correctamente.
2. Desplegar la función `admin-gateway` desde este proyecto.
3. Configurar los secretos del servidor requeridos por la función (`SUPABASE_URL`, `SUPABASE_SERVICE_ROLE_KEY`, `ADMIN_PASSWORD` y `ADMIN_SESSION_SECRET`, según la configuración del proyecto).
4. Desde la interfaz administrativa, generar un código para el inventario exacto que se va a vincular. El código expira a los 10 minutos y solo puede reclamarse una vez.
5. En Android, seleccionar el perfil correspondiente e introducir el código generado para ese mismo inventario.

## Limitación deliberada: datos en la nube

Esta revisión **no habilita todavía la sincronización de productos para TUSK ACT 1–ACT 4**. La comprobación de autorización ya está conectada al intento de sincronización, pero el cliente falla de forma cerrada después de validar porque aún falta desplegar y auditar un endpoint de datos multiinventario con autorización obligatoria por petición y aislamiento por `workspace_id`. No debe usarse el endpoint antiguo de TUSK para enviar datos de otros perfiles.

## Pruebas pendientes antes de producción

- Compilar en Android Studio con el Gradle wrapper/proyecto completo.
- Probar código correcto, vencido, usado y de otro inventario.
- Revocar un dispositivo desde administración y confirmar que la siguiente comprobación falla.
- Probar reinstalación, pérdida de datos de la aplicación y cambio de dispositivo.
- Verificar RLS y que una credencial de un perfil no pueda consultar ni escribir en otro perfil.
- Hacer copia de seguridad antes de cualquier migración productiva.

No se ha desplegado Supabase ni se ha afirmado que el proyecto haya compilado o pasado pruebas en dispositivo.
