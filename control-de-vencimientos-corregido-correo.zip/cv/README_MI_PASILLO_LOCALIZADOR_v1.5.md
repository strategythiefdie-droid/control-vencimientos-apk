# Mi Pasillo: localizador y lista de recolección — versión 1.5

## Qué cambió

Mi Pasillo ahora tiene dos vistas independientes:

1. **Localizador:** busca cualquier producto del inventario activo, aunque todavía no esté agregado al control de cantidades del pasillo.
2. **Control del pasillo:** conserva el control anterior de cantidad física, reposición y agotados. Los registros ya existentes no se eliminan ni se convierten.

## Ubicación por niveles

Desde el botón **Editar** de cada producto se puede registrar:

- Pasillo
- Estante
- Nivel
- Caja
- Otra referencia opcional

Ejemplo guardado en el campo existente `products.location`:

`Pasillo: 2 · Estante: B · Nivel: 3 · Caja: 04`

Se reutiliza el campo de ubicación de la versión 1.4 y se añade una marca de tiempo de edición para resolver cambios entre dispositivos. Las ubicaciones existentes en texto libre se conservan como referencia al abrir el editor y se pueden completar con los nuevos niveles.

## Búsqueda

El buscador acepta nombre, PLU, código de barras y ubicación. Hay filtros para mostrar todos los productos, los que ya tienen ubicación o los que todavía no la tienen.

## Lista de recolección

1. Marca varios productos en el Localizador.
2. Pulsa **Lista de recolección**.
3. La aplicación ordena los productos por pasillo, estante, nivel y caja. Los que no tienen ubicación quedan al final.
4. Marca cada producto conforme lo recoges y consulta el avance de la lista.

El orden es una lista de trabajo por ubicación; no es navegación GPS ni un plano interno del establecimiento.

## Sincronización y migración necesaria

La ubicación se guarda en Room y en Supabase. Cada edición registra `locationUpdatedAt` / `location_updated_at`; la sincronización compara esa marca para que un dispositivo con datos antiguos no vuelva a sobrescribir la ubicación más reciente. También permite propagar una ubicación vacía cuando se elimina intencionalmente.

Antes de usar la sincronización de la versión 1.5, ejecuta `supabase_migration_product_location_sync.sql` en Supabase → SQL Editor y vuelve a desplegar `supabase/functions/admin-gateway/index.ts` para los perfiles ACT. La migración es aditiva y usa `ADD COLUMN IF NOT EXISTS`; no elimina productos ni lotes. No necesitas volver a ejecutar las migraciones de devolución ni recrear los inventarios.

## Versión

- `versionName`: `1.5`
- `versionCode`: `6`
- Room migra de la versión 8 a la 9 con una columna de marca de tiempo.
- Supabase necesita la migración aditiva `supabase_migration_product_location_sync.sql`.
