# Revisión 9 — preparación de pruebas de sincronización multiinventario

## Cambios de esta revisión

1. `AppDatabase.getInstance()` ahora identifica qué perfil abrió la instancia Room. Si el perfil cambia dentro del mismo proceso, cierra la instancia anterior y abre el archivo correspondiente al nuevo perfil; no elimina archivos ni datos.
2. La migración multiinventario permite `user_id = NULL` en `products` e `inventory_batches` para filas de ACT 1–ACT 4. Esto evita que el endpoint tenga que asignar falsamente esas filas a una cuenta de Supabase Auth. Los datos TUSK existentes mantienen su `user_id`.
3. Las filas sin `user_id` deben seguir gestionándose únicamente a través de `admin-gateway` con service role. No se debe añadir una política RLS que permita a clientes anon/authenticated leerlas o modificarlas directamente.

## Pruebas obligatorias en un proyecto Supabase de pruebas

1. Haz una copia de seguridad y aplica primero las migraciones base `supabase_migration_apps1.sql` y después `supabase_migration_multi_inventory.sql` en una base de pruebas.
2. Confirma que `products.user_id` e `inventory_batches.user_id` admiten NULL y que los registros históricos conservan su `user_id` y `workspace_id = 'TUSK'`.
3. Genera un código de ACT 1 desde la administración, vincula un dispositivo y sincroniza un producto con un lote. Confirma que las filas tienen `workspace_id = 'TUSK_ACT_1'` y `user_id IS NULL`.
4. Repite con ACT 2 y confirma que el dispositivo ACT 1 no recibe los datos de ACT 2.
5. Revoca el dispositivo ACT 1. `pull`, `push` y `delete` deben responder 401 después de la revocación.
6. Intenta enviar a ACT 1 un ID de producto o lote que ya pertenezca a TUSK/ACT 2; el endpoint debe rechazarlo sin modificar la fila original.
7. Elimina un producto sin conexión, sincroniza y confirma que no reaparece; los lotes deben eliminarse antes del producto.
8. Selecciona un perfil, solicita la base de datos, cambia el perfil en las preferencias y solicita de nuevo la base dentro del mismo proceso. La segunda instancia debe apuntar al nombre de archivo del nuevo perfil.
9. Prueba el acceso offline de administrador por separado: debe desbloquear solo el área local y no autorizar operaciones remotas.

## Limitaciones

No se ha ejecutado esta migración contra tu proyecto Supabase, no se ha desplegado `admin-gateway` y no se ha compilado ni probado Android en un dispositivo. El entorno disponible no contiene `gradlew` ni `gradle-wrapper.jar`, y no hay conexión autorizada a tu Supabase. No es todavía una versión verificada para producción.


## Usuario de prueba local

- El perfil `Usuario de prueba` usa el archivo Room `control_vencimientos_test.db`, separado de todos los inventarios reales.
- Empieza vacío; no crea productos ficticios automáticamente.
- No requiere código del administrador ni se vincula a `inventory_workspaces`.
- Su sincronización Supabase y los envíos reales de correo (manuales y automáticos) están desactivados. Las acciones locales de la aplicación siguen disponibles para probarlas.

## Códigos de vinculación

- El servidor ya contiene `create-device-invite`, `bind-device`, `authorize-device`, `device-bindings` y `revoke-device` en `supabase/functions/admin-gateway/index.ts`.
- El administrador debe iniciar sesión en línea y generar un código por perfil ACT 1–ACT 4. El código dura 10 minutos y sirve una sola vez. Esta interfaz permite copiarlo; el envío a la otra persona debe hacerse por el canal que el administrador elija.
- Ejecuta `supabase_migration_multi_inventory.sql` y despliega la función Edge `admin-gateway` para habilitar la función en el servidor. El usuario de prueba no requiere SQL adicional, porque es local.
- Los identificadores de nube son `TUSK_ACT_1`…`TUSK_ACT_4` (con guiones bajos), no los títulos visibles `TUSK ACT 1`…`TUSK ACT 4`.
