# Correcciones de inventario y Control de Macro

Cambios aplicados sobre el código fuente recibido:

1. **Importación repetida:** el importador normaliza PLU/código de barras sin distinguir mayúsculas y espacios; intenta reutilizar el producto existente y consolida entradas duplicadas anteriores del mismo identificador.
2. **Lotes repetidos:** al reimportar una misma fecha de vencimiento, actualiza el lote existente en lugar de insertar otro. Las cantidades del CSV se aplican como valor absoluto, no se suman en cada importación.
3. **Macro idempotente:** importar el mismo registro o agregar los mismos productos a Macro reutiliza el registro por área, identificador y vencimiento; después limpia registros duplicados con la misma clave lógica.
4. **Sincronización al eliminar:** eliminar un producto, su último lote o un lote concreto también retira las referencias de Macro relacionadas y registra las bajas para la sincronización.
5. **Productos vencidos:** se pueden retirar de Macro con el nuevo botón de papelera en cada tarjeta. Si se elimina el lote vencido desde inventario, se elimina también su registro Macro relacionado.
6. **Renovar:** se conserva el ID del registro y se actualizan las fechas; el periodo de respuesta/descuento inicia dos días después de pulsar renovar. Un lote con vencimiento físico pasado no se renueva y se retira de Macro.

## Validación

Se revisó estáticamente el código modificado. No se pudo ejecutar `assembleDebug` en este entorno porque no hay un ejecutable de Gradle instalado ni el `gradle-wrapper.jar` dentro del proyecto. Por eso esta entrega no se presenta como compilación verificada. Probar en CI/Android Studio antes de distribuir el APK.
