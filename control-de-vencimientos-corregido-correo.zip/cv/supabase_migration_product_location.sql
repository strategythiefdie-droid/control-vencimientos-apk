-- Añade la ubicación física de cada producto sin eliminar ni reconstruir datos.
-- Ejecutar en Supabase > SQL Editor. Es seguro volver a ejecutarlo.
alter table public.products
  add column if not exists location text not null default '';

alter table public.products
  add column if not exists location_updated_at bigint not null default 0;

-- Actualiza el esquema que expone la API REST de Supabase.
notify pgrst, 'reload schema';
