# Actualización Macro: renovación y descuento manual

- El aviso de renovación ahora es un botón tocable dentro de la tarjeta de Macro.
- Al tocarlo, el registro se renueva conservando el producto, PLU, lote/vencimiento, cantidad y descuento. La nueva fecha de inicio queda en hoy + 2 días (regla operativa de respuesta de Macro), conserva la duración de la vigencia anterior y recalcula la fecha para volver a renovar (fin - 2 días).
- El descuento es editable desde un menú en cada registro de Macro: 10 %, 20 %, 30 %, 40 %, 50 %, 60 % y 70 %.
- Los cambios se guardan en Room. No se modifica el acceso TUSK ni la restricción de administrador.

Nota: el entorno de edición no incluye `gradlew` ni Gradle instalado, por lo que la compilación debe verificarse abriendo el proyecto en Android Studio.


## Renovación manual disponible en cualquier momento

El botón **Renovar ahora** aparece en los registros de Macro que tengan un ID y cuyo lote no esté vencido físicamente. Ya no depende de que el estado sea `RENEW` ni de que haya llegado la fecha sugerida. Al pulsarlo, la lógica existente de `renewMacroRecord` reinicia la vigencia: la nueva fecha de inicio queda a 2 días desde hoy, conserva la duración del periodo anterior (o usa 7 días si no hay duración válida), y calcula la nueva fecha de renovación dos días antes del fin. Si el lote ya venció físicamente, el botón no se muestra.
