# Revisión 2 — selección de perfil y separación local

## Cambios incluidos

- Al primer inicio se muestra una selección entre TUSK, TUSK ACT 1, TUSK ACT 2, TUSK ACT 3 y TUSK ACT 4.
- TUSK conserva el nombre de base local anterior `control_vencimientos.db`; no se crea una base vacía para reemplazar sus datos existentes.
- Cada perfil nuevo usa un archivo Room distinto (`control_vencimientos_act1.db` ... `control_vencimientos_act4.db`). Los productos, lotes, Macro, relaciones y registros del pasillo quedan aislados porque todas esas tablas pertenecen a esa base.
- La sincronización en nube falla de forma cerrada para los perfiles ACT 1–ACT 4. El esquema/sesión actual está configurado para TUSK; permitirles sincronizar ahora podría mezclar sus datos con TUSK. Los perfiles nuevos siguen funcionando localmente.

## Limitaciones que siguen abiertas

- La elección se guarda como perfil activo. Todavía falta una opción segura dentro de la interfaz para cambiar de perfil después de la primera selección.
- No se ha implementado la validación de autorización de dispositivo en cada petición de sincronización.
- No se ha conectado la selección de perfil a códigos de un solo uso ni a la vinculación administrativa completa.
- La sincronización cloud de ACT 1–ACT 4 permanece desactivada intencionalmente.
- Esta sesión no tiene un ejecutable Gradle disponible y el ZIP no incluye `gradlew` ni `gradle-wrapper.jar`; por tanto no se pudo compilar ni ejecutar pruebas Android.

## Prueba recomendada antes de producción

1. Hacer una copia de seguridad del dispositivo con TUSK.
2. Instalar una compilación de prueba y elegir TUSK; comprobar que aparecen los datos previos.
3. En instalación de prueba separada, elegir ACT 1 e insertar un producto de prueba.
4. Confirmar que ACT 1 no muestra productos de TUSK y que la sincronización de ACT 1 informa que está desactivada.
5. No ejecutar migraciones de producción hasta desplegar y revisar las políticas de autorización en Supabase.
