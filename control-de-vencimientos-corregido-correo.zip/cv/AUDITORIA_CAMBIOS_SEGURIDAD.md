# Auditoría de seguridad y cambios aplicados

## Cambios aplicados
- Se retiró el acceso administrativo local basado en la contraseña compartida `TRACEON`.
- El diálogo de administración solicita únicamente la contraseña; no se pide ni se usa correo para este acceso.
- La contraseña se verifica en la Supabase Edge Function `admin-gateway`; las consultas de solo lectura se ejecutan en servidor con `service_role`, que nunca debe incluirse en el APK.
- Se muestra estado de carga y mensajes de error durante el inicio de sesión.
- Cancelar el diálogo limpia el estado de autenticación pendiente.
- Se eliminó la prueba unitaria obsoleta que validaba la contraseña local.
- Se actualizaron los README para describir el flujo nuevo.
- Se conserva la base local Room y no se ha reintroducido `fallbackToDestructiveMigration()`.
- La contraseña ya no se reutiliza en cada consulta: el servidor entrega una sesión firmada con vencimiento de 15 minutos.
- Se retiró la dirección de correo fija que había quedado como comentario/constante obsoleta en el cliente.
- Se desactivó el respaldo automático del sistema Android para proteger los datos locales; el respaldo manual de la aplicación permanece disponible.

## Requisitos antes de usar en producción
1. Desplegar `supabase/functions/admin-gateway` y configurar `ADMIN_PASSWORD`, `ADMIN_SESSION_SECRET` (mínimo 32 caracteres aleatorios) y `SUPABASE_SERVICE_ROLE_KEY` como secretos de Supabase.
2. Aplicar rate limiting a la función y usar una contraseña larga y única.
3. Probar contraseña correcta/incorrecta y confirmar que las consultas son solo de lectura.
4. Hacer una copia de seguridad del inventario local antes de instalar una versión nueva.

## Validación pendiente
No se pudo ejecutar una compilación Android ni pruebas automatizadas en este entorno: el proyecto no incluye `gradlew`/`gradle-wrapper.jar`, no hay Gradle instalado y no hay Android SDK configurado. El ZIP y los cambios se revisaron estáticamente, pero deben compilarse y probarse en Android Studio antes de distribuir el APK.
