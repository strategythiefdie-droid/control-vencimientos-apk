# Revisión 5 — endpoint de sincronización por dispositivo

## Incluido

- Nueva acción `sync-inventory` en `supabase/functions/admin-gateway`.
- Cada operación (`pull`, `push`, `delete`) vuelve a comprobar el token del dispositivo, su hash, el inventario vinculado, la revocación y que el inventario siga activo.
- El cliente no puede elegir libremente el inventario de destino: el servidor valida que coincida con la vinculación y establece `workspace_id` en el servidor.
- Lecturas, escrituras y eliminaciones filtran por el inventario autorizado.
- Rechaza conflictos de identificadores que ya pertenezcan a otro inventario y valida que los lotes se relacionen con productos del mismo inventario.
- Limita el tamaño de cada lote de sincronización.

## Contrato de la función

La función recibe `action: "sync-inventory"`, `deviceId`, `deviceToken`, `workspaceId` y `mode`.

- `mode: "pull"`: devuelve `products` y `batches` del inventario vinculado.
- `mode: "push"`: recibe arreglos `products` y `batches`.
- `mode: "delete"`: recibe `deleteProducts` y `deleteBatches` con UUIDs.

Los perfiles permitidos en este endpoint son `TUSK_ACT_1` a `TUSK_ACT_4`. TUSK sigue usando el flujo existente y no se redirige a este endpoint.

## Antes de producción

1. Revisar y aplicar la migración multi-inventario en un entorno de prueba, con respaldo.
2. Desplegar `admin-gateway` y configurar sus secretos en Supabase.
3. Integrar las llamadas `pull`/`push`/`delete` desde Android. La app de esta revisión todavía no invoca `sync-inventory`; los perfiles secundarios permanecen bloqueados de forma segura en la sincronización.
4. Probar con dispositivos reales: código expirado/reutilizado, dispositivo revocado, perfil incorrecto, IDs cruzados entre inventarios, lotes huérfanos y pérdida de conexión.
5. No habilitar producción hasta revisar la política de eliminación de productos con lotes asociados y confirmar el esquema real de la base.

## Estado de validación

No se desplegó la función ni se ejecutaron pruebas contra un proyecto Supabase real. No se afirma que esta revisión esté compilada o probada en dispositivo.
