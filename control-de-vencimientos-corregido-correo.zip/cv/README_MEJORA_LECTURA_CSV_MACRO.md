# Mejora de lectura CSV en Macro

- Consolida filas repetidas del mismo PLU + fecha de vencimiento dentro del archivo; conserva la última fila para que la cantidad más reciente sea la aplicada.
- Al importar, reutiliza el lote del producto y vencimiento en vez de crear otro.
- Si ya existían lotes duplicados históricos con el mismo producto y vencimiento, conserva uno (el más reciente) y elimina los demás antes de actualizar la cantidad.
- La búsqueda de productos se limita al área activa: un PLU igual en otra área ya no provoca que el producto se mueva de área accidentalmente.
- La búsqueda de registros Macro anteriores también se limita al área activa.
- El mensaje final indica cuántas filas repetidas del CSV se consolidaron.

Validación: ZIP revisado con `unzip -t`. No se ejecutó compilación Android en este entorno; validar en Android Studio o GitHub Actions antes de instalar.
