# Nota de compatibilidad: alerta especial de 8 días

La versión anterior de Android intentaba llamar a una acción independiente `sendEmergencyExpiry8Days` y esperaba una respuesta con `sent` y `count`. El Apps Script activo descrito para este proyecto no implementa ese contrato: procesa la revisión con `runExpiryProcess_()` y devuelve los resultados dentro de `counts`.

Por eso, la versión actualizada de Android deja de usar esa acción no compatible. El trabajador automático sincroniza primero el inventario con Supabase y después llama a Apps Script con `action: "sync"` y `manual: false`. Apps Script aplica las reglas de alertas general y especial configuradas en el servidor (incluida la regla de 8 días para las categorías autorizadas).

La notificación local de Android para el vencimiento especial de 8 días es independiente y sigue en `ExpiryNotificationWorker` / `SpecialExpiryAlert`.

El botón manual usa `action: "sendAlert"` y `manual: true`; sincroniza primero y luego interpreta `counts.emails_accepted`, `counts.email_failures`, `counts.general_candidates`, `counts.special_candidates` y `counts.duplicates`. Un HTTP 200, por sí solo, no se presenta como confirmación de envío.

**Límite:** este paquete actualiza Android. No contiene el proyecto de Google Apps Script, así que no modifica ni publica `Code.gs`. La respuesta remota debe seguir incluyendo el objeto `counts` que produce la versión actual del servidor.
