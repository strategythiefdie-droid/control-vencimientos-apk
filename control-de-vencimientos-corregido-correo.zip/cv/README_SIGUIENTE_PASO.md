# Estado de esta entrega — Control de Vencimientos multiinventario

## Cambio incluido en esta revisión
- La acción administrativa `device-bindings` devuelve el hash completo del dispositivo para que la acción `revoke-device` pueda identificarlo exactamente. Antes la respuesta lo truncaba a ocho caracteres, lo que impedía enviar el identificador completo a la acción de revocación.

## Aún NO es una actualización instalable
Esta revisión no debe instalarse como si ya aislara perfiles en Android. La aplicación todavía usa `control_vencimientos.db` como base local compartida y el cliente de sincronización consulta Supabase directamente con la sesión Auth existente. El `deviceToken` de `bind-device` es actualmente una respuesta de configuración, no una credencial validada en cada operación.

## Requisitos antes de producción
1. Hacer copia de seguridad exportable del inventario TUSK y de la base de Supabase.
2. Integrar selección de perfil antes de crear el ViewModel y usar un nombre de base Room por perfil. Migrar la base actual a `TUSK` sin borrar datos; no usar `fallbackToDestructiveMigration`.
3. Separar también las preferencias/tombstones de sincronización por perfil y revisar workers/alarms para que usen el perfil correcto.
4. Implementar un token de dispositivo aleatorio, guardarlo de forma segura, persistir solo su hash en servidor y comprobar estado revocado/perfil autorizado en cada petición de sincronización.
5. Enrutar la sincronización a través de un endpoint que valide el dispositivo, o aplicar políticas equivalentes en servidor. No considerar `workspace_id` enviado por el cliente como autorización.
6. Terminar la pantalla administrativa para mostrar dispositivos y revocarlos con el hash completo.
7. Desplegar SQL/Edge Function en un proyecto de pruebas, compilar Android y ejecutar pruebas de migración, aislamiento, sincronización offline, códigos reutilizados y revocación.

## Migración de Supabase
`supabase_migration_multi_inventory.sql` modifica tablas existentes y añade columnas, índices y tablas. Aunque no borra productos, debe probarse primero en un entorno de prueba y respaldarse antes de ejecutarla en producción.

## Verificación
No se afirma que este ZIP haya sido compilado, probado en un dispositivo ni desplegado en Supabase. La corrección del hash es una corrección de código fuente; requiere desplegar la Edge Function para verse reflejada en el servicio.
