# Corrección de importación de Macro desde CSV

Cambios incluidos en esta actualización:
- Los campos se buscan por encabezado y no por posición fija.
- `PLU` se conserva como texto; `Descripcion` se usa solo como nombre.
- `Fecha_Vencimiento` y `Cantidad_Vencer` se guardan en el lote del inventario.
- `DesdeCuando` y `HastaCuando` se guardan como vigencia de Macro.
- `PorcentajeDescue` se guarda por separado y se muestra como porcentaje en la tarjeta de Macro.
- `Estado Solic...` y `Detalle Estado` se ignoran.
- Se añade migración Room 4→5 para guardar vencimiento, cantidad y porcentaje en cada registro de Macro.
- Se evita volver a sumar la cantidad al importar otra vez el mismo vencimiento.

CSV esperado (el orden puede variar):
`PLU, Descripcion, Fecha_Vencimiento, Cantidad_Vencer, DesdeCuando, HastaCuando, PorcentajeDescue`

La app usa fechas ISO (`yyyy-MM-dd`) internamente. Se aceptan en el CSV `dd-MM-yyyy`, `dd/MM/yyyy` y `yyyy-MM-dd`.
