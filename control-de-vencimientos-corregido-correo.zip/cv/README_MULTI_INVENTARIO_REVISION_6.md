# Revisión 6 — integración Android del endpoint multiinventario

## Cambios

- `SupabaseSyncRepository` ahora dirige perfiles ACT 1–ACT 4 al endpoint `sync-inventory`; TUSK mantiene su ruta heredada.
- Cada solicitud `pull`, `push` y `delete` incluye la identidad y la credencial cifrada del dispositivo; el servidor vuelve a validar la autorización en cada operación.
- La sincronización secundaria procesa eliminaciones pendientes primero, descarga el inventario autorizado, importa productos antes que lotes y luego sube los datos locales por lotes dentro de los límites del endpoint.
- Los tombstones locales solo se eliminan tras completar la secuencia de sincronización.
- `admin-gateway` usa una lista permitida de campos para productos y lotes en vez de aceptar objetos arbitrarios del cliente, evitando que un dispositivo cambie campos de propiedad u otras columnas.

## Requisitos antes de habilitar en producción

1. Desplegar la versión actualizada de `supabase/functions/admin-gateway`.
2. Confirmar que los campos reales de `products` e `inventory_batches` permiten los valores opcionales usados por esta función; probar con una base de staging primero.
3. Aplicar/revisar la migración multiinventario con copia de seguridad.
4. Compilar el proyecto en Android Studio y ejecutar pruebas en dispositivos reales: vínculo correcto/incorrecto, revocación, desconexión, eliminaciones pendientes, lotes huérfanos, perfiles cruzados y más de un lote de sincronización.
5. Verificar específicamente las columnas `user_id`, `category`, `quantity` y `expiry_date` del esquema desplegado. La función no permite que el cliente escriba `user_id`; si el esquema exige ese campo sin valor predeterminado, debe definirse una política de propietario en el servidor antes de producción.

## Validación

No se compiló ni se ejecutó contra Supabase en esta sesión. El ZIP es código fuente actualizado, no un APK probado. Mantener la sincronización de ACT 1–ACT 4 deshabilitada en producción hasta completar las pruebas del esquema real.
- El almacenamiento de eliminaciones pendientes conserva el nombre histórico de preferencias de TUSK y utiliza un espacio independiente para cada perfil secundario, evitando que una sincronización consuma las eliminaciones de otro inventario.
