# Acceso de administrador con solo contraseña

La app ya no solicita ni usa un correo para el acceso de administrador. La verificación se realiza en una Supabase Edge Function; la contraseña y la clave `service_role` no deben incluirse en el APK.

## Configuración obligatoria en Supabase

1. Instala/actualiza Supabase CLI y vincula el proyecto correcto.
2. Define los secretos del proyecto (usa una contraseña larga, única y distinta de cualquier otra contraseña):

   ```bash
   supabase secrets set ADMIN_PASSWORD='PON_AQUI_UNA_CONTRASENA_LARGA_Y_UNICA'
   supabase secrets set SUPABASE_SERVICE_ROLE_KEY='TU_SERVICE_ROLE_KEY'
supabase secrets set ADMIN_SESSION_SECRET='UNA_CLAVE_ALEATORIA_DE_AL_MENOS_32_CARACTERES'
   ```

   `SUPABASE_URL` suele estar disponible para las Edge Functions; si no, configúralo con la URL del proyecto.
3. Despliega la función:

   ```bash
   supabase functions deploy admin-gateway --no-verify-jwt
   ```

4. El comando anterior desactiva la verificación JWT de entrada para permitir el inicio sin sesión Supabase Auth. La función verifica la contraseña al iniciar y usa un token temporal firmado para las consultas posteriores. No elimines esas comprobaciones.
5. Prueba desde un dispositivo: contraseña correcta debe permitir consultar usuarios/productos; una contraseña incorrecta debe ser rechazada.

## Seguridad

- Nunca pongas `ADMIN_PASSWORD` ni `SUPABASE_SERVICE_ROLE_KEY` en Kotlin, recursos Android, Git o el APK.
- Este acceso usa una contraseña compartida, no una identidad individual. Usa una contraseña larga, única y configura limitación de intentos/rate limiting en la capa de API (por ejemplo, gateway/WAF) antes de distribuir la app.
- La contraseña solo se envía al iniciar sesión. Las consultas usan un token firmado por el servidor que vence a los 15 minutos; al vencer, se debe volver a introducir la contraseña.
- La función solo expone lectura de perfiles y productos. No permite escrituras administrativas.
- Se desactivó la copia de seguridad automática de Android para reducir la exposición accidental de datos locales. La función de copia/restauración manual de la propia app no se elimina.
- La función presupone que las tablas `profiles` y `products` tienen las columnas usadas por la app.
- El inventario local Room no se borra ni migra destructivamente por este cambio.

La compilación Android y el despliegue deben validarse en tu entorno antes de usarlo en producción.
