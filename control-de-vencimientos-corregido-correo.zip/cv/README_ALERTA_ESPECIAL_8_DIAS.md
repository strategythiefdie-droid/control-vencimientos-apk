# Alerta especial de refrigerados (8 días)

Se añadió una notificación local prioritaria para lotes de carnes, pollo, pescado y lácteos.

- Se calcula con la fecha de vencimiento del lote (`BatchEntity.expiryDate`), no con fechas de Macro.
- Se activa cuando faltan exactamente 8 días.
- Reconoce el área `lacteos` y, para otras áreas o categorías, usa palabras clave en el nombre.
- Agrupa los lotes que correspondan en una notificación, ordenados por mayor cantidad/peso.
- Registra cada combinación de producto, lote y fecha de vencimiento para evitar repeticiones en ejecuciones del Worker y AlarmManager.
- Usa un canal de notificación separado y una vibración distinta. El canal especial usa el tono de notificación predeterminado de Android; el canal normal usa el tono de alarma predeterminado. El sonido real puede depender de los ajustes del teléfono y del canal.
- Reutiliza los procesos en segundo plano existentes. Android puede retrasarlos por permisos, ahorro de batería o restricciones del fabricante.

Para recibirla, el usuario debe conceder permiso de notificaciones y mantener activadas las notificaciones del canal especial en los ajustes de Android.
