-- Migración complementaria para Control de Vencimientos.
-- Ejecutar en Supabase > SQL Editor > New query.
-- No borra ni reemplaza la tabla public.products creada anteriormente.

-- Datos que la app local necesita además del esquema inicial.
alter table public.products add column if not exists area_id text;
alter table public.products add column if not exists unit_cost numeric;
alter table public.products add column if not exists location text not null default '';
alter table public.products add column if not exists location_updated_at bigint not null default 0;
alter table public.products add column if not exists has_return boolean not null default false;
alter table public.products add column if not exists return_updated_at bigint not null default 0;

-- Un producto puede tener varios lotes/fechas de vencimiento.
create table if not exists public.inventory_batches (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  product_id uuid not null references public.products(id) on delete cascade,
  batch_number text,
  quantity numeric not null default 1,
  expiry_date date not null,
  created_at timestamptz not null default now()
);

-- Registros de Macro por área.
create table if not exists public.macro_records (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  area_id text not null,
  plu text,
  name text not null,
  start_date date,
  end_date date,
  renew_date date,
  unmatched boolean not null default false,
  updated_at timestamptz not null default now()
);

alter table public.inventory_batches enable row level security;
alter table public.macro_records enable row level security;

-- Policies idempotentes: pueden volver a ejecutarse sin error por nombres duplicados.
drop policy if exists "Users can read own batches" on public.inventory_batches;
drop policy if exists "Users can insert own batches" on public.inventory_batches;
drop policy if exists "Users can update own batches" on public.inventory_batches;
drop policy if exists "Users can delete own batches" on public.inventory_batches;
create policy "Users can read own batches" on public.inventory_batches for select to authenticated using (auth.uid() = user_id);
create policy "Users can insert own batches" on public.inventory_batches for insert to authenticated with check (auth.uid() = user_id);
create policy "Users can update own batches" on public.inventory_batches for update to authenticated using (auth.uid() = user_id) with check (auth.uid() = user_id);
create policy "Users can delete own batches" on public.inventory_batches for delete to authenticated using (auth.uid() = user_id);

drop policy if exists "Users can read own macro records" on public.macro_records;
drop policy if exists "Users can insert own macro records" on public.macro_records;
drop policy if exists "Users can update own macro records" on public.macro_records;
drop policy if exists "Users can delete own macro records" on public.macro_records;
create policy "Users can read own macro records" on public.macro_records for select to authenticated using (auth.uid() = user_id);
create policy "Users can insert own macro records" on public.macro_records for insert to authenticated with check (auth.uid() = user_id);
create policy "Users can update own macro records" on public.macro_records for update to authenticated using (auth.uid() = user_id) with check (auth.uid() = user_id);
create policy "Users can delete own macro records" on public.macro_records for delete to authenticated using (auth.uid() = user_id);

-- Crear perfil de forma automática cuando se registra una cuenta nueva.
create or replace function public.handle_new_user_profile()
returns trigger
language plpgsql
security definer set search_path = ''
as $$
begin
  insert into public.profiles (id, full_name, role)
  values (new.id, coalesce(new.raw_user_meta_data ->> 'full_name', ''), 'user')
  on conflict (id) do nothing;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created_profile on auth.users;
create trigger on_auth_user_created_profile
after insert on auth.users
for each row execute procedure public.handle_new_user_profile();
